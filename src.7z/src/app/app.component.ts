import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'app-bp';
  constructor() {
    console.log('%c Despliegue 11/01/2022 11:00 am Adrian Osorio', 'background: red');
    
  }
}
