import { BrowserModule } from '@angular/platform-browser';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainPipe } from './commons/pipes/main.pipe';
import { ValidatorsComponent } from './commons/validators/validators.component';
import { RequestComponent } from './workflows/request/request.component';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { MsalModule, MsalInterceptor } from '@azure/msal-angular';
import { AuthInterceptorService } from './commons/services/auth-interceptor.service';
import { LOCALE_ID } from '@angular/core';
import { registerLocaleData } from '@angular/common';
import localePy from '@angular/common/locales/es-PY';
import { environment } from '../environments/environment';
import { HttpErrorInterceptor } from './commons/services/http-interceptor.service';
import { Logger, LogLevel } from 'msal';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxSpinnerModule } from "ngx-spinner";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RetryGuard} from './commons/guards/guardsRetry.guard';
import { ParametrizationGuard} from './commons/guards/guardOptionParametrization.guard';
import { SecurityGuard } from './commons/guards/guardsSecurity.guard';
import { ConsultGuard } from './commons/guards/guardsConsult.guard';
import { ParametrizationGeneralGuard }  from './commons/guards/guardParametrizationGeneral.guard';
import { SecurityProfileGuard } from './commons/guards/guardsSecurityPerfil.guard';
import { RetryExecuteGuard} from './commons/guards/guardsRetryEjecutar.guard';

import { WorkflowModule } from './workflows/workflow.module';
import { SharedModule } from './commons/shared/shared.module';
import { SpinnerInterceptor } from './commons/shared/interceptors/spinner.interceptor';
import { WorkflowComponent } from './workflows/workflow.component';
import { RouterModule } from '@angular/router';


/**
 * @ngdoc ngModule
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Julio 2020
 * @author Everis Colombia - para Banco Popular.
 * @description Fichero encargado de realizar la configuracion del SSO, tambien se definen
 * los interceptores del SSO y de la aplicacion.
 */
//Se obtiene informacion referente al navegador
const isIE =
  window.navigator.userAgent.indexOf('MSIE ') > -1 ||
  window.navigator.userAgent.indexOf('Trident/') > -1;

registerLocaleData(localePy, 'es');
export function loggerCallback(logLevel, message, piiEnabled) {
//  console.log("Otorgamiento 2.0 log -->" + message);
}
@NgModule({
  declarations: [
    AppComponent,
    WorkflowComponent,
    MainPipe,
    ValidatorsComponent
    ],
  imports: [
    RouterModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    NgbModule,
    SharedModule,
    NgxSpinnerModule,
    BrowserAnimationsModule,
    //configuracion del SSO
    MsalModule.forRoot(
      {
        auth: {
          // clientId: '8d517bd6-f223-46d7-bdbb-ec1a77cccd9d',
          clientId: 'dcf32222-b3ec-4d04-a0eb-1e0b4a7c0b02',
          //authority:
          // 'https://login.microsoftonline.com/09b63778-0d1f-49a8-8ab5-073e498466fb',
          authority:
            'https://login.microsoftonline.com/616e0c03-b820-4f30-9aa4-b4fdaffca42a',
          redirectUri: environment.returnUrl + '/home',
          // redirectUri: 'https://52.248.44.104/home',
          //redirectUri: 'https://52.151.229.220/home',
          //redirectUri: 'https://10.160.141.101:443/home',
          // redirectUri: 'https://10.160.141.102/home',
          //postLogoutRedirectUri: 'http://localhost',
          // postLogoutRedirectUri: 'https://52.248.44.104',
          //
          //postLogoutRedirectUri: 'https://10.160.141.101',
          postLogoutRedirectUri: environment.returnUrl + '/home',
          // po stLogoutRedirectUri: 'https://52.151.229.220/',

          navigateToLoginRequestUrl: false,
        },
        cache: {
          cacheLocation: 'localStorage',
          storeAuthStateInCookie: isIE, // set to true for IE 11
        },
        system: {
          logger: new Logger(loggerCallback, {
            correlationId: '1234',
            level: LogLevel.Verbose,
            piiLoggingEnabled: true,
          }),
          loadFrameTimeout: 6000,
          tokenRenewalOffsetSeconds: 3000,
          navigateFrameWait: 8000,

        },
      },
      {
        popUp: false,
        consentScopes: ['user.read', 'openid', 'profile'],
        unprotectedResources: [],
        protectedResourceMap: [
          ['https://graph.microsoft.com/v1.0/me', ['user.read']],
        ],
        extraQueryParameters: {},
      }
    ),
    NgbModule,
    WorkflowModule  
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [
    //interceptor del SSO
    {
      provide: HTTP_INTERCEPTORS,
      useClass: MsalInterceptor,
      multi: true,
    },
    //interceptor de la aplicacion
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptorService,
      multi: true,
    },
    //interceptor del spinner
    {
      provide: HTTP_INTERCEPTORS,
      useClass: SpinnerInterceptor,
      multi: true,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpErrorInterceptor,
      multi: true,
    },
      RetryGuard,
      ParametrizationGuard,
      SecurityGuard,
      ConsultGuard,
      ParametrizationGeneralGuard,
      SecurityProfileGuard,
      RetryExecuteGuard,
    { 
      provide: LOCALE_ID, useValue: 'es-CO' 
    },
  ],
  exports: [],
  bootstrap: [AppComponent],
})
export class AppModule { }
