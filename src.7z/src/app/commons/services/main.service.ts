import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Filtro } from '../models/filtro';
import { SolicitudResponse } from '../models/solicitudResponse';
import { API } from 'src/utils/endpoints';
import { Acceso } from '../models/acceso';
import { PerfilResponse } from '../models/perfilResponse';
import { Perfil } from '../models/perfil';
import { SolicitudDetail } from '../models/solicitudDetail';
import { Cliente } from '../models/cliente';
import { ConsultarOficina } from '../models/consultarOficina';
import { Oficina } from '../models/oficina';
import { InfoMotor } from '../models/infoMotor';
import { Ficha } from '../models/ficha';
import { ConsultarFicha } from '../models/consultarFicha';
import { ConsultarMotor } from '../models/consultarMotor';
import { InfoFinanciera } from '../models/infoFinanciera';
import { InfoLaboral } from '../models/infoLaboral';
import { ConsultarFinanciera } from '../models/consultarFinanciera';
import { ConsultarLaboral } from '../models/consultarLaboral';
import { ConsultarTraza } from '../models/consultarTraza';
import { TrazaResponse } from '../models/trazaResponse';
import { InfoCatalogo } from '../models/infoCatalogo';
import { ConsultarCatalogo } from '../models/consultarCatalogo';
import { InfoParams } from '../models/infoParams';
import { PaginaResponse } from '../models/paginaResponse';
import { ConsultarPermisos } from '../models/consultarPermisos';
import { PermisosPerfilResponse } from '../models/permisosPerfilResponse';
import { ConsultarFuncionalidad } from '../models/consultarFuncionalidad';
import { PermissionFuncResponse } from '../models/permissionFuncResponse';
import { InfoFuncionalidad } from '../models/infoFuncionalidad';
import { PerfilByPageResponse } from '../models/perfilByPageResponse';
import { CatalogResponse } from '../models/catalogResponse';
import { CatalogProductResponse } from '../models/catalogProductResponse';
import { InfoCatalogoProducto } from '../models/infoCatalogoProducto';
import { InfoCatalogoProductoFlujo } from '../models/infoCatalogoProductoFlujo';
import { CatalogProductFlowResponse } from '../models/catalogProductFlowResponse';
import { CanalResponse } from '../models/canalResponse';
import { InfoCanal } from '../models/infoCanal';
import { InfoCatalogoCargo } from '../models/infoCatalogoCargo';
import { CargoResponse } from '../models/catalogCargoResponse';
import { OcupationResponse } from '../models/catalogOcupationResponse';
import { InfoCatalogoOcupation } from '../models/infoCatalogoOcupation';
import { ActivityResponse } from '../models/catalogActivityResponse';
import { InfoCatalogoActividad } from '../models/infoCatalogoActividad';
import { ConsultarCliente } from '../models/consultarCliente';
import { ContractResponse } from '../models/catalogContractResponse';
import { InfoCatalogoContrato } from '../models/infoCatalogoContracto';
import { InfoCatalogoEstamento } from '../models/infoCatalogoEstamento';
import { StatementResponse } from '../models/catalogStatementResponse';
import { InfoParamsNombre } from '../models/infoParamsNombre';
import { ConsultarParamsNombre } from '../models/consultarParamsNombre';
import { ConsultarSolicitud } from '../models/consultarSolicitud';
import { SolicitudPerClient } from '../models/solicitudPerClient';
import { OfficeResponse } from '../models/catalogOfficeResponse';
import { InfoCatalogoOficina } from '../models/infoCatalogoOficina';
import { InfoCatalogoOficinaDepartamento } from '../models/infoCatalogoOficinaDepartamento';
import { CitiesResponse } from '../models/catalogOfficeCityResponse';
import { DepartmentResponse } from '../models/catalogOfficeDepartmentResponse';
import { ZoneResponse } from '../models/catalogOfficeZoneResponse';
import { InfoTraza } from '../models/infoTraza';
import { API_CATALOGS } from '@src/utils/catalogs';

/**
 * @ngdoc service
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Julio 2020
 * @author Everis Colombia - para Banco Popular.
 * @description Fichero encargado de realizar la comunicacion de todos las operaciones de los
 * diferentes microservicios
 */
@Injectable({
  providedIn: 'root',
})
export class MainService {
  constructor(public clientHttp: HttpClient) {}
  /**
   * @description metodo encargado de consultar las solicitudes.
   * @author yquintana - Everis Colombia - para Banco Popular.
   * @version 1.0.0
   * @since Julio 2020
   * @param idProfiles que representa el arreglo de perfiles.
   * @returns retorna el objeto tipo Acceso como subscriber.
   */
  public findRequest(filtro: Filtro) {
    return this.clientHttp.post<SolicitudResponse>(API.SEARCH_REQUEST, filtro);
  }
  /**
   * @description metodo encargado de consultar los accesos por arreglo de perfiles.
   * @author yquintana - Everis Colombia - para Banco Popular.
   * @version 1.0.0
   * @since Julio 2020
   * @param idProfiles que representa el arreglo de perfiles.
   * @returns retorna el objeto tipo Acceso como subscriber.
   */
  public findPermissions(idProfiles: string[]) {
    return this.clientHttp.post<Acceso[]>(API.SEARCH_PERMISSIONS, idProfiles);
  }
  /**
   * @description metodo encargado de retornar el token del backend.
   * @author yquintana - Everis Colombia - para Banco Popular.
   * @version 1.0.0
   * @since Julio 2020
   * @param user que representa el nombre del usuario
   * @param accessToken  que representa el token del SSO.
   * @returns retorna el objeto tipo any como subscriber.
   */
  public generateTokenAPI(user: string, accessToken: string) {
    const body = {
      usuario: user,
      aplicacion:
        '99fa63f56bb31d78de25437286a800a4a1f7af06853d0d45f34f4aafcc26da68',
      token: accessToken,
    };
    return this.clientHttp.post<any>(API.TOKEN, body);
  }
  /**
   * @description metodo encargado de consultar todos los perfiles.
   * @author yquintana - Everis Colombia - para Banco Popular.
   * @version 1.0.0
   * @since Julio 2020
   * @returns retorna el objeto tipo PerfilResponse como subscriber.
   */
  public findAllProfiles() {
    return this.clientHttp.get<PerfilResponse>(API.SEARCH_PROFILES);
  }
  public findAllProfilesByPage(param: string) {
    return this.clientHttp.post<PerfilByPageResponse>(API.PAGINATION_PROFILES, {
      pagina: 1,
      activo: param,
    });
  }
  /**
   * @description metodo encargado de crear el perfil.
   * @author yquintana - Everis Colombia - para Banco Popular.
   * @version 1.0.0
   * @since Julio 2020
   * @returns retorna el objeto tipo PerfilResponse como subscriber.
   */
  public createProfile(profile: Perfil) {
    return this.clientHttp.post<PerfilResponse>(API.PATH_PROFILES, profile);
  }

  public createProductTypeFlow(product: InfoCatalogoProductoFlujo) {
    return this.clientHttp.post<CatalogProductFlowResponse>(
      API_CATALOGS.ADD_CATALOG_TYPE_FLOW,
      product
    );
  }

  public createCanal(canal: InfoCanal) {
    return this.clientHttp.post<CanalResponse>(API_CATALOGS.ADD_CATALOG_CANAL, canal);
  }

  public createCargo(cargo: InfoCatalogoCargo) {
    return this.clientHttp.post<CargoResponse>(API_CATALOGS.ADD_CATALOG_CARGO, cargo);
  }

  public createOcupation(ocupation: InfoCatalogoOcupation) {
    return this.clientHttp.post<OcupationResponse>(
      API_CATALOGS.ADD_CATALOG_OCUPATION,
      ocupation
    );
  }

  public createActivity(actividad: InfoCatalogoActividad) {
    return this.clientHttp.post<ActivityResponse>(
      API_CATALOGS.ADD_CATALOG_ACTIVITY,
      actividad
    );
  }

  public createContract(contract: InfoCatalogoContrato) {
    return this.clientHttp.post<ContractResponse>(
      API_CATALOGS.ADD_CATALOG_CONTRACT,
      contract
    );
  }

  public createStatement(statement: InfoCatalogoEstamento) {
    return this.clientHttp.post<StatementResponse>(
      API_CATALOGS.ADD_CATALOG_STATEMENT,
      statement
    );
  }

  public createProduct(product: InfoCatalogoProducto) {
    return this.clientHttp.post<CatalogProductResponse>(
      API_CATALOGS.ADD_CATALOG_PRODUCT,
      product
    );
  }

  public createOffice(product: InfoCatalogoOficina) {
    return this.clientHttp.post<OfficeResponse>(
      API_CATALOGS.ADD_CATALOG_OFFICE,
      product
    );
  }
 

  /**
   * @description metodo encargado de actualizar el perfil.
   * @author yquintana - Everis Colombia - para Banco Popular.
   * @author jcastcor - Everis Colombia - para Banco Popular.
   * @version 1.0.0
   * @since Julio 2020
   * @returns retorna el objeto tipo segun variable como subscriber.
   */
  public updateProfile(profile: Perfil) {
    return this.clientHttp.post<PerfilResponse>(API.UPDATE_PROFILES, profile);
  }
  public updateParams(param: InfoParams) {
    return this.clientHttp.post<PaginaResponse>(API_CATALOGS.UPDATE_PARAMS, param);
  }
  public updatePerms(permissionFunc: Array<InfoFuncionalidad>) {
    return this.clientHttp.post<PermissionFuncResponse>(
      API.UPDATE_PERMS,
      permissionFunc
    );
  }
  public editCatalogProduct(product: InfoCatalogoProducto) {
    return this.clientHttp.post<CatalogProductResponse>(
      API_CATALOGS.UPDATE_CATALOG_PRODUCT,
      product
    );
  }

  public updateProductStatus(product: InfoCatalogoProducto) {
    return this.clientHttp.post<CatalogProductResponse>(
      API_CATALOGS.UPDATE_CATALOG_PRODUCT,
      product
    );
  }

  public updateProductTypeFlowStatus(product: InfoCatalogoProductoFlujo) {
    return this.clientHttp.post<CatalogProductFlowResponse>(
      API_CATALOGS.UPDATE_CATALOG_TYPE_FLOW,
      product
    );
  }

  // public updateCanalStatus(canal: InfoCanal) {
  //   return this.clientHttp.post<CanalResponse>(API_CATALOGS.UPDATE_CATALOG_CANAL, canal);
  // }

  public updateCanalStatus(canal: InfoCanal) {
    return this.clientHttp.post<CanalResponse>(API_CATALOGS.STATUS_CATALOG_CANAL, canal);
  }

  // actualiza canal venta
  public updateCanal(canal: InfoCanal) {
    return this.clientHttp.post<CanalResponse>(API_CATALOGS.UPDATE_CATALOG_CANAL, canal);
  }

  public updateCargoStatus(cargo: InfoCatalogoCargo) {
    return this.clientHttp.post<CargoResponse>(API_CATALOGS.UPDATE_CATALOG_CARGO, cargo);
  }

  public updateOcupationStatus(ocupation: InfoCatalogoOcupation) {
    return this.clientHttp.post<OcupationResponse>(
      API_CATALOGS.UPDATE_CATALOG_OCUPATION,
      ocupation
    );
  }

  public updateActivityStatus(actividad: InfoCatalogoActividad) {
    return this.clientHttp.post<ActivityResponse>(
      API_CATALOGS.UPDATE_CATALOG_ACTIVITY,
      actividad
    );
  }

  public updateContractStatus(contract: InfoCatalogoContrato) {
    return this.clientHttp.post<ContractResponse>(
      API_CATALOGS.UPDATE_CATALOG_CONTRACT,
      contract
    );
  }

  public updateStatementStatus(statement: InfoCatalogoEstamento) {
    return this.clientHttp.post<StatementResponse>(
      API_CATALOGS.UPDATE_CATALOG_STATEMENT,
      statement
    );
  }

  public updateOficceStatus(office: InfoCatalogoOficina) {
    return this.clientHttp.post<OfficeResponse>(
      API_CATALOGS.UPDATE_CATALOG_OFFICE,
      office
    );
  }

  public editProductInfo(product: InfoCatalogoProducto) {
    return this.clientHttp.post<CatalogProductResponse>(
      API_CATALOGS.UPDATE_CATALOG_PRODUCT,
      product
    );
  }
  public updateOffice(product: InfoCatalogoOficina) {
    return this.clientHttp.post<OfficeResponse>(
      API_CATALOGS.UPDATE_CATALOG_OFFICE,
      product
    );
  }

  /**
   * @description metodoS encargadoS de buscar información por el perfil.
   * @author yquintana - Everis Colombia - para Banco Popular.
   * @author jcastcor - Everis Colombia - para Banco Popular.
   * @version 1.0.0
   * @since Julio 2020
   * @returns retorna el objeto tipo segun variable como subscriber.
   */
  public findProfileById(id: Perfil) {
    return this.clientHttp.post<Perfil>(API.SEARCH_PROFILES, id.idPerfil);
  }

  /* public findRequestDetail(idSolicitud: string) {
    return this.clientHttp.get<SolicitudDetail>(
      API.SEARCH_REQUEST_DETAILS + idSolicitud
    );
  } */

  public findRequestDetail(idSolicitud: ConsultarSolicitud) {
    return this.clientHttp.post<SolicitudDetail>(
      API.SEARCH_REQUEST_DETAILS,
      idSolicitud
    );
  }

  public findClientById(cliente: ConsultarCliente) {
    return this.clientHttp.post<Cliente>(API.SEARCH_CLIENT_ID, cliente);
  }

  /* public findClientByDocument(document: string) {
    return this.clientHttp.get<Cliente>(API.SEARCH_CLI∫ENT_DOCUMENT + document);
  } */

  public findClientByDocument(document: ConsultarCliente) {
    return this.clientHttp.post<Cliente>(API.SEARCH_CLIENT_DOCUMENT, document);
  }

  /* public findRequestByClient(idReqCliente: number) {
    return this.clientHttp.get<SolicitudResponse>(
      API.SEARCH_REQUEST_CLIENTE + idReqCliente
    );
  } */

  /* public findRequestByClient(idReqCliente: ConsultarCliente) {
    return this.clientHttp.post<SolicitudDetail>(
      API.SEARCH_REQUEST_CLIENTE,
      idReqCliente
    );
  } */

  public findRequestPerClientId(idCliente: ConsultarCliente) {
    return this.clientHttp.post<SolicitudPerClient>(
      API.SEARCH_REQUEST_PER_CLIENTE,
      idCliente
    );
  }

  public findOfficeById(consultarOficina: ConsultarOficina) {
    return this.clientHttp.post<Oficina>(API.SEARCH_OFFICE, consultarOficina);
  }

  public findMotorBySolicitud(consultarMotor: ConsultarMotor) {
    return this.clientHttp.post<InfoMotor>(API.SEARCH_MOTOR, consultarMotor);
  }

  public findFinancieraBySolicitud(consultarFinanciera: ConsultarFinanciera) {
    return this.clientHttp.post<InfoFinanciera>(
      API.SEARCH_FINANCIERA,
      consultarFinanciera
    );
  }

  public findLaboralBySolicitud(consultarLaboral: ConsultarLaboral) {
    return this.clientHttp.post<InfoLaboral>(
      API.SEARCH_LABORAL,
      consultarLaboral
    );
  }

  public findTrazaBySolicitud(consultarTraza: ConsultarTraza) {
    return this.clientHttp.post<TrazaResponse>(
      API.SEARCH_TRAZA,
      consultarTraza
    );
  }

  public findCatalogoBySolicitud(infoCatalogo: ConsultarCatalogo) {
    return this.clientHttp.post<InfoCatalogo>(
      API_CATALOGS.SEARCH_CATALOGO,
      infoCatalogo
    );
  }

  public generateFile(consultarFicha: ConsultarFicha) {
    return this.clientHttp.post<Ficha>(API.DOWNLOAD_FILE, consultarFicha);
  }

  public findAllParams() {
    return this.clientHttp.post<PaginaResponse>(API_CATALOGS.SEARCH_PARAMS_ALL_PAGES, {
      pagina: 1,
    });
  }

  public findAllParamNames(nombreParametro: ConsultarParamsNombre) {
    return this.clientHttp.post<InfoParamsNombre>(API_CATALOGS.SEARCH_PARAMS_ALL_NAMES, {
      nombreParametro,
    });
  }

  public findAllPermissionByProfile(consultarPermisos: ConsultarPermisos) {
    return this.clientHttp.post<PermisosPerfilResponse>(
      API.SEARCH_ALL_PERMS,
      consultarPermisos
    );
  }

  public findAllFunctionsByProfile(
    consultarFuncionalidad: ConsultarFuncionalidad
  ) {
    return this.clientHttp.post<PermissionFuncResponse>(
      API.SEARCH_PERMS_BY_FUNCTION,
      consultarFuncionalidad
    );
  }

  public findAllCatalogsByProfile() {
    return this.clientHttp.post<CatalogResponse>(API_CATALOGS.SEARCH_ALL_CATALOGS, {
      activo: true,
    });
  }

  public findCatalogByProfile() {
    return this.clientHttp.post<CatalogProductResponse>(
      API_CATALOGS.SEARCH_CATALOG_PAGE,
      {
        pagina: 1,
      }
    );
  }

  public findCatalogFlowByProfile() {
    return this.clientHttp.post<CatalogProductFlowResponse>(
      API_CATALOGS.SEARCH_CATALOG_TYPE_FLOW,
      {
        pagina: 1,
      }
    );
  }

  public findCatalogCanalByProfile() {
    return this.clientHttp.post<CanalResponse>(API_CATALOGS.SEARCH_CATALOG_CANAL, {});
  }

  public findCatalogCargoByProfile() {
    return this.clientHttp.post<CargoResponse>(API_CATALOGS.SEARCH_CATALOG_CARGO, {
      pagina: 1,
    });
  }

  public findCatalogOcupationByProfile() {
    return this.clientHttp.post<OcupationResponse>(
      API_CATALOGS.SEARCH_CATALOG_OCUPATION,
      {
        pagina: 1,
      }
    );
  }

  public findCatalogActivityByProfile() {
    return this.clientHttp.post<ActivityResponse>(API_CATALOGS.SEARCH_CATALOG_ACTIVITY, {
      pagina: 1,
    });
  }

  public findCatalogContractByProfile() {
    return this.clientHttp.post<ContractResponse>(API_CATALOGS.SEARCH_CATALOG_CONTRACT, {
      pagina: 1,
    });
  }

  public findCatalogStatementByProfile() {
    return this.clientHttp.post<StatementResponse>(
      API_CATALOGS.SEARCH_CATALOG_STATEMENT,
      {
        pagina: 1,
      }
    );
  }

  public findCatalogOfficeByProfile() {
    return this.clientHttp.post<OfficeResponse>(API_CATALOGS.SEARCH_CATALOG_OFFICE_ALL, {
      pagina: 1,
    });
  }

  public findCatalogOfficeZoneByProfile() {
    return this.clientHttp.post<ZoneResponse>(
      API_CATALOGS.SEARCH_CATALOG_OFFICE_ZONES,
      {}
    );
  }

  public findCatalogOfficeDepartmentByProfile() {
    return this.clientHttp.post<DepartmentResponse>(
      API_CATALOGS.SEARCH_CATALOG_OFFICE_DEPARTMENTS,
      {}
    );
  }

  /* public findCatalogOfficeCitiesByProfile() {
    return this.clientHttp.post<CitiesResponse>(
      API.SEARCH_CATALOG_OFFICE_CITIES,
      { idDepartamento: '68' }
    );
  } */

  public findCatalogOfficeCityByProfile(
    idDepartamento: InfoCatalogoOficinaDepartamento
  ) {
    return this.clientHttp.post<CitiesResponse>(
      API_CATALOGS.SEARCH_CATALOG_OFFICE_CITIES,
      idDepartamento
    );
  }

  public sendMessageMicroServiceWeb(traza: InfoTraza){
    return this.clientHttp.post<InfoTraza>(
      API.SEND_MESSAGE,
      traza
    );
  }

  public updatetraza(traza: InfoTraza){
    return this.clientHttp.post<InfoTraza>(
      API.UPDATE_TRAZA,
      traza
    );
  }
  public consultarParametrizacionReintento(body) { // borrar
    return this.clientHttp.post<any>(API.RETRY_PARAMETRIZATION,body);
   // return this.http.post<ParametrizationReintento[]>(API.RETRY_PARAMETRIZATION,body);
 };
}
