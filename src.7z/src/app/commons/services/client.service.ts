import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ClientService {
  public data = new BehaviorSubject<any>({});
  constructor() {}

  getData() {
    return this.data.asObservable();
  }

  setData(data: any) {
    this.data.next(data);
  }
}
