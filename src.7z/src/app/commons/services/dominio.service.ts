import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { API } from 'src/utils/endpoints';
import { DiaNoHabil, Microservicio } from '../models/index';

@Injectable({
  providedIn: 'root'
})
export class DominioService {

  constructor(private http: HttpClient) { }

   /**
   * Método para consultar el listado de microservicio
   * @param body 
   * @returns el listado de la parametrizacion de reintentos
   */
    public consultarMicroservicios(): Observable<Microservicio[]> { // cambiar el body por el objeto mapeado parametrizationReintento[]
      return this.http.post<any>(API.MICRO_SERVICIOS,{});
     // return this.http.post<Microservicio[]>(API.MICRO_SERVICIOS,body);
   };

  /**
   * Método para consultar las opciones de habil y calendario
   * @param body 
   * @returns el listado de dias
   */
      public consultarOpcionesDias(body): Observable<[DiaNoHabil]> { // cambiar el body por el objeto mapeado parametrizationReintento[]
        return this.http.post<any>(API.DIA,body);
       // return this.http.post<Microservicio[]>(API.MICRO_SERVICIOS,body);
     };
}
