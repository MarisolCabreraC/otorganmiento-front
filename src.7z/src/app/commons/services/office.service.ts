import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class OfficeService {
  public data = new BehaviorSubject<any>([]);
  constructor() {}

  getDataOffice() {
    return this.data.asObservable();
  }

  setDataOffice(data: any) {
    this.data.next(data);
  }

  getDataOfficeZone() {
    return this.data.asObservable();
  }

  setDataOfficeZone(data: any) {
    this.data.next(data);
  }

  getDataOfficeDepartment() {
    return this.data.asObservable();
  }

  setDataOfficeDepartment(data: any) {
    this.data.next(data);
  }

  getDataOfficeCity() {
    return this.data.asObservable();
  }

  setDataOfficeCity(data: any) {
    this.data.next(data);
  }
}
