import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { API } from 'src/utils/endpoints';
import { TraceInformation } from '../models/mvp2/traceInformation';

@Injectable({
  providedIn: 'root'
})
export class TraceService {

  constructor(private http: HttpClient) { }

  /**
   * Devuelve las trazas en estado reintento
   * @param obj 
   * @returns 
   */
  public consultTraceStatusRetry(obj): Observable<any> { 
    return this.http.post<any>(API.TRACE_MASSIVE_RETRY, obj);
  };

  /**
   * Enviar traza 
   * @param trace 
   * @returns 
   */
  public sendMessageTrace(trace:TraceInformation):Observable<TraceInformation>{
    return this.http.post<TraceInformation>( API.SEND_MESSAGE,trace);
  }

  /**
   * actualizar traza
   * @param trace 
   * @returns 
   */
  public updatetraza(trace: TraceInformation):Observable<TraceInformation> {
    return this.http.post<TraceInformation>( API.UPDATE_TRAZA, trace);
  }

  /**
   * Envia los reintentos para hacerlos masivamente
   */
  public retryMassive(traces: TraceInformation[]): Observable<any> {
    return this.http.post<any>( API.RETRY_MASSIVE_TRACES,traces);
  }
}
