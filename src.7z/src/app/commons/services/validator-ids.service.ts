/**
 * @ngdoc const
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Octubre 2020
 * @author jcastcor - para Banco Popular.
 * @description Fichero encargado de realizar la intercepcion de los errores html.
 */
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ValidationStateInterceptorService {
  public validationStates = new BehaviorSubject<any>({
    adminAccessBtns: true,
    editMenuOpt: true,
    catalogDetailColumn: true,
    adminProfileBtnMenu: true,
    fieldDetails: true,
    creditBtn: true,
    trazaBtn: true,
  });
  constructor() {}

  setValidationStates(validationStates: any) {
    this.validationStates.next(validationStates);
  }

  getValidationStates() {
    return this.validationStates.asObservable();
  }
}
