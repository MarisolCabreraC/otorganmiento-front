import { TestBed } from '@angular/core/testing';

import { ValidatorIdsService } from './validator-ids.service';

describe('ValidatorIdsService', () => {
  let service: ValidatorIdsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ValidatorIdsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
