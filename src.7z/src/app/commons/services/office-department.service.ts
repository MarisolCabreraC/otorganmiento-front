import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class DepartmentService {
  public data = new BehaviorSubject<any>([]);
  constructor() {}

  getDataDepartment() {
    return this.data.asObservable();
  }

  setDataDepartment(data: any) {
    this.data.next(data);
  }
}
