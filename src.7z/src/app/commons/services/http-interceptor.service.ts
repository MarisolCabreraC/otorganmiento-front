import { Injectable } from '@angular/core';
import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpErrorResponse,
} from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ERRORS } from '../../../utils/errors';
import { BehaviourInterceptorService } from './behaviour-interceptor.service';
/**
 * @ngdoc service
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Septiembre 2020
 * @author Everis Colombia - para Banco Popular.
 * @description Fichero encargado de realizar la interseccion de todas las intercepciones http de los
 * diferentes microservicios
 */
@Injectable({
  providedIn: 'root',
})
export class HttpErrorInterceptor implements HttpInterceptor {
  private httpErrorMsg = '';
  private isAlert: boolean;
  constructor(
    private router: Router,
    private behaviourSubject: BehaviourInterceptorService
  ) {}

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    const request = req;
    return next.handle(request).pipe(
      catchError((err: HttpErrorResponse) => {
        console.log("err",err);
        let codeError = 0;
        let smsError = '';

        if (err.status === 204) {
          // this.authService.logout();
          codeError = 204;
          smsError = ERRORS.ERROR_HTTP_204;
        }
        if (err.status >= 400 && err.status < 500 && err.status !== 404 && err.status !== 401) {
          // this.authService.logout();
          codeError = 400;
          smsError = ERRORS.ERROR_HTTP_400;
        }
        if (err.status === 401) {
          codeError = 401;
          smsError = ERRORS.ERROR_HTTP_401;
        }
        if (err.status === 404) {
          codeError = 404;
          smsError = ERRORS.ERROR_HTTP_404;
        }
        if (err.status >= 500 && err.status < 600) {
          codeError = 500;
          smsError = ERRORS.ERROR_HTTP_500;
        }
        
        if (err.message === 'Failed to stablished a backside connection') {
          codeError = 500;
          smsError = ERRORS.ERROR_SERVIDOR_COMMUNICATION1;
        }

        if (err.message === 'Failed to process response header') {
          codeError = 500;
          smsError = ERRORS.ERROR_SERVIDOR_COMMUNICATION2;
        }

        if (err.message === 'ERROR:could not execute statement SQL; nested exception') {
          codeError = 500;
          smsError = ERRORS.ERROR_SERVIDOR_COMMUNICATION3;
        }

        this.behaviourSubject.setData({
          smsError,
          isAlert: codeError !== 0,
        });
        return throwError(err);
      })
    );
  }
}
