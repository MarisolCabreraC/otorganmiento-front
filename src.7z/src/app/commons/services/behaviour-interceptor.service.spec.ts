import { TestBed } from '@angular/core/testing';

import { BehaviourInterceptorService } from './behaviour-interceptor.service';

describe('BehaviourInterceptorService', () => {
  let service: BehaviourInterceptorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BehaviourInterceptorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
