import { TestBed } from '@angular/core/testing';

import { ParametrizationReintentoService } from './parametrization-reintento.service';

describe('ParametrizationReintentoService', () => {
  let service: ParametrizationReintentoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ParametrizationReintentoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
