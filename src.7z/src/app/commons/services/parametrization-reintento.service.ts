import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { API } from 'src/utils/endpoints';
import { ParametrizationReintento } from '../models/index';

@Injectable({
  providedIn: 'root'
})
export class ParametrizationReintentoService {

  constructor(private http: HttpClient) { }

  /**
   * Método para consultar la parametrizacion de reintentos
   * @param body 
   * @returns el listado de la parametrizacion de reintentos
   */
  public consultarParametrizacionReintento(): Observable<ParametrizationReintento[]> { // cambiar el body por el objeto mapeado parametrizationReintento[]
    return this.http.post<any>(API.RETRY_PARAMETRIZATION, {});
    // return this.http.post<ParametrizationReintento[]>(API.RETRY_PARAMETRIZATION,body);
  };

  /**
   * 
   * @param parametrizacionReintento 
   * @returns 
   */
  public saveParametrizationRetry(parametrizacionReintento): Observable<any> {
    return this.http.post<any>(API.SAVE_PARAMETRIZATION, parametrizacionReintento);
  }

  public consultarParametrizacionReintentoPorId(parametrizacion): Observable<ParametrizationReintento> { // cambiar el body por el objeto mapeado parametrizationReintento[]
    console.log('servicio de consultar por id', parametrizacion);

    return this.http.post<any>(API.SEARCH_PARAMETRIZATION_ID, parametrizacion);
  };

  public editParametrization(parametrizacion): Observable<ParametrizationReintento> { 
    return this.http.post<any>(API.EDIT_PARAMETRIZATION, parametrizacion);
  };
}
