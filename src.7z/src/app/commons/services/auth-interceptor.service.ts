import { Injectable } from '@angular/core';
import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpErrorResponse,
} from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { MsalService } from '@azure/msal-angular';
import { MainService } from './main.service';
/**
 * @ngdoc service
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Julio 2020
 * @author Everis Colombia - para Banco Popular.
 * @description Fichero encargado de realizar la interseccion de todas las operaciones de los
 * diferentes microservicios
 */
@Injectable({
  providedIn: 'root',
})
export class AuthInterceptorService implements HttpInterceptor {
  constructor(private router: Router, private authService: MsalService, private servicio: MainService,) {}

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    let request = req;
    //se omite el endpoint de microsoft
    if (!req.url.includes('https://graph.microsoft.com')) {
      const token: string = localStorage.getItem('token');

      if (token) {
        request = req.clone({
          setHeaders: {
            authorization: `${token}`,
          },
        });
      }
    }
    //se valida si el error es de seguridad
    return next.handle(request).pipe(
      catchError((err: HttpErrorResponse) => {
        console.log(
          'Ha ocurrido un error.. ' +
            err.url +
            ' ' +
            err.status +
            ' ' +
            JSON.stringify(err.headers)
        );
        if (err.status === 401 && !err.url.includes('obtenerPermisos')) {
          //this.authService.logout();
          const requestObj = {
            scopes: ['user.read'],
          };
          this.authService
          .acquireTokenSilent(requestObj)
          .then((tokenResponse) => {            
            const userName = tokenResponse.account.userName;
            this.servicio
              .generateTokenAPI(userName, tokenResponse.accessToken)
              .subscribe((token1) => {
                localStorage.setItem('token', token1.token);
              });
          })
          .catch(function(error) {
              this.authService
                .acquireTokenSilent(requestObj)
                .then((tokenResponse) => {
                  const userName = tokenResponse.account.userName;
                  this.service
                    .generateTokenAPI(userName, tokenResponse.accessToken)
                    .subscribe((token2) => {
                      localStorage.setItem('token', token2.token);
                    });
                })
                .catch(function(error1) {
                    this.interval = setInterval(
                    this.getTokenSilent(requestObj),
                    3000
                  );
                });
            });        
        }
        return throwError(err);
      })
    );
  }
}
