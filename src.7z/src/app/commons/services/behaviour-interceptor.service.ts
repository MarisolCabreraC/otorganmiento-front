/**
 * @ngdoc const
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Septiembre 2020
 * @author jcastcor - para Banco Popular.
 * @description Fichero encargado de realizar la intercepcion de los errores html.
 */
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class BehaviourInterceptorService {
  public data = new BehaviorSubject<any>({});
  constructor() {}

  setData(data: any) {
    this.data.next(data);
  }

  getData() {
    return this.data.asObservable();
  }
}
