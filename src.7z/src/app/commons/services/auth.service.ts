import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  AccessToken = '';
  _url = '';

  constructor(private http: HttpClient) {}
  private TokenAPI = 'url';

  // login(Username: string, Password: string): Observable<TokenParams>{
  //     var headersForTokenAPI = new Headers({'Content-Type': 'application/x-www-form-urlencoded'});
  //     var data = 'grant_type=password&username=' + Username + "&password=" + Password;
  //     return this.http.post(this.TokenAPI, data, { headers: headersForTokenAPI }).map(res => res.json());
  // }
}
