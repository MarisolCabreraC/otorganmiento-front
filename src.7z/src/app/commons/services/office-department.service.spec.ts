import { TestBed } from '@angular/core/testing';

import { OfficeDepartmentService } from './office-department.service';

describe('OfficeDepartmentService', () => {
  let service: OfficeDepartmentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OfficeDepartmentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
