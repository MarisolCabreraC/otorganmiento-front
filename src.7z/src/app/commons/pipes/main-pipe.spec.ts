import { MainPipe } from './main.pipe';

describe('PipesPipe', () => {
  it('create an instance', () => {
    const pipe = new MainPipe();
    expect(pipe).toBeTruthy();
  });
});
