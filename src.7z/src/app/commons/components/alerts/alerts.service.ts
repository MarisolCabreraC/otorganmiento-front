
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Mesaage } from '@src/utils/message';
import Swal from 'sweetalert2';
@Injectable({
    providedIn: 'root'
  })
export class AlertService {

    constructor(private router: Router,){

    }

    alertError(err:any){

        Swal.fire({
            icon: 'error',
            title: 'Error',
            text : err,
            confirmButtonColor: '#00A80C',
            confirmButtonText: 'Aceptar'
        })

    }

   async alertConfirm(accion:string){
        let respuesta = false;
        switch(accion){
            case 'Guardar':
                await Swal.fire({
                    icon: 'warning',
                    title: Mesaage.GUARDAR_INFO,
                    confirmButtonColor : '#00A80C',
                    confirmButtonText: 'Aceptar',
                    cancelButtonText: 'Cancelar',
                    showCancelButton: true
                
                }).then((result) =>{
                    if(result.isConfirmed){
                      respuesta = true;
                      return respuesta
                    }
                } )
                break
            case 'Actualizar':
                await Swal.fire({
                    icon: 'warning',
                    title: Mesaage.ACTUALIZAR_INFO,
                    confirmButtonColor : '#00A80C',
                    confirmButtonText: 'Aceptar',
                    cancelButtonText: 'Cancelar',
                    showCancelButton: true
                }).then((result) =>{
                    if(result.isConfirmed){
                        respuesta = true;
                        return respuesta
                    }
                } )
                break
        }
       
        return respuesta;

    }
    alertSuccesMessage(accion:string,ruta:string){
        switch(accion){
            case 'Guardar':
                Swal.fire({
                    icon: 'success',
                    title: 'Guardado con éxito!',
                    confirmButtonColor : '#00A80C',
                    confirmButtonText: 'Aceptar',
                }).then(element =>{
                    this.router.navigate([ruta], { replaceUrl: true })
                })
                break
            case 'Actualizar':
                Swal.fire({
                    icon: 'success',
                    title: 'Actualizado con éxito!',
                    confirmButtonColor : '#00A80C',
                    confirmButtonText: 'Aceptar',
                }).then(element =>{
                    this.router.navigate([ruta], { replaceUrl: true })
                })
                break
        }
    


    }

}