import { Component, OnInit, Input } from '@angular/core';
import { IButton } from 'src/app/commons/interfaces/interfaces';
import { SafeStyle, DomSanitizer } from '@angular/platform-browser';
@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss'],
})
export class ButtonComponent implements OnInit {
  @Input() button: IButton;
  @Input() profile: string;
  public icon: SafeStyle;

  constructor(private sanitizer: DomSanitizer) {}

  ngOnInit(): void {
    this.icon = this.sanitizer.bypassSecurityTrustStyle(
      'url( \'../../../../../../../assets/icons/' + this.button.icon + '\')'
    );
  }
}
