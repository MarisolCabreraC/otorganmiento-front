import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-validators',
  templateUrl: './validators.component.html',
  styleUrls: ['./validators.component.scss']
})
export class ValidatorsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
