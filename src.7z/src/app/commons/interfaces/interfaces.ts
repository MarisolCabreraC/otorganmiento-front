export interface Interfaces {}

export interface IButton {
  active: boolean;
  icon: string;
  name: string;
  route: string;
}
