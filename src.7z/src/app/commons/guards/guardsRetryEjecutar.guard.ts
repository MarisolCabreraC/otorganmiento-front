import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree,
  Router,
} from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class RetryExecuteGuard implements CanActivate {
  constructor(private router: Router){}
// para reintento ejecucion
  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot  ):
    | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      // console.log('Entra guard reintento ejecucion evalua menuReintentoEjecucion',localStorage.getItem('menuReintentoEjecucion'));
      
      if (localStorage.getItem('menuReintentoEjecucion') === 'true') {
        return true;
      } else {
        this.router.navigateByUrl('/home/no-permitido', {skipLocationChange: true}).then(() =>
        this.router.navigate(['/home/no-permitido']));
        return false;
      }
    }
}
