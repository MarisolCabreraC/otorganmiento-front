export class ConsultarFicha {
    public solicitud: string;
}