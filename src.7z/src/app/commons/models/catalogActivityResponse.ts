import { InfoCatalogoActividad } from './infoCatalogoActividad';

export class ActivityResponse {
  public registros: InfoCatalogoActividad[];
}
