import { InfoCatalogoFestivo } from './infoCatalogoFestivo';

export class FestiveResponse {
  public registros: InfoCatalogoFestivo[];
}