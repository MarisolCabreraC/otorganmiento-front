export class InfoCatalogo {
  public idEtapa: number;
  public nombre: string;
}
