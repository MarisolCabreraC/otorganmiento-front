import { SolicitudDetail } from './solicitudDetail';

/**
 * @ngdoc class
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Nov 2020
 * @author jcastcor - Everis Colombia - para Banco Popular.
 * @description Fichero encargado representar la entidad Solicitud por cliente.
 */
export class SolicitudPerClient {
  public solicitudes: SolicitudDetail[];
}
