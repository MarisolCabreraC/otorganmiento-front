
export interface Microservicio {
  idMicroServicio: string;
  nombreMicroServicio: string;  
  valor: string;
}
