export class InfoCatalogoProfesion {
  public idProfesion: number;
  public nombre: string;
  public usuario?: string;
  public activo?: boolean;
}
