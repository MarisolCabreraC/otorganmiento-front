import { InfoCatalogoContrato } from './infoCatalogoContracto';

export class ContractResponse {
  public registros: InfoCatalogoContrato[];
}
