export class InfoMotor {
    public decisionMotor: string;
    public reglaMotor: string;
    public causalMotor: string;
    public montoLimitePolitica: number;
    public subcausales: string[]
}