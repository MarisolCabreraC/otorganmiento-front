export class InfoCatalogoActividad {
  public idActividadEconomica: number;
  public nombre: string;
  public activo?: boolean;
}
