export class ConsultarCatalogoOficina {
  public pagina: number;
}
