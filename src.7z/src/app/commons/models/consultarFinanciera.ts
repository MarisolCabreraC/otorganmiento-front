export class ConsultarFinanciera {
  public numeroSolicitud: number;
}
