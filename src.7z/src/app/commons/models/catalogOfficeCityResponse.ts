import { InfoCatalogoOficinaCiudad } from './infoCatalogoOficinaCiudad';

export class CitiesResponse {
  public registros: InfoCatalogoOficinaCiudad[];
}
