export class InfoCatalogoSector {
  public idSectorEmpresa: string;
  public nombre: string;
  public usuario?: string;
  public activo?: boolean;
}
