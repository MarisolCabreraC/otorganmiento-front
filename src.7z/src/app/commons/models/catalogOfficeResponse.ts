import { InfoCatalogoOficina } from './infoCatalogoOficina';

export class OfficeResponse {
  public registros: InfoCatalogoOficina[];
}
