export class ConsultarTraza {
  public numeroSolicitud: number;
  public operador?: string;
  public solicitudADL?: number;
}
