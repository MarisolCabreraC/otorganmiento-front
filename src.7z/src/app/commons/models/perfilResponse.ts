import { Perfil } from './perfil';
/**
 * @ngdoc class
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Julio 2020
 * @author yquintana - Everis Colombia - para Banco Popular.
 * @description Fichero encargado representar la entidad PerfilResponse.
 */
export class PerfilResponse {
  public contenido: Perfil[];
  public totalPaginas: number;
  public totalRegistros: number;
}
