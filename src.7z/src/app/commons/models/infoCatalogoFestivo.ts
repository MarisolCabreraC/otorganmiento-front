/**
 * Entidad que mapea la informacion obtenida del microservicio de festivos
 */
export class InfoCatalogoFestivo {
    /**
     * Identificador del dia festivo
     */
    public idDiaNoHabil: number;
    /**
     * Dia festivo
     */
    public dia?: string;
    /**
     * Descripcion del dia festivo
     */
    public descripcion?: string;
    /**
     * Estado del dia (activo o inactivo)
     */
    public activo?: boolean;
}