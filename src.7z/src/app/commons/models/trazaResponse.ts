import { InfoTraza } from './infoTraza';

export class TrazaResponse {
  public trazabilidad: InfoTraza[];
}
