export class InfoCatalogoContrato {
  public idTipoContrato: string;
  public nombre: string;
  public activo?: boolean;
}
