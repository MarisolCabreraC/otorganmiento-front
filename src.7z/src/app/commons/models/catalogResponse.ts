import { InfoCatalogoParam } from './infoCatalogoParams';

export class CatalogResponse {
  public catalogos: InfoCatalogoParam[];
}
