/**
 * @ngdoc class  
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Julio 2020
 * @author yquintana - Everis Colombia - para Banco Popular.
 * @description Fichero encargado representar la entidad Funcionalidad
 */
export class Funcionalidad {
  public id?: number;
  public nombre: string;
  public url: string;
  public lectura: boolean;
  public escritura: boolean;
}
