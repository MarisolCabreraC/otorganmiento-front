export class InfoFinancialEnty {
    public idEntidadFinanciera: number;
    public nombre: string;
    public numeroIdentificacion: number;
    public idCartera : number;
    public activo?: number;
  }
  