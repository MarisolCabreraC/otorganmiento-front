export class InfoCatalogoOficinaCiudad {
  public idCiudad: string;
  public idDepartamento: string;
  public nombre: string;
}
