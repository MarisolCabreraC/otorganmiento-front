export class InfoPermisos {
  idPerfil: string;
  nombrePerfil: string;
  accesos: [
    {
      idAcceso: number;
      idFuncionalidad: number;
      nombreFuncionalidad: string;
      url: string;
      lectura: string;
      escritura: string;
    }
  ];
}
