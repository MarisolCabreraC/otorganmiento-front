export class ConsultarCatalogoProducto {
  public pagina: number;
}
