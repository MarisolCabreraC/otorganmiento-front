import { InfoCatalogoOficinaZona } from './infoCatalogoOficinaZona';

export class ZoneResponse {
  public registros: InfoCatalogoOficinaZona[];
}
