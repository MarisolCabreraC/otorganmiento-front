export class InfoCatalogoOficina {
  public activo?: boolean;
  public idCiudad: string;
  public idCrm: string;
  public idDepartamento: string;
  public idOficina: number;
  public idZona: number;
  public nombreCiudad: string;
  public nombreDepartamento: string;
  public nombreOficina: string;
  public nombreZona: string;
}
