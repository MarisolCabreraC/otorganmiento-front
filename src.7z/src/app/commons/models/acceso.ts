import { Funcionalidad } from './funcionalidad';
/**
 * @ngdoc class
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Julio 2020
 * @author yquintana - Everis Colombia - para Banco Popular.
 * @description Fichero encargado  representar la entidad Acceso
 */
export class Acceso {
  public id: string;
  public nombre: string;
  public funcionalidades: Funcionalidad[];
}
