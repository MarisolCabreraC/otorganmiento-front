export class ConsultarCatalogo {
  public id: string;
  public nombre: string;
}
