import { InfoCatalogoCargo } from './infoCatalogoCargo';

export class CargoResponse {
  public registros: InfoCatalogoCargo[];
}
