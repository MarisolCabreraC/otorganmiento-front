export class ConsultarFuncionalidad {
  public idPerfil: number;
}
