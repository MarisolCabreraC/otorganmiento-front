export class ConsultarLaboral {
  public id: number;
}
