import { InfoCatalogoProducto } from './infoCatalogoProducto';

export class CatalogProductResponse {
  public registros: InfoCatalogoProducto[];
}
