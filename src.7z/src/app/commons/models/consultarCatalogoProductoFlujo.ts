export class ConsultarCatalogoProductoFlujo {
  public pagina: number;
}
