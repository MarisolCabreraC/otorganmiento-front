import { InfoCatalogoOcupation } from './infoCatalogoOcupation';

export class OcupationResponse {
  public registros: InfoCatalogoOcupation[];
}
