/**
 * @ngdoc class
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Julio 2020
 * @author yquintana - Everis Colombia - para Banco Popular.
 * @description Fichero encargado representar la entidad Perfil.
 */
export class Perfil {
  public idPerfil: number;
  public codigoDa: string;
  public nombre: string;
  public activo: boolean;
  public escritura?: boolean;
  public lectura?: boolean;
}
