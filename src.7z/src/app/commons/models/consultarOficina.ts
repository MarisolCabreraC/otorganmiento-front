export class ConsultarOficina {
  public id: string;
}
