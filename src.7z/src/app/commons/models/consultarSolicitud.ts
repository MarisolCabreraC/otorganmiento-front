export class ConsultarSolicitud {
  public numeroSolicitud: string;
}
