export class Oficina {
  public idCrm: string;
  public nombre: string;
  public idZona: number;
}
