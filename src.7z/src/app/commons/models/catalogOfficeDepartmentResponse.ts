import { InfoCatalogoOficinaDepartamento } from './infoCatalogoOficinaDepartamento';

export class DepartmentResponse {
  public registros: InfoCatalogoOficinaDepartamento[];
}
