export class ConsultarCatalogoParam {
  activo: boolean;
}
