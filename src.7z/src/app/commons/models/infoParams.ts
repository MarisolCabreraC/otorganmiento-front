export class InfoParams {
  public idParametro: number;
  public nombre: string;
  public valor: number;
  public descripcion: string;
}
