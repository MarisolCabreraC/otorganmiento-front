import { Solicitud } from './solicitud';
import { Cliente } from './cliente';
import { SolicitudDetail } from './solicitudDetail';
/**
 * @ngdoc class
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Julio 2020
 * @author yquintana - Everis Colombia - para Banco Popular.
 * @description Fichero encargado representar la entidad SolicitudResponse.
 */
export class SolicitudResponse {
  public nombreCliente: string;
  public apellidoCliente: string;
  public tipoIdCliente: string;
  public idCliente: string;
  public rolCliente: string;
  //objeto de cliente
  public cliente: Cliente;
  public solicitudActual: SolicitudDetail;
  public solicitudes: Solicitud[];
  public solicitudDetails: SolicitudDetail[];
  public totalPaginas: number;
  public totalRegistros: number;
}
