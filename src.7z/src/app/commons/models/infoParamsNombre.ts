export class InfoParamsNombre {
  public idParametro: string;
  public descripcion: string;
  public nombre: string;
  public valor: string;
}
