export class InfoCatalogoOficinaDepartamento {
  public idDepartamento: string;
  public idPais: number;
  public nombre: string;
}
