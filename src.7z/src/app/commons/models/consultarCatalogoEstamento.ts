export class ConsultarCatalogoEstamento {
  public pagina: number;
}
