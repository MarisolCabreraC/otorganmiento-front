export class InfoCatalogoOficinaZona {
  public idRegional: number;
  public idZona: number;
  public nombre: string;
}
