export class ConsultarCatalogoContrato {
  public pagina: number;
}
