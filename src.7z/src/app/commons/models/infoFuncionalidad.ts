export class InfoFuncionalidad {
  idFuncionalidad: number;
  idPerfil: string;
  lectura: boolean;
  escritura: boolean;
}
