export class ConsultarCanal {
  public pagina: number;
}
