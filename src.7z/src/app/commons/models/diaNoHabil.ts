export interface DiaNoHabil {
  idDiaNoHabil: string;
  dia: any;  
}
