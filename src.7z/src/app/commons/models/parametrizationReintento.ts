 

export interface ParametrizationReintento {
  idParametroReintento: string;
  idMicroServicio: string;  
  microServicio: string;
  reintento: string;
  restriccionInicio: string;
  restriccionFin: string;
  restriccionDia: string;
  intervalo: string;
}
