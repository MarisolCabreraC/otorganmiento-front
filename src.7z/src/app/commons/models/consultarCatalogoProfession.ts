export class ConsultarCatalogoProfesion {
  public pagina: number;
}
