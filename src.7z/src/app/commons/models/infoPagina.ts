export class InfoPagina {
  public idParametro: number;
  public nombre: string;
  public valor: number;
  public descripcion: string;
}
