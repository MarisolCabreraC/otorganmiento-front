export class InfoCatalogoParam {
  idMenuCatalogo: number;
  nombre: string;
  ubicacion: string;
}
