export class InfoLaboral {
  public idCliente: number;
  public cargo: string;
  public tipoContrato: string;
  public nitEmpresa: string;
  public empresa: string;
  public telefonoEmpresa: number;
  public antiguedad: number;
  public sectorEmpresa: string;
}
