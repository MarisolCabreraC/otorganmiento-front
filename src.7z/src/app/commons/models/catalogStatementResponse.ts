import { InfoCatalogoEstamento } from './infoCatalogoEstamento';

export class StatementResponse {
  public registros: InfoCatalogoEstamento[];
}
