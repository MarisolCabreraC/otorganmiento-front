export class ConsultarCatalogoSector {
  public pagina: number;
}
