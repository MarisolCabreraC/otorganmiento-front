export class Ficha {
  public metadadata: string;
  public solicitud: string;
}
