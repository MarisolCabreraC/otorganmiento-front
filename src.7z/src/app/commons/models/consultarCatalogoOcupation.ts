export class ConsultarCatalogoOcupation {
  public pagina: number;
}
