import { InfoCatalogoProductoFlujo } from './infoCatalogoProductoFlujo';

export class CatalogProductFlowResponse {
  public registros: InfoCatalogoProductoFlujo[];
}
