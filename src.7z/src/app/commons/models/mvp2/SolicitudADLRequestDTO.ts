export interface SolicitudADLRequestDTO { //  existe dos objetos con el mismo nombre la diferencia es que una es clase otra interface
  formaDesembolso: string;
  
  // los de abajo son copy paste no se si se usan 10 mayo 21
  antiguedadLaboral: number;
  apellidosCliente: String;
  canalVenta: number;
  cargo: number;
  causalMotor: String;
  cedulaFuncionarioAprueba: number;
  cedulaFuncionarioRadica: String;
  cicloFacturacion: number;
  claseGarantia: number;
  cuotaCredito: number;
  cuotasContingentesObligacionesComprar: number;
  cuotasSectorFinanciero: number;
  decisionADL: number;
  decisionMotor: number;
  departamentoResidencia: number;
  direccionResidencia: String;
  edadCliente: number;
  endeudamientoInternoConsumo: number;
  endudamientoInternoConsumoVivienda: number;
  entidadFinanciera: number;
  
  envioCorrespondencia: String;
  
  esSujetoLibranza: String;
  
  estadoCivil: String;
  
  estamentoDecisor: number;
  
  etapaFlujo: number;
  
  experienciaFinanciera: String;
  
  exposicionMaxima: number;
  
  fechaDecisionADL: Date;
  
  fechaNacimiento: Date;
  
  fechaRadicacion: Date;
  
  fechaVinculacionBanco: Date;
  
  gastosFamiliares: number;
  
  gastosFinancieros: number;
  
  ibcPromedio: number;
  
  idCliente: number;
  
  idSolicitud: String;
  
  idTransaccion: String;
  
  ingresoAdicional1: number;
  
  ingresoAdicional2: number;
  
  ingresoPrincipal: number;
  
  ingresosAdicionales: number;
  
  ingresoTotal: number;
  
  ingresoTotalSMMLV: number;
  
  inicioVigenciaDecision: Date;
  
  modalidadCredito: number;
  
  modalidadTasaInteres: number;
  
  montoLimitePolitica: number;
  
  nitEmpresaLabora: String;
  
  nivelEstudio: number;
  
  nombreClaseGarantia: String;
  
  nombreCliente: String;
  
  nombreEmpresa: String;
  
  nombreFuncionarioAprueba: String;
  
  numeroCuenta: String;
  
  numeroDocumentoDecisor: number;
  
  numeroIdentificacionCliente: String;
  
  ocupacion: String;
  
  oficinaDesembolso: String;
  
  oficinaVenta: String;
  
  pdi: number;
  
  periodicidadTasaInteres: number;
  
  personasACargo: number;
  
  piDefinitiva: number;
  
  plazoAprobado: number;
  
  plazoSolicitado: number;
  
  producto: number;
  
  profesion: number;
  
  puntajeAcierta: number;
  
  reglaMotor: String;
  
  rolTitularidad: number;
  
  salarioBasico: number;
  
  saldoSectorFinanciero: number;
  
  sarcMaxAltMora12M: number;
  
  sarcMaxAltMoras3M: number;
  
  sarcNoMora30D: number;
  
  sarcNoMoras90D: number;
  
  sectorEmpresa: String;
  
  sexo: String;
  
  solicitudADL: String;
  
  subCausalMotor: String;
  
  tasaInteres: number;
  
  telefonoEmpresa: String;
  
  tipoContrato: String;
  
  tipoCuenta: number;
  
  tipoDocumentoDecisor: number;
  
  tipoFlujo: number;
  
  tipoIdentificacionCliente: number;
  
  tipoPagare: number;
  
  tipoTasaInteres: number;
  
  tipoVivienda: String;
  
  unidadTiempoCredito: number;
  
  valorAprobado: number;
  
  valorSolicitado: number;
  
  nombreTipoIdentificacionCliente: String;
  
  descripcionGarantia: String;
  
  numeroGarantia: number;
}
