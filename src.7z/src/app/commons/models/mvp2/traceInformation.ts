import {SolicitudADLRequestDTO} from './SolicitudADLRequestDTO';

export interface TraceInformation {  
  idTraza: number;
  numeroSolicitud?: string;
  solicitudAdl?: string;
  fecha?: string;
  nombreEtapaFlujo?: string;
  estado?: string;
  numeroIntento?: number;
  detalle?: string;
  mensaje?: SolicitudADLRequestDTO;
  checked?: boolean;
  tipoReintento?: string;
  reintento?: boolean;
  usuarioEjecucion? : string;
}
