import { InfoFinancialEnty } from './infoFinancialEntity';

export class financialEntity {
  public registros: InfoFinancialEnty[];
}
