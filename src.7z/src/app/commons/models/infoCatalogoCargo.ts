export class InfoCatalogoCargo {
  public idCargo: number;
  public nombre: string;
  public usuario?: string;
  public activo?: boolean;
}
