export class InfoCanal {
  public idCanalVenta: number;
  public nombre: string;
  public activo?: boolean;
}
