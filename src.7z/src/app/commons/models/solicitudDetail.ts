/**
 * @ngdoc class
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Julio 2020
 * @author yquintana - Everis Colombia - para Banco Popular.
 * @description Fichero encargado representar los de detalles de solicitud.
 */
export class SolicitudDetail {
  public numeroSolicitud: string;
  public numeroSolicitudADL: number;
  public fechaRadicacionADL: string;
  public idCliente: number;
  public tipoFlujo: string;
  public etapaFlujo: string;
  public producto: string;
  public decisionADL: string;
  public idCanalVenta: number;
  public nombreCanalVenta: string;
  public idOficinaVenta: string;
  public idOficinaDesembolso: string;
  public cedulaFuncionarioRadica: string;
  public rolTitularidad: string;
  public valorSolicitado: number;
  public valorAprobado: number;
  public esSujetoLibraza: boolean;
  //campos nuevos
  public fechaDecisionADL: string;
  public fechaInicioVigencia: string;
  public puntajeAcierta: number;
  public exposicionMaxima: number;
  public plazoSolicitado: number;
  public plazoAprobado: number;
  public tasaInteres: number;
  public cicloFacturacion: number;
  public cuotaCredito: number;
  public tipoDocumentoDecisor: string;
  public nombreFuncionarioAprueba: string;
  public estamentoDecisor: string;
  public numeroDocumentoDecisor: string;
  public sarcNoMora90D: number;
  public sarcMaxAltMora3M: number;
  public sarcNoMora30D: number;
  public sarcMaxAltMora12M: number;
  public idParametro: number;
  public nombreOficinaDesembolso: string;
  public nombreOficinaVenta: string;
}
