/**
 * @ngdoc class
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Julio 2020
 * @author yquintana - Everis Colombia - para Banco Popular.
 * @description Fichero encargado representar la entidad cliente.
 */
export class Cliente {
  public idCliente: number;
  public tipoIdentificacion: string;
  public numeroIdentificacion: string;
  public ocupacion: string;
  public profesion: string;
  public actividadEconomica: string;
  public nombres: string;
  public apellidos: string;
  public edad: number;
  public fechaNacimiento: string;
}
