export class ConsultarCatalogoCargo {
  public pagina: number;
}
