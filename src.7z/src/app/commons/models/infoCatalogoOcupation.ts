export class InfoCatalogoOcupation {
  public idOcupacion: string;
  public nombre: string;
  public activo?: boolean;
  public codigoSarc: number;
}
