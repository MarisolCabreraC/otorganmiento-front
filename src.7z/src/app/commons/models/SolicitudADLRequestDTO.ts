export class SolicitudADLRequestDTO{

    public actividadEconomica: number;

    public antiguedadLaboral: number;
    
    public apellidosCliente: String;
    
    public canalVenta: number;
    
    public cargo: number;
    
    public causalMotor: String;
    
    public cedulaFuncionarioAprueba: number;
    
    public cedulaFuncionarioRadica: String;
    
    public cicloFacturacion: number;
    
    public claseGarantia: number;
    
    public cuotaCredito: number;
    
    public cuotasContingentesObligacionesComprar: number;
    
    public cuotasSectorFinanciero: number;
    
    public decisionADL: number;
    
    public decisionMotor: number;
    
    public departamentoResidencia: number;
    
    public direccionResidencia: String;
    
    public edadCliente: number;
    
    public endeudamientoInternoConsumo: number;
    
    public endudamientoInternoConsumoVivienda: number;
    
    public entidadFinanciera: number;
    
    public envioCorrespondencia: String;
    
    public esSujetoLibranza: String;
    
    public estadoCivil: String;
    
    public estamentoDecisor: number;
    
    public etapaFlujo: number;
    
    public experienciaFinanciera: String;
    
    public exposicionMaxima: number;
    
    public fechaDecisionADL: Date;
    
    public fechaNacimiento: Date;
    
    public fechaRadicacion: Date;
    
    public fechaVinculacionBanco: Date;
    
    public formaDesembolso: String;
    
    public gastosFamiliares: number;
    
    public gastosFinancieros: number;
    
    public ibcPromedio: number;
    
    public idCliente: number;
    
    public idSolicitud: String;
    
    public idTransaccion: String;
    
    public ingresoAdicional1: number;
    
    public ingresoAdicional2: number;
    
    public ingresoPrincipal: number;
    
    public ingresosAdicionales: number;
    
    public ingresoTotal: number;
    
    public ingresoTotalSMMLV: number;
    
    public inicioVigenciaDecision: Date;
    
    public modalidadCredito: number;
    
    public modalidadTasaInteres: number;
    
    public montoLimitePolitica: number;
    
    public nitEmpresaLabora: String;
    
    public nivelEstudio: number;
    
    public nombreClaseGarantia: String;
    
    public nombreCliente: String;
    
    public nombreEmpresa: String;
    
    public nombreFuncionarioAprueba: String;
    
    public numeroCuenta: String;
    
    public numeroDocumentoDecisor: number;
    
    public numeroIdentificacionCliente: String;
    
    public ocupacion: String;
    
    public oficinaDesembolso: String;
    
    public oficinaVenta: String;
    
    public pdi: number;
    
    public periodicidadTasaInteres: number;
    
    public personasACargo: number;
    
    public piDefinitiva: number;
    
    public plazoAprobado: number;
    
    public plazoSolicitado: number;
    
    public producto: number;
    
    public profesion: number;
    
    public puntajeAcierta: number;
    
    public reglaMotor: String;
    
    public rolTitularidad: number;
    
    public salarioBasico: number;
    
    public saldoSectorFinanciero: number;
    
    public sarcMaxAltMora12M: number;
    
    public sarcMaxAltMoras3M: number;
    
    public sarcNoMora30D: number;
    
    public sarcNoMoras90D: number;
    
    public sectorEmpresa: String;
    
    public sexo: String;
    
    public solicitudADL: String;
    
    public subCausalMotor: String;
    
    public tasaInteres: number;
    
    public telefonoEmpresa: String;
    
    public tipoContrato: String;
    
    public tipoCuenta: number;
    
    public tipoDocumentoDecisor: number;
    
    public tipoFlujo: number;
    
    public tipoIdentificacionCliente: number;
    
    public tipoPagare: number;
    
    public tipoTasaInteres: number;
    
    public tipoVivienda: String;
    
    public unidadTiempoCredito: number;
    
    public valorAprobado: number;
    
    public valorSolicitado: number;
    
    public nombreTipoIdentificacionCliente: String;
    
    public descripcionGarantia: String;
    
    public numeroGarantia: number;
}