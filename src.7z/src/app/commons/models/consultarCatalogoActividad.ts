export class ConsultarCatalogoActividad {
  public pagina: number;
}
