import { InfoCatalogoSector } from './infoCatalogoSector';

export class SectorResponse {
  public registros: InfoCatalogoSector[];
}
