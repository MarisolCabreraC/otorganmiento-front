export class ConsultarParamsNombre {
  public nombreParametro: string;
}
