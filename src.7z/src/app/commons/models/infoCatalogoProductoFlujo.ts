export class InfoCatalogoProductoFlujo {
  public idFlujo: number;
  public nombre: string;
  public activo?: boolean;
}
