export class InfoCatalogoProducto {
  public abreviatura: string;
  public activo: boolean;
  public idLineaCreditoSarc: number;
  public idModalidadSarc: string;
  public idProducto: number;
  public idSarc: string;
  public idTipoPrestamoGar: string;
  public indicador: number;
  public nombre: string;
  public orden: number;
  public plazoMaxMeses: number;
  public tipoOperacion: string;
  public utilizacion: number;
}
