export class ConsultarPagina {
  public pagina: number;
}
