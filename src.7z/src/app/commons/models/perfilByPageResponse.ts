import { Perfil } from './perfil';
/**
 * @ngdoc class
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Septiembre 2020
 * @author jcastcor - Everis Colombia - para Banco Popular.
 * @description Fichero encargado representar la entidad PerfilByPageResponse.
 */
export class PerfilByPageResponse {
  public contenido: Perfil[];
  public activo: boolean;
  public pagina: number;
}
