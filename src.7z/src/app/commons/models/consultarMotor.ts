export class ConsultarMotor {
    public idSolicitud: number;
}