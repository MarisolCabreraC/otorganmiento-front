export class InfoFinanciera {
  public numeroSolicitud: number;
  public salarioBasico: number;
  public ibcPromedio: number;
  public ingresoPrincipal: number;
  public ingresoAdicional1: number;
  public ingresoAdicional2: number;
  public ingresosAdicionales: number;
  public ingresoTotal: number;
  public ingresoTotalSMMLV: number;
  public gastosFamiliares: number;
  public cuotasSectorFinanciero: number;
  public gastosFinancieros: number;
  public cuotasContingentesObligacionesComprar: number;
  public experienciaFinanciera: boolean;
}
