import { InfoPagina } from './infoPagina';
/**
 * @ngdoc class
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Sep 2020
 * @author jcastcor - Everis Colombia - para Banco Popular.
 * @description Fichero encargado representar la entidad PerfilResponse.
 */
export class PaginaResponse {
  public contenido: InfoPagina[];
}
