export class ConsultarParams {
  public idParametro: number;
}
