export class ConsultarCliente {
  public idCliente: number;
  public numeroIdentificacion: string;
}
