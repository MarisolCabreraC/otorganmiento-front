import { SolicitudDetail } from './solicitudDetail';

/**
 * @ngdoc class  
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Julio 2020
 * @author yquintana - Everis Colombia - para Banco Popular.
 * @description Fichero encargado representar la entidad Solicitud.
 */
export class Solicitud {
  public numeroSolicitud: string;
  public rolCliente: string;
  public estadoSolicitud: string;
  public valorSolicitado: number;
  public valorAprobado: number;
  public fechaSolicitud: string;
  public producto: string;
  //YQ
  public detalle: SolicitudDetail;
}
