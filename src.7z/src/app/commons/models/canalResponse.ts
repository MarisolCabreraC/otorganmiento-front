import { InfoCanal } from './infoCanal';

export class CanalResponse {
  public registros: InfoCanal[];
}
