import { InfoPermisos } from './infoPermisos';

export class PermisosPerfilResponse {
  public contenido: InfoPermisos[];
}
