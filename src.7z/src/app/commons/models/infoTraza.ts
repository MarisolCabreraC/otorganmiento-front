import { SolicitudADLRequestDTO } from './SolicitudADLRequestDTO';

export class InfoTraza {
  public idTraza: number;
  public numeroSolicitud: number;
  public solicitudAdl: number;
  public idEtapaFlujo: number;
  public usuarioEjecucion: string;
  public estado: string;
  public fecha: string;
  public detalle: string;
  public nombreEtapaFlujo: string;
  public mensaje: SolicitudADLRequestDTO;
  public tipoReintento: string;
}
