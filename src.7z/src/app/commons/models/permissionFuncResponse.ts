import { InfoFuncionalidad } from './infoFuncionalidad';

export class PermissionFuncResponse {
  public acceso: InfoFuncionalidad[];
}
