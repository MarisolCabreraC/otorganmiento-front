import { InfoCatalogoProfesion } from './infoCatalogoProfession';

export class ProfessionResponse {
  public registros: InfoCatalogoProfesion[];
}
