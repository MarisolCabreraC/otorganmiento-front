export class ConsultarPermisos {
  public idPerfil: number;
}
