export class InfoCatalogoEstamento {
  public abreviatura: string;
  public articulo: boolean;
  public idEstamento: number;
  public montoMaximo: number;
  public montoMinimo: number;
  public nombre: string;
  public activo?: boolean;
}
