import { Component } from '@angular/core';
import { SpinnerService } from '@src/app/commons/services/spinner.service';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-spinner',
  template: `
    <ngx-spinner *ngIf="isLoading$ | async" bdColor = "rgba(0, 0, 0, 0.8)" size = "medium" color = "#fff" type = "timer" [fullScreen] = "true"><p style="color: white" > Cargando... </p></ngx-spinner>
  `,
  styles: ['']
})
export class SpinnerComponent {

  isLoading$ = this.spinnerService.isLoading$;

  constructor(private spinnerService: SpinnerService) { }

}
