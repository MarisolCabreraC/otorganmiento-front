import { Component, OnInit, Input } from '@angular/core';
import { MainService } from 'src/app/commons/services/main.service';
import { HttpClient } from '@angular/common/http';
import { URL_API_EXTERNAL } from 'src/utils/constants';
import { MsalService } from '@azure/msal-angular';

@Component({
  selector: 'app-avatar-card',
  templateUrl: './avatar-card.component.html',
  styleUrls: ['./avatar-card.component.scss'],
  providers: [MainService],
})
export class AvatarCardComponent implements OnInit {
  @Input() insideBar: boolean;
  public nombrePerfil: string;
  public idProfiles: string[];
  public name: string;
  public contractionName: string;
  private userName: string;
  public interval: any;
  constructor(
    private service: MainService,
    private https: HttpClient,
    private authService: MsalService
  ) { }

  ngOnInit(): void {
    const token: string = localStorage.getItem('token');
    if (token) {
      this.getProfile();
    } else {
      const requestObj = {
        scopes: ['user.read'],
      };
      this.authService
        .acquireTokenSilent(requestObj)
        .then((tokenResponse) => {
          const userName = tokenResponse.account.userName;
          this.service
            .generateTokenAPI(userName, tokenResponse.accessToken)
            .subscribe((token1) => {
              localStorage.setItem('token', token1['token']);
              localStorage.setItem('usuarioFront', userName);
              console.log("AQUI GUARDA USUARIO LINEA 44",userName)
              this.getProfile();
            });
        })
        .catch(function(error1) {
          console.log('[avatar-card] Error Otorgamiento 2.0 intento 1. ' + error1);
          this.authService
            .acquireTokenSilent(requestObj)
            .then((tokenResponse) => {
              const userName = tokenResponse.account.userName;
              this.service
                .generateTokenAPI(userName, tokenResponse.accessToken)
                .subscribe((token2) => {
                  localStorage.setItem('token', token2['token']);
                  this.getProfile();
                });
            })
            .catch(function(error2) {
              console.log('[avatar-card] Error Otorgamiento 2.0 intento 2)' + error2);
              console.log('[avatar-card] Iniciando hilo de reintento ...');
              this.interval = setInterval(this.getTokenSilent(requestObj), 3000);
            });
        });
    }
  }


  public getTokenSilent(requestObj) {
    this.authService
      .acquireTokenSilent(requestObj)
      .then((tokenResponse) => {
        let userName = tokenResponse.account.userName;
        this.service
          .generateTokenAPI(userName, tokenResponse.accessToken)
          .subscribe((token) => {
            localStorage.setItem('token', token['token']);
            localStorage.setItem('usuarioFront', userName);
            console.log("AQUI GUARDA USUARIO LINEA 80",userName)
            this.getProfile();
          });
        console.log('[avatar-card] Fin hilo de reintento, proceso exitoso.');
        clearInterval(this.interval);
      })
      .catch(function (error) {
        console.log('[avatar-card] Error en metodo recursivo' + error);

      });

  }

  public findPermissionByProfile() {
    this.service.findPermissions(this.idProfiles).subscribe((result) => {
      let profiles = '';
      result.forEach((profile) => {
        profiles = profile.nombre;
      });

      window.localStorage.setItem('rol', profiles);
      this.nombrePerfil = profiles;
    });
  }

  getProfile() {
    this.https
      .get(URL_API_EXTERNAL.URL_MICROSOFT_GRAPH_ME)
      .toPromise()
      .then((infoUser) => {
        this.name = infoUser['displayName'];
        let arr = this.name.split(' ');
        let name = arr[0].substring(0, 1);
        let surname = '';
        if (arr.length > 1) {
          surname = arr[1].substring(0, 1);
        }
        this.contractionName = name + surname;
      });
    this.https
      .get(URL_API_EXTERNAL.URL_MICROSOFT_GRAPH_ME_MEMBER_OF)
      .toPromise()
      .then((groups) => {
        this.idProfiles = [];
        let values = groups['value'];
        for (let group of values) {
          this.idProfiles.push(group['id']);
        }

        // window.localStorage.setItem("idProfiles",JSON.stringify(this.idProfiles));
        this.nombrePerfil = window.localStorage.getItem('rol');
        if (
          this.nombrePerfil === '' ||
          this.nombrePerfil === null ||
          this.nombrePerfil === undefined
        ) {
          this.findPermissionByProfile();
        }
      });
  }
}
