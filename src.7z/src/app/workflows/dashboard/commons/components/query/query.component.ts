import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MainService } from '@commons/services/main.service';
import { Filtro } from '@commons/models/filtro';
import { SolicitudResponse } from '@commons/models/solicitudResponse';
import { Solicitud } from '@commons/models/solicitud';
import { ERRORS } from '../../../../../../utils/errors';
import { Cliente } from '@commons/models/cliente';
import { ConsultarCliente } from '@commons/models/consultarCliente';
import { ConsultarSolicitud } from '@commons/models/consultarSolicitud';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-query',
  templateUrl: './query.component.html',
  styleUrls: ['./query.component.scss'],
  providers: [MainService],
})
export class QueryComponent implements OnInit {
  public userToSearch: string;
  public error: boolean;
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private spinner: NgxSpinnerService,
    private proveedor: MainService
  ) { }

  // Se define los campos
  public field: string;
  public placeHolder: string;
  public mensaje: 'Por favor espera, estamos consultando ...';
  public mensajeError: string;
  public solicitudResponse: SolicitudResponse;
  public successMessage: boolean;
  public clienteRes: ConsultarCliente;
  public solicitudRes: ConsultarSolicitud;
  public userPin: ConsultarSolicitud;
  public userIdClient: Cliente;
  public clientInfo: Cliente;
  public dataResponse: any;
  public solicitudData: any;
  public solicitudObj: Solicitud;
  ngOnInit(): void {
    this.userToSearch = '';
    this.error = false;
    this.placeHolder = 'Número de solicitud';
    this.field = 'idSolicitud';
  }

  changeField() {
    if (this.field === 'idSolicitud') {
      this.placeHolder = 'Número de solicitud';
    } else {
      this.placeHolder = 'Número de documento';
    }
  }

  public searchToUser(): void {
    const filtro = new Filtro();
    filtro.Campo = this.field;
    filtro.Identificador = this.userToSearch;
    if (this.userToSearch === '') {
      {
        {
          this.mensajeError = ERRORS.ERROR_NO_SELECCTION;
        }
      }
    } else {
      this.spinner.show();
      this.successMessage = true;
    }
    if (this.userToSearch !== '') {
      if (this.field === 'idSolicitud') {
        this.spinner.show();
        // 1) Se consulta primero el id de la solicitud
        this.userPin = new ConsultarSolicitud();
        this.userPin.numeroSolicitud = this.userToSearch;
        this.proveedor
          .findRequestDetail(this.userPin)
          .subscribe((respuesta) => {
          if (respuesta === null) {
            {
              {
                this.mensajeError = ERRORS.ERROR_NO_IDSOLICITUD;
              }
            }
          }
          // console.error('que llega por la solicitud', respuesta);
          this.solicitudResponse = new SolicitudResponse();
          this.clienteRes = new ConsultarCliente();
          const solicitud = new Solicitud();
          const solicitudArreglo = [];
          solicitud.numeroSolicitud = respuesta.numeroSolicitud;
          solicitud.rolCliente = respuesta.rolTitularidad;
          solicitud.estadoSolicitud = respuesta.decisionADL;
          solicitud.valorSolicitado = respuesta.valorSolicitado;
          solicitud.valorAprobado = respuesta.valorAprobado;
          solicitud.fechaSolicitud = respuesta.fechaRadicacionADL;
          solicitud.producto = respuesta.producto;
          solicitudArreglo.push(solicitud);
          this.solicitudResponse.solicitudes = solicitudArreglo;
          this.solicitudResponse.rolCliente = respuesta.rolTitularidad;
          this.solicitudResponse.solicitudActual = respuesta;
          this.clienteRes.numeroIdentificacion = '';
          this.clienteRes.idCliente = respuesta.idCliente;
          this.proveedor
            .findClientById(this.clienteRes)
            .subscribe((resCliente) => {
            // console.error('que llega por la solicitud cliente', resCliente);

            this.solicitudResponse.idCliente = resCliente.numeroIdentificacion;
            this.solicitudResponse.nombreCliente = resCliente.nombres;
            this.solicitudResponse.apellidoCliente = resCliente.apellidos;
            this.solicitudResponse.tipoIdCliente = resCliente.tipoIdentificacion;
            this.solicitudResponse.cliente = resCliente;
            const uri = `home/request/${this.userToSearch}`;
            this.router.navigate(
              [
                uri,
                {
                  solicitudResponse: JSON.stringify(this.solicitudResponse),
                },
              ],
              { skipLocationChange: true, replaceUrl: false }
            );
          });
              // (error) => {
              //   this.mensajeError = 'Error: ' + error.error.description;
              // };
        });

      // 2) se consulta el cliente

      } else if (this.field === 'idCliente') {
        // 1) se consulta el cliente por el numero de documento para devolver el id del cliente
        this.userIdClient = new Cliente();
        this.userIdClient.numeroIdentificacion = this.userToSearch;
        this.proveedor
          .findClientByDocument(this.userIdClient)
          .subscribe((respuesta) => {
          if (respuesta == null) {
            {
              {
                this.mensajeError = ERRORS.ERROR_NO_IDCLIENT;
              }
            }
          } else {
            this.successMessage = true;
          }
          // console.error('que llega por el id cliente', respuesta);

          this.solicitudRes = new ConsultarSolicitud();
          this.solicitudResponse = new SolicitudResponse();
          this.solicitudResponse.idCliente = respuesta.numeroIdentificacion;
          this.solicitudResponse.nombreCliente = respuesta.nombres;
          this.solicitudResponse.apellidoCliente = respuesta.apellidos;
          this.solicitudResponse.tipoIdCliente = respuesta.tipoIdentificacion;
          this.solicitudResponse.cliente = respuesta;
          this.solicitudResponse.cliente.actividadEconomica =
            respuesta.actividadEconomica;
          this.solicitudResponse.cliente.edad = respuesta.edad;
          this.solicitudResponse.cliente.ocupacion = respuesta.ocupacion;
          this.solicitudResponse.cliente.profesion = respuesta.profesion;
          this.solicitudResponse.cliente.fechaNacimiento =
            respuesta.fechaNacimiento;
          this.solicitudRes.numeroSolicitud = respuesta.numeroIdentificacion;

          this.clienteRes = new ConsultarCliente();
          this.clienteRes.numeroIdentificacion = this.userToSearch;
          this.proveedor
            .findRequestPerClientId(this.clienteRes)
            .subscribe((resCliente1) => {
            console.log(
              '%c test data',
              'background: black; color: white',
              resCliente1
            );
            this.solicitudResponse.solicitudes = [];
            resCliente1.solicitudes.forEach((sol) => {
              this.solicitudObj = new Solicitud();
              this.solicitudObj.numeroSolicitud = sol.numeroSolicitud;
              this.solicitudObj.rolCliente = sol.rolTitularidad;
              this.solicitudObj.estadoSolicitud = sol.decisionADL;
              this.solicitudObj.valorSolicitado = sol.valorSolicitado;
              this.solicitudObj.valorAprobado = sol.valorAprobado;
              this.solicitudObj.fechaSolicitud = sol.fechaRadicacionADL;
              this.solicitudObj.producto = sol.producto;
              this.solicitudObj.detalle = sol;
              this.solicitudResponse.solicitudes.push(this.solicitudObj);
            });
            const uri = `home/request/${this.userToSearch}`;
            this.router.navigate(
              [
                uri,
                {
                  solicitudResponse: JSON.stringify(this.solicitudResponse),
                },
              ],
              { skipLocationChange: true, replaceUrl: false }
            );
          });
        });
        // 2) Se consulta las solicitudes por el id del cliente
      } else {
        console.log('opcion invalida ' + this.field);
      }
    } else {
      this.error = true;
    }
  }
}
