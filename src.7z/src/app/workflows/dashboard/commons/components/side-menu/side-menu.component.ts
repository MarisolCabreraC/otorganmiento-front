import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MainService } from '@commons/services/main.service';
import { APP, URL_API_EXTERNAL } from 'src/utils/constants';
import { MsalService } from '@azure/msal-angular';
import { HttpClient } from '@angular/common/http';
import { ConsultarParamsNombre } from '@commons/models/consultarParamsNombre';
import { Router } from '@angular/router';

@Component({
  selector: 'app-side-menu',
  templateUrl: './side-menu.component.html',
  styleUrls: ['./side-menu.component.scss'],
  providers: [MainService],
})
export class SideMenuComponent implements OnInit {
  private idProfiles: string[];
  @Input() openMenu: boolean;
  @Output() toggleSideBar: EventEmitter<null> = new EventEmitter();
  public interval: any;
  public idName: ConsultarParamsNombre;
  public name = 'URL_SAPBO';

  constructor(
    private servicio: MainService,
    private authService: MsalService,
    private https: HttpClient,
    private router: Router
  ) {}
  public permissions: any[];
  public listParamsName: any[];
  public valorUrlParam: string;
  public subMenus: any[];
  ngOnInit(): void {
    const token: string = localStorage.getItem('token');
    // this.habilitarMenuLocal()
    if (token) {
      this.getProfiles();
    } else {
      const requestObj = {
        scopes: ['user.read'],
      };
      this.authService
        .acquireTokenSilent(requestObj)
        .then((tokenResponse) => {
          const userName = tokenResponse.account.userName;
          this.servicio
            .generateTokenAPI(userName, tokenResponse.accessToken)
            .subscribe((token1) => {
              localStorage.setItem('token', token1.token);
              this.getProfiles();
            });
        })
        .catch(function (error) {
          this.authService
            .acquireTokenSilent(requestObj)
            .then((tokenResponse) => {
              const userName = tokenResponse.account.userName;
              this.service
                .generateTokenAPI(userName, tokenResponse.accessToken)
                .subscribe((token2) => {
                  localStorage.setItem('token', token2.token);
                  this.getProfile();
                });
            })
            .catch(function (error1) {
              this.interval = setInterval(
                this.getTokenSilent(requestObj),
                3000
              );
            });
        });
    }
  }

  habilitarMenuLocal() {
    localStorage.setItem('detalleCampo', 'true');
    localStorage.setItem('fichaCredito', 'true');
    localStorage.setItem('menuSeguridad', 'true');
    localStorage.setItem('segAccesos', 'true');
    localStorage.setItem('trazabilidad', 'true');
    localStorage.setItem('menuParametrizacionGeneral', 'true');
    localStorage.setItem('paramGeneral', 'true');
    localStorage.setItem('menuParametrizacion', 'true');
    localStorage.setItem('paramCatalogo', 'true');
    localStorage.setItem('menuSeguridadPerfil', 'true');
    localStorage.setItem('segPerfil', 'true');
    localStorage.setItem('reintoManualColumn', 'true');
    localStorage.setItem('menuReintento', 'true');
    localStorage.setItem('reintentoParametrizacion', 'true');
    localStorage.setItem('menuReintentoEjecucion', 'true');
    localStorage.setItem('reintentoMasivo', 'true');
    localStorage.setItem('menuConsulta', 'true');
    this.permissions = [];
    APP.MENU.ADMIN.forEach((option) => {
      if (option.subMenus !== undefined) {
        this.subMenus = [];
        option.subMenus.forEach((child) => {
          this.subMenus.push(child);
        });
        option.subMenus = [];
        option.subMenus = this.subMenus;
        this.permissions.push(option);
      } else {
        this.permissions.push(option);
      }
    });
  }
  public home() {
    this.router.navigate(['home/'], { replaceUrl: true });
  }
  public getTokenSilent(requestObj) {
    this.authService
      .acquireTokenSilent(requestObj)
      .then((tokenResponse) => {
        const userName = tokenResponse.account.userName;
        this.servicio
          .generateTokenAPI(userName, tokenResponse.accessToken)
          .subscribe((token) => {
            localStorage.setItem('token', token.token);
            this.getProfiles();
          });
        clearInterval(this.interval);
      })
      .catch((error) => {});
  }

  clickToogle() {
    this.toggleSideBar.emit();
  }

  public findPermissionByName(name) {
    this.servicio.findAllParamNames(name).subscribe((result) => {
      this.valorUrlParam = result.valor;
    });
  }

  public findPermissionByProfile() {
    localStorage.removeItem('showDetail');
    localStorage.removeItem('detalleCampo');
    localStorage.removeItem('fichaCredito');
    localStorage.removeItem('trazabilidad');
    localStorage.removeItem('segAccesos');
    localStorage.removeItem('paramGeneral');
    localStorage.removeItem('paramCatalogo');
    localStorage.removeItem('segPerfil');
    localStorage.removeItem('reintoManualColumn');
    localStorage.removeItem('reintentoParametrizacion');
    localStorage.removeItem('reintentoMasivo');

    localStorage.removeItem('menuConsulta');
    localStorage.removeItem('menuParametrizacion');
    localStorage.removeItem('menuSeguridad');
    localStorage.removeItem('menuReintento');
    localStorage.removeItem('menuParametrizacionGeneral');
    localStorage.removeItem('menuSeguridadPerfil');
    localStorage.removeItem('menuReintentoEjecucion');

    this.findPermissionByName('URL_SAPBO');
    window.localStorage.setItem('showDetail', 'true');

    this.servicio.findPermissions(this.idProfiles).subscribe((result) => {
      let profileName = '';
      result.forEach((profile) => {
        profileName = profile.nombre;
        this.permissions = [];

        // Detalle de campos
        let funcion = profile.funcionalidades.find((item) => item.id === 2);
        if (funcion !== null && funcion !== undefined) {
          localStorage.setItem('detalleCampo', 'true');
          // console.log('setea bandera detalleCampo: ');
        }

        // Ficha de crédito
        funcion = profile.funcionalidades.find((item) => item.id === 3);
        if (funcion !== null && funcion !== undefined) {
          localStorage.setItem('fichaCredito', 'true');
          // console.log('setea bandera fichaCredito: ');
        }

        // Seguridad accesos
        funcion = profile.funcionalidades.find((item) => item.id === 4);
        if (funcion !== null && funcion !== undefined) {
          localStorage.setItem('menuSeguridad', 'true');
          // console.log('setea bandera menuSeguridadAcceso: ');
          if (funcion.escritura === true) {
            localStorage.setItem('segAccesos', 'true');
            // console.log('setea bandera segAccesos: ');
          }
        }

        // Trazabilidad
        funcion = profile.funcionalidades.find((item) => item.id === 5);
        if (funcion !== null && funcion !== undefined) {
          localStorage.setItem('trazabilidad', 'true');
          // console.log('setea bandera trazabilidad: ');
        }

        // Parametrización general
        funcion = profile.funcionalidades.find((item) => item.id === 7);
        if (funcion !== null && funcion !== undefined) {
          localStorage.setItem('menuParametrizacionGeneral', 'true');
          // console.log('setea bandera menuParametrizacionGeneral');
          if (funcion.escritura === true) {
            localStorage.setItem('paramGeneral', 'true');
            // console.log('setea bandera paramGeneral');
          }
        }

        // Parametrización catálogos
        funcion = profile.funcionalidades.find((item) => item.id === 8);
        if (funcion !== null && funcion !== undefined) {
          localStorage.setItem('menuParametrizacion', 'true');
          // console.log('setea bandera menuParametrizacion');
          if (funcion.escritura === true) {
            localStorage.setItem('paramCatalogo', 'true');
            // console.log('setea bandera paramCatalogo');
          }
        }

        // Parametrización adherencia
        /* Ajustar id cuando exista en la BD */
        funcion = profile.funcionalidades.find((item) => item.id === 8);
        if (funcion !== null && funcion !== undefined) {
          localStorage.setItem('menuParametrizacion', 'true');
          // console.log('setea bandera menuParametrizacion');
          if (funcion.escritura === true) {
            localStorage.setItem('paramAdherencia', 'true');
            // console.log('setea bandera paramAdherencia');
          }
        }

        // Seguridad perfil
        funcion = profile.funcionalidades.find((item) => item.id === 9);
        if (funcion !== null && funcion !== undefined) {
          localStorage.setItem('menuSeguridadPerfil', 'true');
          // console.log('setea bandera: menuSeguridadPerfil');
          if (funcion.escritura === true) {
            localStorage.setItem('segPerfil', 'true');
            // console.log('setea bandera: segPerfil');
          }
        }

        // Seguridad reintento manual
        funcion = profile.funcionalidades.find((item) => item.id === 11);
        if (funcion !== null && funcion !== undefined) {
          if (funcion.escritura === true) {
            localStorage.setItem('reintoManualColumn', 'true');
            // console.log('setea bandera: reintoManualColumn');
          }
        }

        // parametrizacion de reintento
        funcion = profile.funcionalidades.find((item) => item.id === 12);
        if (funcion !== null && funcion !== undefined) {
          localStorage.setItem('menuReintento', 'true');
          // console.log('setea bandera: menuReintento ');
          if (funcion.escritura === true) {
            localStorage.setItem('reintentoParametrizacion', 'true');
            // console.log('setea bandera: reintentoParametrizacion ');
          }
        }

        // reintento masivo
        funcion = profile.funcionalidades.find((item) => item.id === 13);
        if (funcion !== null && funcion !== undefined) {
          localStorage.setItem('menuReintentoEjecucion', 'true');
          // console.log('setea bandera: menuReintentoEjecucion');
          if (funcion.escritura === true) {
            localStorage.setItem('reintentoMasivo', 'true');
            // console.log('setea bandera: reintentoMasivo');
          }
        }

        APP.MENU.ADMIN.forEach((option) => {
          if (option.id === 7) {
            // Parametrización general y catágos
            // console.log('Entra menu admin 7');
            funcion = profile.funcionalidades.find(
              (item) => item.id === option.id || item.id === 8
            );
          } else if (option.id === 9) {
            // Seguridad perfiles y accesos
            // console.log('Entra menu admin 9');
            funcion = profile.funcionalidades.find(
              (item) => item.id === option.id || item.id === 4
            );
          } else if (option.id === 12) {
            // Parametrización reitento y ejecución masiva
            // console.log('Entra menu admin 12');
            funcion = profile.funcionalidades.find(
              (item) => item.id === option.id || item.id === 13
            );
          } else if (option.id === 10) {
            // Consulta básica
            // console.log('Entra menu admin 10');
            funcion = profile.funcionalidades.find(
              (item) => item.id === option.id
            );
            if (funcion !== null && funcion !== undefined) {
              localStorage.setItem('menuConsulta', 'true');
              // console.log('setea bandera: menuConsulta');
            }
          } else if (option.id === 6) {
            // Reportes
            // console.log('Entra menu admin 6');
            funcion = profile.funcionalidades.find(
              (item) => item.id === option.id
            );
          }

          if (funcion !== null && funcion !== undefined) {
            if (option.subMenus !== undefined) {
              this.subMenus = [];
              option.subMenus.forEach((child) => {
                const submenu = profile.funcionalidades.find(
                  (item) => item.id === child.id
                );
                if (submenu !== null && submenu !== undefined) {
                  this.subMenus.push(child);
                }
              });
              option.subMenus = [];
              option.subMenus = this.subMenus;
              this.permissions.push(option);
            } else {
              this.permissions.push(option);
            }
          }
        });
      });
      window.localStorage.setItem('rol', profileName);
    });
  }

  getProfiles() {
    try {
      this.https
        .get(URL_API_EXTERNAL.URL_MICROSOFT_GRAPH_ME_MEMBER_OF)
        .toPromise()
        .then((groups) => {
          this.idProfiles = [];
          const values = groups['value'];

          for (const group of values) {
            this.idProfiles.push(group.id);
          }
          window.localStorage.setItem(
            'idProfiles',
            JSON.stringify(this.idProfiles)
          );
          this.findPermissionByProfile();
        });
    } catch (e) {
      console.log('&c esta fallando', 'background: red', e);
    }
  }

  logout() {
    window.localStorage.removeItem('rol');
    window.localStorage.removeItem('idProfiles');
    localStorage.removeItem('token');
    this.authService.logout();
  }

  redirect() {
    window.open(this.valorUrlParam, '_blank');
  }
}
