import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { MainService } from '@commons/services/main.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
  @Output() toggleSideBar: EventEmitter<null> = new EventEmitter();

  constructor(private mainService: MainService) {}

  ngOnInit(): void {}

  clickToogle() {
    this.toggleSideBar.emit();
  }
}
