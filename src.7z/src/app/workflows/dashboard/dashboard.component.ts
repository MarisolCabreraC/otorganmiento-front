import { Component, OnInit } from '@angular/core';
import { NgbAlertConfig } from '@ng-bootstrap/ng-bootstrap';
import { BehaviourInterceptorService } from 'src/app/commons/services/behaviour-interceptor.service';
/**
 * @ngdoc component
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Julio 2020
 * @author Everis Colombia - para Banco Popular.
 * @description Fichero encargado de realizar la interpolacion del home.
 */
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements OnInit {
  public isAlert: boolean;
  public httpErrorMsg: string;

  sideBarIsOpened = false;

  constructor(private _httpError: BehaviourInterceptorService,
              private configAlert:NgbAlertConfig) {
    // console.info('instancio data');
  }
  //metodo por defecto que se ejecuta al terminar de cargar la pagina
  ngOnInit(): void {
    // console.info(this._httpError);
    // this._httpError.getData().subscribe((obj) => {
    //   this.isAlert = obj.isAlert;
    //   this.httpErrorMsg = obj.smsError;
    //   this.timerCloseAlert();
    // });
    setTimeout(() =>document.getElementById('alertE').style.display="none",5000 );
  }

  sideBarToogle() {
    this.sideBarIsOpened = !this.sideBarIsOpened;
  }

  private timerCloseAlert() {
    setTimeout(() => {
      this.isAlert = false;
    }, 15000);
  }
  cerrar(alertE){
    document.getElementById(alertE).style.display="none";
  }
}
