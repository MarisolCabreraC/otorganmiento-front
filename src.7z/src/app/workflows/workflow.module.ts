import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@commons/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AdminAccessComponent } from './admin-access/admin-access.component';
import { AdminProfileComponent } from './admin-profile/admin-profile.component';
import { AddProfileComponent } from './admin-profile/components/add-profile/add-profile.component';
import { AvatarCardComponent } from './dashboard/commons/components/avatar-card/avatar-card.component';
import { ContentComponent } from './dashboard/commons/components/content/content.component';
import { HeaderComponent } from './dashboard/commons/components/header/header.component';

import { SideMenuComponent } from './dashboard/commons/components/side-menu/side-menu.component';
import { ButtonComponent } from './dashboard/commons/components/side-menu/button/button.component';
import { LoginComponent } from './login/login.component';
import { ModalsComponent } from './modals/modals.component';
import { ParametrizationComponent } from './parametrization/parametrization.component';
import { EditParamsComponent } from './parametrization/commons/edit/edit-params/edit-params.component';
import { EditRetryComponent } from './parametrization/edit-retry/edit-retry.component';
import { MassiveComponent } from './parametrization/reintento/massive/massive.component';
import { ReintentoComponent } from './parametrization/reintento/reintento.component';
import { SaveRetryComponent } from './parametrization/save-retry/save-retry.component';
import { CatalogosComponent } from './parametrization/catalogos/catalogos.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { WorkflowRoutingModule } from '@workflows/workflow.routing';

import { activityCatalogModule } from '@workflows/parametrization/catalogos/commons/activity-catalog/activity-catalog.module';
import { AdminActivityModule } from '@src/app/workflows/parametrization/catalogos/commons/activity-catalog/admin-activity/admin-activity.module';
import { CanalCatalogModule } from '@workflows/parametrization/catalogos/commons/canal-catalog/canal-catalog.module';
import { ContractCatalogModule } from './parametrization/catalogos/commons/contract-catalog/contract-catalog.module';
import { AdminContractModule } from './parametrization/catalogos/commons/contract-catalog/admin-contract/admin-contract.module';
import { CargoCatalogModule } from '@workflows/parametrization/catalogos/commons/cargo-catalog/cargo-catalog.module';
import { AdminCargoModule } from '@workflows/parametrization/catalogos/commons/cargo-catalog/admin-cargo/admin-cargo.module';
import { OcupationCatalogModule } from './parametrization/catalogos/commons/ocupation-catalog/ocupation-catalog.module';
import { AdminOcupationModule } from './parametrization/catalogos/commons/ocupation-catalog/admin-ocupation/admin-ocupation.module';
import { OfficeCatalogModule } from './parametrization/catalogos/commons/office-catalog/office-catalog.module';
import { AdminOfficeModule } from './parametrization/catalogos/commons/office-catalog/admin-office/admin-office.module';
import { EditOfficeModule } from './parametrization/catalogos/commons/office-catalog/edit-office/edit-office.module';
import { ProductCatalogModule } from './parametrization/catalogos/commons/product-catalog/product-catalog.module';
import { AdminCatalogModule } from './parametrization/catalogos/commons/product-catalog/admin-catalog/admin-catalog.module';
import { ProfessionCatalogModule } from './parametrization/catalogos/commons/profession-catalog/profession-catalog.module';
import { AdminProfessionModule } from './parametrization/catalogos/commons/profession-catalog/admin-profession/admin-profession.module';
import { SectorCatalogModule } from './parametrization/catalogos/commons/sector-catalog/sector-catalog.module';
import { AdminSectorModule } from './parametrization/catalogos/commons/sector-catalog/admin-sector/admin-sector.module';
import { StatementCatalogModule } from './parametrization/catalogos/commons/statement-catalog/statement-catalog.module';
import { AdminStatementModule } from './parametrization/catalogos/commons/statement-catalog/admin-statement/admin-statement.module';
import { TypeFlowCatalogModule } from './parametrization/catalogos/commons/type-flow-catalog/type-flow-catalog.module';
import { AdminTypeflowModule } from './parametrization/catalogos/commons/type-flow-catalog/admin-typeflow/admin-typeflow.module';
import { FinancialEntityModule } from './parametrization/catalogos/commons/financial-entity/financial-entity.module';
import { QueryComponent } from './dashboard/commons/components/query/query.component';
import { NoPermitidoComponent } from '../commons/components/no-permitido/no-permitido.component';
import { RequestComponent } from './request/request.component';
import { DetailedConsultationComponent } from './request/components/details/detailed-consultation/detailed-consultation.component';
import { FieldDetailsComponent } from './request/components/details/field-details/field-details.component';
import { DetailedTraceabilityTableComponent } from './request/components/details/detailed-consultation/commons/detailed-traceability-table/detailed-traceability-table.component';
import { DetailedTableComponent } from './request/components/details/detailed-consultation/commons/detailed-table/detailed-table.component';
import { AccordionComponent } from './request/components/details/field-details/commons/accordion/accordion.component';
import { DetailedCellComponent } from './request/components/details/detailed-consultation/commons/detailed-table/commons/detailed-cell/detailed-cell.component';
import { DetailedTraceabilityCellsComponent } from './request/components/details/detailed-consultation/commons/detailed-traceability-table/commons/detailed-traceability-cells/detailed-traceability-cells.component';
import { ClienteComponent } from './cliente/cliente.component';
import { EditActivityModule } from './parametrization/catalogos/commons/activity-catalog/edit-activity/edit-activity.module';
import { EditOcupationModule } from './parametrization/catalogos/commons/ocupation-catalog/edit-ocupation/edit-ocupation.module';
import { EditTypeflowModule } from './parametrization/catalogos/commons/type-flow-catalog/edit-typeflow/edit-typeflow.module';
import { AdminCanalModule } from './parametrization/catalogos/commons/canal-catalog/admin-canal/admin-canal.module';
import { EditCanalModule } from './parametrization/catalogos/commons/canal-catalog/edit-canal/edit-canal.module';
import { EditFinancialEntityModule } from './parametrization/catalogos/commons/financial-entity/edit-financial-entity/edit-financial-entity.module';
import { AdminFinancialEntityModule } from './parametrization/catalogos/commons/financial-entity/admin-financial-entity/admin-financial-entity.module';
import { EditProductModule } from './parametrization/catalogos/commons/product-catalog/edit-product/edit-product.module';
import { FestiveCatalogModule } from './parametrization/catalogos/commons/festive-catalog/festive-catalog.module';
import { AdminFestiveModule } from '@workflows/parametrization/catalogos/commons/festive-catalog/admin-festive/admin-festive.module';
import { EditFestiveModule } from '@workflows/parametrization/catalogos/commons/festive-catalog/edit-festive/edit-festive.module';
import { DatePipe } from '@angular/common';
import { FlowStageModule } from './parametrization/catalogos/commons/flow-stage/flow-stage.module';
import { AdminStageModule } from './parametrization/catalogos/commons/flow-stage/admin-stage/admin-stage.module';
import { ZoneCatalogModule } from './parametrization/catalogos/commons/zone-catalog/zone-catalog.module';
import { AdminZoneModule } from './parametrization/catalogos/commons/zone-catalog/admin-zone/admin-zone.module';
import { EditCargoModule } from './parametrization/catalogos/commons/cargo-catalog/edit-cargo/edit-cargo.module';
import { RegionalCatalogModule } from '@workflows/parametrization/catalogos/commons/regional-catalog/regional-catalog.module';
import { EditRegionalCatalogModule } from '@workflows/parametrization/catalogos/commons/regional-catalog/edit-regional-catalog/edit-regional-catalog.module';
import { AdminRegionalCatalogModule } from '@workflows/parametrization/catalogos/commons/regional-catalog/admin-regional-catalog/admin-regional-catalog.module';
import { DocumentTypeCatalogModule } from '@workflows/parametrization/catalogos/commons/document-type-catalog/document-type-catalog.module';
import { AdminDocumentTypeModule } from '@workflows/parametrization/catalogos/commons/document-type-catalog/admin-document-type/admin-document-type.module';
import { EditDocumentTypeModule } from '@workflows/parametrization/catalogos/commons/document-type-catalog/edit-document-type/edit-document-type.module';
import { RolCatalogModule } from './parametrization/catalogos/commons/rol-catalog/rol-catalog.module';
import { AdminRolModule } from './parametrization/catalogos/commons/rol-catalog/admin-rol/admin-rol.module';
import { PayNoteTypeCatalogModule } from './parametrization/catalogos/commons/pay-note-type-catalog/pay-note-type-catalog.module';
import { EditPayNoteTypeCatalogModule } from './parametrization/catalogos/commons/pay-note-type-catalog/edit-pay-note-type-catalog/edit-pay-note-type-catalog.module';
import { AdminPayNoteTypeCatalogModule } from './parametrization/catalogos/commons/pay-note-type-catalog/admin-pay-note-type-catalog/admin-pay-note-type-catalog.module';

import { AccountCatalogModule } from './parametrization/catalogos/commons/account-catalog/account-catalog.module';
import { AdminAccountModule } from './parametrization/catalogos/commons/account-catalog/admin-account/admin-account.module';
import { EditAccountModule } from './parametrization/catalogos/commons/account-catalog/edit-account/edit-account.module';
import { DocumentDeciderCatalogModule } from './parametrization/catalogos/commons/document-decider-catalog/document-decider-catalog.module';
import { AdminDocumentDeciderModule } from './parametrization/catalogos/commons/document-decider-catalog/admin-document-decider/admin-document-decider.module';
import { EditContractModule } from './parametrization/catalogos/commons/contract-catalog/edit-contract/edit-contract.module';
import { EditStatementModule } from './parametrization/catalogos/commons/statement-catalog/edit-statement/edit-statement.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AlertService } from '../commons/components/alerts/alerts.service';
import { AdminAdherenceComponent } from './parametrization/adherencia/adherencia/admin-adherence/admin-adherence.component';
import { AddAdherenceComponent } from './parametrization/adherencia/adherencia/admin-adherence/add-adherence/add-adherence/add-adherence.component';
import { AdminProfileAdherenceComponent } from './parametrization/adherencia/perfiles/admin-profile/admin-profile.component';
import { AddProfileAdherenceComponent } from './parametrization/adherencia/perfiles/admin-profile/add-profile/add-profile.component';
import { NavbarAdherenciaComponent } from './parametrization/adherencia/navbar-adherencia/navbar-adherencia/navbar-adherencia.component';
import { AddAdherenceModule } from './parametrization/adherencia/adherencia/admin-adherence/add-adherence/add-adherence/add-adherence.module';
import { AdminAdherenceModule } from './parametrization/adherencia/adherencia/admin-adherence/admin-adherence.module';
import { AdminAdherenceProfileModule } from './parametrization/adherencia/perfiles/admin-profile/admin-profile.module';

@NgModule({
  declarations: [
    DashboardComponent,
    AdminAccessComponent,
    AdminProfileComponent,
    AddProfileComponent,
    AvatarCardComponent,
    ContentComponent,
    HeaderComponent,
    SideMenuComponent,
    ButtonComponent,
    LoginComponent,
    ModalsComponent,
    ParametrizationComponent,
    EditParamsComponent,
    EditRetryComponent,
    MassiveComponent,
    ReintentoComponent,
    SaveRetryComponent,
    CatalogosComponent,
    QueryComponent,
    NoPermitidoComponent,
    RequestComponent,
    DetailedConsultationComponent,
    FieldDetailsComponent,
    DetailedTraceabilityTableComponent,
    DetailedTableComponent,
    AccordionComponent,
    DetailedCellComponent,
    DetailedTraceabilityCellsComponent,
    ClienteComponent,
    AdminAdherenceComponent,
    AddAdherenceComponent,
    AdminProfileAdherenceComponent,
    AddProfileComponent,
    AddProfileAdherenceComponent,
    NavbarAdherenciaComponent,
  ],
  imports: [
    ReactiveFormsModule,
    CommonModule,
    RouterModule,
    FormsModule,
    SharedModule,
    WorkflowRoutingModule,
    activityCatalogModule,
    AdminActivityModule,
    CanalCatalogModule,
    ContractCatalogModule,
    AdminContractModule,
    EditContractModule,
    CargoCatalogModule,
    AdminCargoModule,
    CargoCatalogModule,
    OcupationCatalogModule,
    AdminOcupationModule,
    OfficeCatalogModule,
    AdminOfficeModule,
    EditOfficeModule,
    ProductCatalogModule,
    AdminCatalogModule,
    ProfessionCatalogModule,
    AdminProfessionModule,
    SectorCatalogModule,
    AdminSectorModule,
    StatementCatalogModule,
    AdminStatementModule,
    TypeFlowCatalogModule,
    AdminTypeflowModule,
    AdminActivityModule,
    EditActivityModule,
    activityCatalogModule,
    AdminOcupationModule,
    EditOcupationModule,
    OcupationCatalogModule,
    TypeFlowCatalogModule,
    AdminTypeflowModule,
    EditTypeflowModule,
    AdminCanalModule,
    EditCanalModule,
    EditFinancialEntityModule,
    FinancialEntityModule,
    AdminFinancialEntityModule,
    EditProductModule,
    FestiveCatalogModule,
    AccountCatalogModule,
    AdminAccountModule,
    EditAccountModule,
    AdminFestiveModule,
    EditFestiveModule,
    RegionalCatalogModule,
    EditRegionalCatalogModule,
    AdminRegionalCatalogModule,
    FlowStageModule,
    AdminStageModule,
    DocumentTypeCatalogModule,
    AdminDocumentTypeModule,
    EditDocumentTypeModule,
    ZoneCatalogModule,
    AdminZoneModule,
    EditCargoModule,
    RolCatalogModule,
    AdminRolModule,
    PayNoteTypeCatalogModule,
    AdminPayNoteTypeCatalogModule,
    DocumentDeciderCatalogModule,
    AdminDocumentDeciderModule,
    EditStatementModule,
    AdminAdherenceModule,
    AddAdherenceModule,
    AdminAdherenceProfileModule,
    NgbModule,
  ],
  exports: [
    DashboardComponent,
    AdminAccessComponent,
    AdminProfileComponent,
    AddProfileComponent,
    AvatarCardComponent,
    ContentComponent,
    HeaderComponent,
    SideMenuComponent,
    ButtonComponent,
    LoginComponent,
    ModalsComponent,
    ParametrizationComponent,
    EditParamsComponent,
    EditRetryComponent,
    MassiveComponent,
    ReintentoComponent,
    SaveRetryComponent,
    CatalogosComponent,
    QueryComponent,
    NoPermitidoComponent,
    RequestComponent,
    DetailedConsultationComponent,
    FieldDetailsComponent,
    DetailedTraceabilityTableComponent,
    DetailedTableComponent,
    AccordionComponent,
    DetailedCellComponent,
    DetailedTraceabilityCellsComponent,
    ClienteComponent,
    EditPayNoteTypeCatalogModule,
  ],
  providers: [DatePipe, AlertService],
})
export class WorkflowModule {}
