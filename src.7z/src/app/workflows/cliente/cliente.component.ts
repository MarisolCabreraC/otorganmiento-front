import { Component, Input, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { SolicitudResponse } from '@commons/models/solicitudResponse';
import { ClientService } from '@commons/services/client.service';
import { NgxSpinnerService } from 'ngx-spinner';
/**
 * @ngdoc component
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Julio 2020
 * @author Everis Colombia - para Banco Popular.
 * @description Fichero encargado de realizar la interpolacion de cliente.
 */
@Component({
  selector: 'app-cliente',
  templateUrl: './cliente.component.html',
  styleUrls: ['./cliente.component.scss'],
})
export class ClienteComponent implements OnInit {
  @Input() isTraza: boolean;
  public solicitudResponse: any;
  public solicitud: any;
  public idSolicitud: any;
  constructor(
    private router: Router,
    private route: Location,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute,
    private service: ClientService
  ) {}
  // metodo por defecto que se ejecuta al terminar de cargar la pagina
  ngOnInit(): void {
    this.service.getData().subscribe((res) => {
      if (res.nombreCliente !== undefined) {
        this.solicitudResponse = res;
      } else {
        this.loadData();
      }
    });
  }

  /**
   * @description metodo encargado de traer los datos.
   * @author yquintana - Everis Colombia - para Banco Popular.
   * @version 1.0.0
   * @since Julio 2020
   */
  loadData() {
    this.spinner.show();
    this.activatedRoute.params.subscribe((params) => {
      this.idSolicitud = params.request_id;
      console.log('LoadData >>>>>>>>>>>>>>>', params.request_id);
      if (params.solicitudResponse !== null) {
        this.solicitudResponse = JSON.parse(
          params.solicitudResponse
        ) as SolicitudResponse;
        this.service.setData(this.solicitudResponse);
      }
      this.spinner.hide();
    });

    // this.activatedRoute.queryParamMap.subscribe((params) => {
    //   if (params['params'].solicitudResponse !== undefined) {
    //     this.solicitudResponse = JSON.parse(
    //       params['params'].solicitudResponse
    //     ) as SolicitudResponse;
    //   }
    // });
  }
  /**
   * @description metodo encargado de volver para atras .
   * @author yquintana - Everis Colombia - para Banco Popular.
   * @version 1.0.0
   * @since Julio 2020
   */

  public back(): void {
    if (this.isTraza === false) {
      this.router.navigate(['home/query'], { replaceUrl: true });
      window.location.reload();
    } else {
      this.solicitud = {};
      this.solicitudResponse.idSolicitud = this.solicitudResponse.solicitudActual.numeroSolicitud;
      this.solicitudResponse.numeroSolicitud = this.solicitudResponse.solicitudActual.numeroSolicitud;
      this.solicitud.solicitudResponse = this.solicitudResponse;
      this.solicitud.nombreCliente =
        this.solicitudResponse.nombreCliente +
        ' ' +
        this.solicitudResponse.apellidoCliente;
      this.router.navigate(
        [
          'home/detailed-consultation',
          { solicitud: JSON.stringify(this.solicitud) },
        ],
        { skipLocationChange: true }
      );
    }
  }
}
