import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MainService } from '@commons/services/main.service';
import { ConsultarFuncionalidad } from '@commons/models/consultarFuncionalidad';
import { InfoFuncionalidad } from '@commons/models/infoFuncionalidad';
import { NgxSpinnerService } from 'ngx-spinner';
/**
 * @ngdoc component
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Julio 2020
 * @author Everis Colombia - para Banco Popular.
 * @description Fichero encargado de realizar la interpolacion de accesos.
 */
@Component({
  selector: 'app-admin-access',
  templateUrl: './admin-access.component.html',
  styleUrls: ['./admin-access.component.scss'],
})
export class AdminAccessComponent implements OnInit {
  public optionValue: string;
  public showTable = false;
  public idFromProfile: any;
  public listProfiles: any;
  public listPermission: any;
  public mensaje: string;
  public idFunctionnality: number;
  public disabledField = true;
  public editAccess: any;
  public editedPermissions: Array<InfoFuncionalidad> = [];
  public adminAccessBtns: boolean;
  constructor(
    private servicio: MainService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute
  ) {
    this.adminAccessBtns = JSON.parse(localStorage.getItem('segAccesos'));
  //  console.log('>>>>> Escritura segAccesos: ', this.adminAccessBtns);
  }

  onChange(idPerfil) {
    this.idFromProfile = idPerfil;
    this.loadPermissionData();
    this.showTable = true;
  }

  ngOnInit(): void {
    this.loadProfileData();
  }

  // metodo por defecto que se ejecuta al cargar la pagina
  loadProfileData() {
    this.spinner.show();
    this.servicio.findAllProfilesByPage('true').subscribe((result) => {
      this.listProfiles = result.contenido;
      this.spinner.hide();
    });
  }

  loadPermissionData() {
    this.activatedRoute.params.subscribe((params) => {
      const consultaPerms = new ConsultarFuncionalidad();
      consultaPerms.idPerfil = this.idFromProfile;
      this.servicio
        .findAllFunctionsByProfile(consultaPerms)
        .subscribe((result) => {
          this.listPermission = result.acceso;
          this.idFunctionnality = this.listPermission.map((perm) => {
            this.editAccess = Object.assign({}, perm);
            // console.log('%c Clicked, new value','background-color: red', this.editAccess);
            return perm.idAcceso;
          });
        });
    });
  }

  updatePermissionValue(field, perm: InfoFuncionalidad) {
    const duplicated = this.editedPermissions.find(
      (item) => item.idFuncionalidad === perm.idFuncionalidad
    );

    const duplicatedIdx = this.editedPermissions.indexOf(duplicated);
    const prevPerm =
      duplicatedIdx === -1 ? Object.assign({}, perm as any) : duplicated;
    const newPerm = Object.assign({}, prevPerm);
    newPerm[field] = !newPerm[field];

    if (field === 'escritura' && newPerm[field]) {
      newPerm.lectura = true;
    }

    if (field === 'lectura' && !newPerm[field]) {
      newPerm.escritura = false;
    }

    if (
      (!prevPerm.escritura && newPerm.lectura) ||
      (prevPerm.escritura && !newPerm.escritura) ||
      (prevPerm.escritura && newPerm.lectura)
    ) {
      if (duplicatedIdx !== -1) {
        this.editedPermissions[duplicatedIdx] = newPerm;
      } else {
        this.editedPermissions.push(newPerm);
      }
      this.updateMainData(newPerm);
    }

    // console.log('%c Clicked, new value', 'background-color: green', newPerm);
  }

  public updateMainData(permAccess) {
    const edited = this.listPermission.find(
      (item) => item.idFuncionalidad === permAccess.idFuncionalidad
    );

    const editedIdx = this.listPermission.indexOf(edited);
    if (editedIdx >= 0) {
      this.listPermission[editedIdx] = permAccess;
    }
  }

  public toggleFields() {
    this.disabledField = !this.disabledField;
  }

  public updateValues() {
    this.servicio.updatePerms(this.editedPermissions).subscribe(
      (result) => {
        console.log(result);
        document.getElementById('openModalButton').click();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
    // console.log('envio', this.editedPermissions);
  }
  public back(): void {
    setTimeout(() => {
      window.location.reload();
    }, 2000);
  }

  public cancelValues(): void {
    window.location.reload();
    this.router.navigate(['home/admin-access'], { replaceUrl: true });
  }
}
