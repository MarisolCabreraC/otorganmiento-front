import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditRetryComponent } from './edit-retry.component';

describe('EditRetryComponent', () => {
  let component: EditRetryComponent;
  let fixture: ComponentFixture<EditRetryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditRetryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditRetryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
