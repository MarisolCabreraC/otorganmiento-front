import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ParametrizationReintento } from '@commons/models';
import { ParametrizationReintentoService } from '@commons/services/parametrization-reintento.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-edit-retry',
  templateUrl: './edit-retry.component.html',
  styleUrls: ['./edit-retry.component.scss']
})
export class EditRetryComponent implements OnInit {
  public forma: FormGroup;
  public regularPhraseFormatHour: RegExp = /^([01]?[0-9]|2[0-3]):[0-5][0-9]$/;
  public regularPhraseNumberRetry: RegExp = /^[1-9][0-9]?$|^99$/;
  public regularPhraseNumberInterval: RegExp = /^(?:1[01][0-9]|120|1[5-9]|[2-9][0-9])$/;
  public editParam: string;
  public edicion: boolean = false;
  public parametrization: ParametrizationReintento;
  public errorCode = false;
  public errorCodeText = 'el dato no ha sido procesado';

  constructor(private router: Router,
    public formBuilder: FormBuilder,
    private spinner: NgxSpinnerService,
    private parametrizationRetryService: ParametrizationReintentoService,
    private activatedRoute: ActivatedRoute,) { }

  ngOnInit(): void {
    this.loadPage();
  }
  /**
* 
*/
  public loadPage(): void {
    this.setForm();    
    this.editParam = this.activatedRoute.snapshot.paramMap.get('id');
    this.searchParametrization();
    // this.setDataToForm();
  }

  public back() {
    this.router.navigate(['home/reintentos/parametrizacion'], { replaceUrl: true });
  }
 
  /**
   * 
   * @param idParametrizacionReintento 
   */
  public searchParametrization(): void {
    this.spinner.show();
    var obj = {
      idParametroReintento:this.editParam
    }
    this.parametrizationRetryService.consultarParametrizacionReintentoPorId(obj).subscribe(
      data => {
        this.parametrization = data;
        this.setDataToForm();
        this.spinner.hide();
      }, error => {
        this.spinner.hide();
      }
    );
  }

  /**
   * 
   */
   public setForm(): void {
     this.forma = new FormGroup({
       idMicroServicio: new FormControl('',[Validators.required]),
       reintento: new FormControl('', [Validators.required, Validators.pattern(this.regularPhraseNumberRetry)]),
       restriccionInicio: new FormControl('', [Validators.required, Validators.pattern(this.regularPhraseFormatHour)]),
       restriccionFin: new FormControl('', [Validators.required, Validators.pattern(this.regularPhraseFormatHour)]),
       restriccionDia: new FormControl('', [Validators.required,]),
       intervalo: new FormControl('',[Validators.required, Validators.pattern(this.regularPhraseNumberInterval)]),
       idParametroReintento:   new FormControl (),
      });
   }

   /**
    * 
    */
  public edit() {
    this.forma.controls['idMicroServicio'].setValue(this.parametrization.idMicroServicio);
    this.forma.controls['idParametroReintento'].setValue(this.editParam);
    this.spinner.show();
    this.parametrizationRetryService.editParametrization(this.forma.value).subscribe(  
        data => {
          this.spinner.hide();
          document.getElementById('openModalButtonS').click();
        }, 
        error => {
          this.spinner.hide();
          this.forma.controls['idMicroServicio'].setValue(this.parametrization.microServicio);
          document.getElementById('openModalButtonE').click();
        });
    }
   

  public backForm() {
    this.router.navigate(['/home/reintentos/parametrizacion']);
  }
  public goToRetryList() {
    this.router.navigate(['/home/reintentos/parametrizacion']);
  }

   public setDataToForm():void{
     
     this.forma.controls['idMicroServicio'].setValue(this.parametrization.microServicio);
     this.forma.controls['idMicroServicio'].disabled;
     this.forma.controls['reintento'].setValue(this.parametrization.reintento);
     this.forma.controls['intervalo'].setValue(this.parametrization.intervalo);
     this.forma.controls['restriccionDia'].setValue(this.parametrization.restriccionDia);
     this.forma.controls['restriccionFin'].setValue(this.parametrization.restriccionFin);
     this.forma.controls['restriccionInicio'].setValue(this.parametrization.restriccionInicio);
    
   }
}
