import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

// Route
import { EditProductRoutingModule } from './edit-product-routing.module';

// Service
import { ProductService } from '../service/product.service';

// Component
import { EditProductComponent } from './edit-product.component';

@NgModule({
  declarations: [EditProductComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    NgbModule,
    EditProductRoutingModule
  ],
  providers: [ProductService]
})
export class EditProductModule { }
