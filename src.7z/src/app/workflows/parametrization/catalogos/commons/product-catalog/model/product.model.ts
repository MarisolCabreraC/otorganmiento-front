/**
 * Entidad que mapea la informacion obtenida del microservicio de productos.
 */
export interface CatalogoProductoInterface {
    abreviatura: string;
    idLineaCreditoSarc: number;
    idModalidadSarc: string;
    idProducto: number;
    idSarc: string;
    idTipoPrestamoGar: string;
    indicador: number;
    nombre: string;
    orden: number;
    plazoMaxMeses: number;
    tipoOperacion: string;
    utilizacion: number;
    usuario?: string;
    activo?: boolean;
  }
  