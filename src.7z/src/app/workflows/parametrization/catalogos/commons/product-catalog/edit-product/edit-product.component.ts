import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ModalsComponent } from '@workflows/modals/modals.component';
import { CatalogoProductoInterface } from '../model/product.model';
import { ProductService } from '../service/product.service';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['../../../../../../../../src/assets/css/style_catalogue.scss']
})
export class EditProductComponent implements OnInit {

  @ViewChild('examplemodal') modal: ModalsComponent;
  public errorCode = false;
  public errorCodeText = 'el dato no ha sido procesado';
  public mensaje: string;
  public product: CatalogoProductoInterface;
  public idProducto: number;
  public abreviatura: string;
  public idLineaCreditoSarc: number;
  public idModalidadSarc: string;
  public idSarc: string;
  public idTipoPrestamoGar: string;
  public indicador: number;
  public orden: number;
  public plazoMaxMeses: number;
  public tipoOperacion: string;
  public utilizacion: number;
  public nombre: string;
  public status: boolean;
  public form: FormGroup;
  public activo: boolean;
  public operacion: string = 'Editar';

  constructor(private router: Router,
    public formBuilder: FormBuilder,
    private productService: ProductService,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.loadData();
    this.buildForm();
  }

  /**
   * Metodo que carga los datos en el formulario
   */
   loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.product = JSON.parse(params['editProfile']) as CatalogoProductoInterface;
      this.abreviatura = this.product.abreviatura;
      this.idLineaCreditoSarc = this.product.idLineaCreditoSarc;
      this.idModalidadSarc = this.product.idModalidadSarc;
      this.idProducto = this.product.idProducto;
      this.idSarc = this.product.idSarc;
      this.idTipoPrestamoGar = this.product.idTipoPrestamoGar;
      this.indicador = this.product.indicador;
      this.nombre = this.product.nombre;
      this.orden = this.product.orden;
      this.plazoMaxMeses = this.product.plazoMaxMeses;
      this.tipoOperacion = this.product.tipoOperacion;
      this.utilizacion = this.product.utilizacion;

      if (this.nombre == null) {
        this.status = true;
      }
    });
  }

  /**
   * Form producto
   */
   buildForm(): void {
    this.form = this.formBuilder.group({
      idProducto: new FormControl(this.idProducto, [Validators.required]),
      nombre: new FormControl(this.nombre, [Validators.required, Validators.maxLength(125)]),
      abreviatura: new FormControl(this.abreviatura, [Validators.required, Validators.maxLength(125)]),
      indicador: new FormControl(this.indicador, [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      tipoOperacion: new FormControl(this.tipoOperacion, [Validators.required, Validators.maxLength(25)]),
      orden: new FormControl(this.orden, [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      plazoMaxMeses: new FormControl(this.plazoMaxMeses, [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      utilizacion: new FormControl(this.utilizacion, [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      idSarc: new FormControl(this.idSarc, [Validators.required, Validators.maxLength(25)]),
      idLineaCreditoSarc: new FormControl(this.idLineaCreditoSarc, [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      idModalidadSarc: new FormControl(this.idModalidadSarc, [Validators.required, Validators.maxLength(25)]),
      idTipoPrestamoGar: new FormControl(this.idTipoPrestamoGar, [Validators.required, Validators.maxLength(25)]),
      activo: new FormControl(this.activo)
    });
  }

  /**
   * Metodo que actualiza producto
   */
   updateProduct() {
    this.mensaje = '';
    this.product.nombre = this.form.controls['nombre'].value;
    this.product.abreviatura = this.form.controls['abreviatura'].value;
    this.product.idLineaCreditoSarc = this.form.controls['idLineaCreditoSarc'].value;
    this.product.idModalidadSarc = this.form.controls['idModalidadSarc'].value;
    this.product.idSarc = this.form.controls['idSarc'].value;
    this.product.idTipoPrestamoGar = this.form.controls['idTipoPrestamoGar'].value;
    this.product.indicador = this.form.controls['indicador'].value;
    this.product.orden = this.form.controls['orden'].value;
    this.product.plazoMaxMeses = this.form.controls['plazoMaxMeses'].value;
    this.product.tipoOperacion = this.form.controls['tipoOperacion'].value;
    this.product.utilizacion = this.form.controls['utilizacion'].value;
    this.product.idProducto = this.form.controls['idProducto'].value;
    this.productService.updateProduct(this.product).subscribe(
      (result) => {
        document.getElementById('modalButtonEditClose').click();
        document.getElementById('openModalButtonEditClose').click();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Metodo que abre la ventana modal para editar producto
   */
   openEditModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  /**
   * Metodo que cierra el modal y redirecciona al listado de productos
   */
  closeModalEdit() {
    this.router.navigate(['home/parametrization/catalogos/product-catalog'], { replaceUrl: true });
  }

  /**
   * Redirecciona al listado de productos
   */
  public back(): void {
    this.router.navigate(['home/parametrization/catalogos/product-catalog'], { replaceUrl: true });
  }

}
