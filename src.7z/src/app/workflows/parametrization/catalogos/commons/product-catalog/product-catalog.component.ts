import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { CatalogoProductoInterface } from './model/product.model';
import { ProductService } from './service/product.service';

@Component({
  selector: 'app-product-catalogs',
  templateUrl: './product-catalog.component.html',
  styleUrls: ['../../../../../../../src/assets/css/style_catalogue.scss']
})
export class ProductCatalogComponent implements OnInit {

  public mensaje: any;
  public editMenuOpt: boolean;
  products: CatalogoProductoInterface[];

  constructor(private router: Router, private productService: ProductService, private spinner: NgxSpinnerService) {
    this.editMenuOpt = JSON.parse(localStorage.getItem('paramGeneral'));
  }

  ngOnInit(): void {
    this.initTableProduct();
  }

  /**
   * Carga la tabla con los datos de producto
   */
  initTableProduct() {
    this.spinner.show();
    this.productService.findCatalogProductByProfile().subscribe(response => {
      this.products = response;
      this.spinner.hide();
    });
  }

  /**
   * Redirecciona al componente para crear producto
   */
   public addProduct(): void {
    this.router.navigate([
      '/home/parametrization/catalogos/product-catalog/admin-product',
    ]);
  }

  /**
   * Metodo para actualizar el estado del producto
   */
   public statusProduct(product: CatalogoProductoInterface, status: boolean) {
    product.activo = status;
    this.productService.updateProductStatus(product).subscribe(
      (result) => {
        this.initTableProduct();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Redirecciona al componente para editar producto
   */
   public editProduct(product: CatalogoProductoInterface): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/product-catalog/edit-product',
        { editProfile: JSON.stringify(product) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  /**
   * Redirecciona a la tabla donde estan todos los catalogos
   */
  public back(): void {
    this.router.navigate(['/home/parametrization/catalogos'], {
      replaceUrl: true,
    });
  }
}
