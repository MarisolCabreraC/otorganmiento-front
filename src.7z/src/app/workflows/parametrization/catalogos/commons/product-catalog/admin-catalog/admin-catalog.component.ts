import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalsComponent } from '@workflows/modals/modals.component';
import { CatalogoProductoInterface } from '../model/product.model';
import { ProductService } from '../service/product.service';

@Component({
  selector: 'app-admin-catalog',
  templateUrl: './admin-catalog.component.html',
  styleUrls: ['../../../../../../../../src/assets/css/style_catalogue.scss']
})
export class AdminCatalogComponent implements OnInit {

  @ViewChild('examplemodal') modal: ModalsComponent;
  public errorCode = false;
  public errorCodeText = 'el dato no ha sido procesado';
  public mensaje: string;
  public abreviatura: string;
  public activo: boolean = true;
  public idLineaCreditoSarc: number;
  public idModalidadSarc: string;
  public idProducto: number;
  public idSarc: string;
  public idTipoPrestamoGar: string;
  public indicador: number;
  public nombre: string;
  public orden: number;
  public plazoMaxMeses: number;
  public tipoOperacion: string;
  public utilizacion: number;
  public productForm: FormGroup;
  public operacion: string = '';
  public titulo: string = '';
  public product: CatalogoProductoInterface;

  constructor(
    private productService: ProductService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    this.loadData();
    this.buildForm();
  }

  /**
   * Asigna data
   */
   loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.operacion = 'Agregar';
      this.titulo = ' producto';
    });
  }

  /**
   * Form producto
   */
   buildForm(): void {
    const user: string = localStorage.getItem('usuarioFront');
    const user2 = user.split('@');
    this.productForm = this.formBuilder.group({
      idProducto: new FormControl(this.idProducto, [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      nombre: new FormControl(this.nombre, [Validators.required, Validators.maxLength(125)]),
      abreviatura: new FormControl(this.abreviatura, [Validators.required, Validators.maxLength(125)]),
      indicador: new FormControl(this.indicador, [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      tipoOperacion: new FormControl(this.tipoOperacion, [Validators.required, Validators.maxLength(25)]),
      orden: new FormControl(this.orden, [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      plazoMaxMeses: new FormControl(this.plazoMaxMeses, [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      utilizacion: new FormControl(this.utilizacion, [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      idSarc: new FormControl(this.idSarc, [Validators.required, Validators.maxLength(25)]),
      idLineaCreditoSarc: new FormControl(this.idLineaCreditoSarc, [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      idModalidadSarc: new FormControl(this.idModalidadSarc, [Validators.required, Validators.maxLength(25)]),
      idTipoPrestamoGar: new FormControl(this.idTipoPrestamoGar, [Validators.required, Validators.maxLength(25)]),
      activo: new FormControl(this.activo),
      usuario: new FormControl(user2[0])
    });
  }

  /**
   * Metodo que crea producto
   */
   createProduct() {
    const data = {
      nombre: this.productForm.controls['nombre'].value,
      abreviatura: this.productForm.controls['abreviatura'].value,
      idLineaCreditoSarc: this.productForm.controls['idLineaCreditoSarc'].value,
      idModalidadSarc: this.productForm.controls['idModalidadSarc'].value,
      idProducto: this.productForm.controls['idProducto'].value,
      idSarc: this.productForm.controls['idSarc'].value,
      idTipoPrestamoGar: this.productForm.controls['idTipoPrestamoGar'].value,
      indicador: this.productForm.controls['indicador'].value,
      orden: this.productForm.controls['orden'].value,
      plazoMaxMeses: this.productForm.controls['plazoMaxMeses'].value,
      tipoOperacion: this.productForm.controls['tipoOperacion'].value,
      usuario: this.productForm.controls['usuario'].value,
      utilizacion: this.productForm.controls['utilizacion'].value
    }

    this.productService.createProduct(data).subscribe(
      (result) => {
        document.getElementById('openModalButtonEdit').click();
        this.router.navigate(['home/parametrization/catalogos/product-catalog'], {
          replaceUrl: true,
        });
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Metodo que abre la ventana modal para crear producto
   */
   openAddModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  /**
   * Metodo que cierra el modal y redirecciona al listado de productos
   */
  closeModalEdit() {
    this.router.navigate(['home/parametrization/catalogos/product-catalog'], {
      replaceUrl: true,
    });
  }

  /**
   * Redirecciona al listado de productos
   */
  public back(): void {
    this.router.navigate(['home/parametrization/catalogos/product-catalog'], {
      replaceUrl: true,
    });
  }
}
