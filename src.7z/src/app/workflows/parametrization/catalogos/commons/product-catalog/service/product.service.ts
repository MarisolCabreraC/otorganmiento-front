import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API_CATALOGS } from '@src/utils/catalogs';
import { Observable } from 'rxjs';
import { CatalogoProductoInterface } from '../model/product.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http: HttpClient) { }

  /**
   * Funcion que permite consumir el servicio para guardar producto.
   * @param product a guardar.
   */
   createProduct(product: CatalogoProductoInterface): Observable<CatalogoProductoInterface> {
    return this.http.post<CatalogoProductoInterface>(API_CATALOGS.ADD_CATALOG_PRODUCT, product);
  }

  /**
   * Funcion que permite consumir el servicio para actualizar un producto.
   * @param product a actualizar.
   */
  updateProduct(product: CatalogoProductoInterface): Observable<CatalogoProductoInterface> {
    return this.http.post<CatalogoProductoInterface>(API_CATALOGS.UPDATE_CATALOG_PRODUCT, product);
  }

  /**
   * Funcion que permite consumir el servicio para actualizar el estado de un producto
   * @param product estado a actualizar
   */
  updateProductStatus(product: CatalogoProductoInterface): Observable<CatalogoProductoInterface> {
    return this.http.post<CatalogoProductoInterface>(API_CATALOGS.STATUS_CATALOG_PRODUCT, product);
  }

  /**
   * Funcion que permite consumur el servicio para consultar producto
   */
  findCatalogProductByProfile(): Observable<CatalogoProductoInterface[]> {
    return this.http.post<CatalogoProductoInterface[]>(API_CATALOGS.SEARCH_CATALOG_PRODUCT, {});
  }
}
