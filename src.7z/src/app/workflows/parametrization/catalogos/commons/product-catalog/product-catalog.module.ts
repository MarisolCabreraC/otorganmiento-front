// Modules
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// Route
import { ProductCatalogRoutingModule } from './product-catalog-routing.module';

// Service
import { ProductService } from './service/product.service';

// Component
import { ProductCatalogComponent } from './product-catalog.component';

@NgModule({
  declarations: [ProductCatalogComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    ProductCatalogRoutingModule
  ],
  providers: [ProductService]
})
export class ProductCatalogModule { }
