import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminCatalogComponent } from './admin-catalog.component';

const routes: Routes = [
  {
    path: '',
    component: AdminCatalogComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminCatalogRoutingModule { }
