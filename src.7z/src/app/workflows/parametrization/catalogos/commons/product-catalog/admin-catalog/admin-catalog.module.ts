// Modules
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// Route
import { AdminCatalogRoutingModule } from './admin-catalog-routing.module';

// Service
import { ProductService } from '../service/product.service';

// Component
import { AdminCatalogComponent } from './admin-catalog.component';

@NgModule({
  declarations: [AdminCatalogComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    NgbModule,
    AdminCatalogRoutingModule
  ],
  providers: [ProductService]
})
export class AdminCatalogModule { }
