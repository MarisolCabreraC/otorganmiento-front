// Modules
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Component
import { AccountCatalogComponent } from '@workflows/parametrization/catalogos/commons/account-catalog/account-catalog.component';

const routes: Routes = [
  {
    path: '',
    component: AccountCatalogComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccountCatalogRouting { }
