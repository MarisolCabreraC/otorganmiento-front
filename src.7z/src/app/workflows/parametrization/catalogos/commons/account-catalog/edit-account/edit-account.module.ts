// Modules
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

// Route
import { EditAccountRoutingModule } from './edit-account-routing.module';

// Service
import { AccountService } from '../services/account.service';

// Component
import { EditAccountComponent } from './edit-account.component';

@NgModule({
  declarations: [EditAccountComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    NgbModule,
    EditAccountRoutingModule
  ],
  providers: [AccountService],
  exports: [EditAccountComponent]
})
export class EditAccountModule { }
