export interface Account{
    idTipoCuenta: string,
    nombre: string,
    codigoCartera: string,
    idDesembolsoMultiple:string,
    activo?: boolean,
    usuario?: string,
    code?:any,
    description?:any
}
