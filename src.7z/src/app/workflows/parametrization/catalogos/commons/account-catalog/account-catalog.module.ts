import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccountCatalogComponent } from './account-catalog.component';
import { EditAccountComponent } from './edit-account/edit-account.component';
import { AdminAccountComponent } from './admin-account/admin-account.component';

// Route
import { AccountCatalogRouting } from '@src/app/workflows/parametrization/catalogos/commons/account-catalog/account-catalog-routing.module'

// Service
import { AccountService } from '@workflows/parametrization/catalogos/commons/account-catalog/services/account.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';



@NgModule({
  declarations: [AccountCatalogComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    NgbModule,
    CommonModule,
    AccountCatalogRouting
  ],
  providers: [AccountService],
  exports:[AccountCatalogComponent]
})
export class AccountCatalogModule { }
