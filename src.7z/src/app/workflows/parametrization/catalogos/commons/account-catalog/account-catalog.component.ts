import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import {Account} from './model/interfaceAccount'
import { AccountService } from './services/account.service';
@Component({
  selector: 'app-account-catalog',
  templateUrl: './account-catalog.component.html',
  styleUrls: ['./account-catalog.component.scss']
})
export class AccountCatalogComponent implements OnInit {
  public mensaje: any;
  public editMenuOpt: boolean;
  accounts: Account[];
  constructor(
    private accountService:AccountService,
    private spinner: NgxSpinnerService,
    private router: Router
    
    ) { 
      this.editMenuOpt = JSON.parse(localStorage.getItem('paramGeneral'));
    }

  ngOnInit(): void {
    this.initTableCanal();
  }


   /**
   * Redirecciona al componente para crear tipo cuenta
   */
  public addAccount(): void {
    this.router.navigate([
      '/home/parametrization/catalogos/account-catalog/admin-account',
    ]);
  }
  /**
   * Carga la tabla con los datos de tipo cuenta
   */
  initTableCanal() {
    this.spinner.show();
    this.accountService.findCatalogAcountByProfile().subscribe(response => {
      this.accounts = response;
      this.spinner.hide();
    });
  }

  /**
   * Metodo para actualizar el estado del tipo cuenta
   */
  public statusAccount(account: Account, status: boolean) {
    account.activo = status;
    this.accountService.updateAcountStatus(account).subscribe(
      (result) => {
        this.initTableCanal();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

   /**
   * Redirecciona al componente para editar tipo cuenta
   */
  public editAccount(account: Account): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/account-catalog/edit-account',
        { editProfile: JSON.stringify(account) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  /**
   * Redirecciona a la tabla donde estan todos los catalogos
   */
  public back(): void {
    this.router.navigate(['/home/parametrization/catalogos'], {
      replaceUrl: true,
    });
  }
}
