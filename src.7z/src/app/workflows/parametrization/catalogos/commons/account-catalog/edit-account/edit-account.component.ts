import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalsComponent } from '@src/app/workflows/modals/modals.component';
import {Account} from '../model/interfaceAccount';
import { AccountService } from '../services/account.service';
@Component({
  selector: 'app-edit-account',
  templateUrl: './edit-account.component.html',
  styleUrls: ['./edit-account.component.scss']
})
export class EditAccountComponent implements OnInit {


  @ViewChild('examplemodal') modal: ModalsComponent;
  public errorCode = false;
  public errorCodeText = 'el dato no ha sido procesado';
  public mensaje: string;
  public account: Account = {
    nombre: '',
    codigoCartera: '',
    idTipoCuenta: '',
    idDesembolsoMultiple: '',
  };
  public idCanalVenta: number;
  public nombre: string;
  public valor: number;
  public descripcion: string;
  public status: boolean;
  public formAccount: FormGroup;
  public activo: boolean;
  public operacion: string = 'Editar';
  
  constructor(
    private router: Router,
    public formBuilder: FormBuilder,
    private accountService: AccountService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.loadData();
    this.buildForm();
  }

   /**
   * Metodo que carga los datos en el formulario
   */
  loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.account = JSON.parse(params['editProfile']) as Account;
     
    });
  }

  
  /**
   * Form tipo cuenta
   */
  buildForm(): void {
    this.formAccount = this.formBuilder.group({
      idTipoCuenta: new FormControl(this.account.idTipoCuenta, Validators.required),
      nombre: new FormControl(this.account.nombre, [Validators.required, Validators.maxLength(50)]),
      codigoCartera: new FormControl(this.account.codigoCartera, [Validators.required, Validators.maxLength(10),Validators.pattern("^[0-9]*$")]),
      idDesembolsoMultiple: new FormControl(this.account.idDesembolsoMultiple,[Validators.required,Validators.maxLength(38),Validators.pattern("^[0-9]*$")]),
      activo: new FormControl(this.account.activo)
    });
  }

   /**
   * Metodo que actualiza tipo cuenta
   */
  updateAccount() {
    this.mensaje = '';
    this.account.idTipoCuenta = this.formAccount.controls['idTipoCuenta'].value
    this.account.nombre = this.formAccount.controls['nombre'].value
    this.account.codigoCartera = this.formAccount.controls['codigoCartera'].value
    this.account.idDesembolsoMultiple = this.formAccount.controls['idDesembolsoMultiple'].value
    this.accountService.updateAcount(this.account).subscribe(
      (result) => {
        if(result.code == "TPC_001"){
          this.mensaje = 'Error: ' + result.description;
        }else{
          document.getElementById('modalButtonEditClose').click();
          document.getElementById('openModalButtonEditClose').click();
          
        }
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Metodo que abre la ventana modal para editar tipo cuenta
   */
  openEditModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  /**
   * Metodo que cierra el modal y redirecciona al listado de tipo cuenta
   */
  closeModalEdit() {
    this.router.navigate(['home/parametrization/catalogos/account-catalog'], { replaceUrl: true });
  }

  /**
   * Redirecciona al listado de tipo cuenta
   */
  public back(): void {
    this.router.navigate(['home/parametrization/catalogos/account-catalog'], { replaceUrl: true });
  }

}
