// Modules
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// Route
import { AdminAccountRoutingModule } from './admin-account-routing.module';

// Service
import { AccountService } from '../services/account.service';

// Component
import { AdminAccountComponent } from './admin-account.component';

@NgModule({
  declarations: [AdminAccountComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    NgbModule,
    AdminAccountRoutingModule
  ],
  providers: [AccountService],
  exports: [AdminAccountComponent]
})
export class AdminAccountModule { }
