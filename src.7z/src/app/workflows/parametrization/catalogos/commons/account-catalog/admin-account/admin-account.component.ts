import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalsComponent } from '@src/app/workflows/modals/modals.component';
import {Account} from '../model/interfaceAccount';
import { AccountService } from '../services/account.service';
@Component({
  selector: 'app-admin-account',
  templateUrl: './admin-account.component.html',
  styleUrls: ['./admin-account.component.scss']
})
export class AdminAccountComponent implements OnInit {
  @ViewChild('examplemodal') modal: ModalsComponent;
  public errorCode = false;
  public errorCodeText = 'el dato no ha sido procesado';
  public mensaje: string;
  public idCanalVenta: number;
  public activo: boolean = true;
  public nombre: string;
  public operacion: string = '';
  public titulo: string = '';
  public accountForm: FormGroup;
  public account: Account = {
    nombre: '',
    codigoCartera: '',
    idTipoCuenta: '',
    idDesembolsoMultiple: '',
  };

  constructor(
    private accountService: AccountService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public formBuilder: FormBuilder

  ) { }

  ngOnInit(): void {
    this.loadData();
    this.buildForm();
  }

   /**
   * Asigna data
   */
  loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.operacion = 'Agregar';
      this.titulo = 'Tipo cuenta';
    });
  }

   /**
   * Form tipo cuenta
   */
 
  buildForm(): void {
    this.accountForm = this.formBuilder.group({
      // idCanalVenta: new FormControl(this.idCanalVenta, [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      codigoCartera: new FormControl('',[Validators.required,Validators.maxLength(10),Validators.pattern("^[0-9]*$")]),
      nombre: new FormControl(this.nombre, [Validators.required, Validators.maxLength(50)]),
      idDesembolsoMultiple: new FormControl('',[Validators.required,Validators.maxLength(38),Validators.pattern("^[0-9]*$")]),
     
    });
  }

  /**
   * Metodo que crea tipo de cuenta
   */
  createAccount() {
    const user: string = localStorage.getItem('usuarioFront');
    const user2 = user.split('@');
    this.account.nombre = this.accountForm.controls['nombre'].value;
    this.account.idDesembolsoMultiple = this.accountForm.controls['idDesembolsoMultiple'].value
    this.account.codigoCartera = this.accountForm.controls['codigoCartera'].value;
    this.account.usuario = user2[0];

    this.accountService.createAcount(this.account).subscribe(
      (result) => {  
        if(result.code == "TPC_001"){
          this.mensaje = 'Error: ' + result.description;
        }else{
          document.getElementById('openModalButtonEdit').click();
          this.router.navigate(['home/parametrization/catalogos/account-catalog'], {
            replaceUrl: true,
          });
          
        }
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Metodo que abre la ventana modal para crear canal de venta
   */
   openAddModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  /**
   * Metodo que cierra el modal y redirecciona al listado de canal de ventas
   */
  closeModalEdit() {
    this.router.navigate(['home/parametrization/catalogos/account-catalog'], {
      replaceUrl: true,
    });
  }

  /**
   * Redirecciona al listado de canal de ventas
   */
  public back(): void {
    this.router.navigate(['home/parametrization/catalogos/account-catalog'], {
      replaceUrl: true,
    });
  }

}
