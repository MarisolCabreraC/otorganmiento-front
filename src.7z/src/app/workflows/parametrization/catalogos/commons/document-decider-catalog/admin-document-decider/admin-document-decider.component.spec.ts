import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminDocumentDeciderComponent } from './admin-document-decider.component';

describe('AdminDocumentDeciderComponent', () => {
  let component: AdminDocumentDeciderComponent;
  let fixture: ComponentFixture<AdminDocumentDeciderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminDocumentDeciderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminDocumentDeciderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
