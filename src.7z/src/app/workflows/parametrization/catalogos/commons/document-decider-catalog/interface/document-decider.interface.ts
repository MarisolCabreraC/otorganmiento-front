/**
 * Entidad que mapea la informacion obtenida del microservicio del catalogo documento decisor.
 */
 export interface DocDeciderInterface {
    /**
   * Identificador del catalogo documento decisor.
   */
    idTipoDocumentoDecisor        : number;
    /**
   * Nombre del catalogo documento decisor.
   */
    nombre         : string;
    /**
   * Usuario que crea el catalogo documento decisor.
   */
    usuario?        : string;
    /**
   * Estado del catalogo documento decisor (activo - inactivo)
   */
    activo?        : boolean;
}