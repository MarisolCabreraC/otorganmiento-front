// Modules
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

// Route
import { AdminDocumentDeciderRoutingModule } from '@workflows/parametrization/catalogos/commons/document-decider-catalog/admin-document-decider/admin-document-decider-routing.module';

// Component
import { AdminDocumentDeciderComponent } from '@workflows/parametrization/catalogos/commons/document-decider-catalog/admin-document-decider/admin-document-decider.component';

@NgModule({
  declarations: [AdminDocumentDeciderComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    NgbModule,
    AdminDocumentDeciderRoutingModule
  ]
})
export class AdminDocumentDeciderModule { }
