import { TestBed } from '@angular/core/testing';

import { DocumentDeciderService } from './document-decider.service';

describe('DocumentDeciderService', () => {
  let service: DocumentDeciderService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DocumentDeciderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
