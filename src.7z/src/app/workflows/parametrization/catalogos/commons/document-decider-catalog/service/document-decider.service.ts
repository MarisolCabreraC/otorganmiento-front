import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API_CATALOGS } from '@src/utils/catalogs';
import { Observable } from 'rxjs';
import { DocDeciderInterface } from '../interface/document-decider.interface';

@Injectable({
  providedIn: 'root'
})
export class DocumentDeciderService {

  constructor(private http: HttpClient) { }

  /**
   * Funcion que permite consumir el servicio para guardar documento decisor.
   * @param decider a guardar.
   */
   createDocDecider(decider: DocDeciderInterface): Observable<DocDeciderInterface> {
    return this.http.post<DocDeciderInterface>(API_CATALOGS.ADD_CATALOG_DOC_DECIDER, decider);
  }

  /**
   * Funcion que permite consumir el servicio para actualizar un documento decisor.
   * @param decider a actualizar.
   */
  updateDocDecider(decider: DocDeciderInterface): Observable<DocDeciderInterface> {
    return this.http.post<DocDeciderInterface>(API_CATALOGS.UPDATE_CATALOG_DOC_DECIDER, decider);
  }

  /**
   * Funcion que permite consumir el servicio para actualizar el estado de documento decisor
   * @param decider estado a actualizar
   */
  updateDocDeciderStatus(decider: DocDeciderInterface): Observable<DocDeciderInterface> {
    return this.http.post<DocDeciderInterface>(API_CATALOGS.STATUS_CATALOG_DOC_DECIDER, decider);
  }

  /**
   * Funcion que permite consumur el servicio para consultar documento decisor
   */
   listDocDecider(): Observable<DocDeciderInterface[]> {
    return this.http.post<DocDeciderInterface[]>(API_CATALOGS.LIST_CATALOG_DOC_DECIDER, {});
  }
}
