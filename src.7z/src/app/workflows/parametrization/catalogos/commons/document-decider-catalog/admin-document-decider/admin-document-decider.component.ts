import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ModalsComponent } from '@workflows/modals/modals.component';
import { DocDeciderInterface } from '../interface/document-decider.interface';
import { DocumentDeciderService } from '../service/document-decider.service';

@Component({
  selector: 'app-admin-document-decider',
  templateUrl: './admin-document-decider.component.html',
  styleUrls: ['../../../../../../../../src/assets/css/style_catalogue.scss']
})
export class AdminDocumentDeciderComponent implements OnInit {

  @ViewChild('examplemodal') modal: ModalsComponent;
  mensaje: string;
  idTipoDocumentoDecisor: number;
  activo: boolean;
  nombre: string;
  boton: string = '';
  operacion: string = '';
  titulo: string = '';
  docDeciderForm: FormGroup;
  docDecider: DocDeciderInterface;

  constructor(private deciderService: DocumentDeciderService, private router: Router, private activatedRoute: ActivatedRoute, public formBuilder: FormBuilder) {
    this.activatedRoute.params.subscribe((params) => {
      if (params.editProfile) {
        this.operacion = 'Editar';
        this.titulo = ' tipo documento decisor';
        this.boton = 'Actualizar';
        this.loadData();
      } else {
        this.operacion = 'Agregar';
        this.titulo = ' tipo documento decisor';
        this.boton = 'Crear';
      }
    });
  }

  ngOnInit(): void {
    this.buildForm();
  }

  /**
   * Carga data documento decisor
   */
   loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.docDecider = JSON.parse(params['editProfile']) as DocDeciderInterface;
      this.nombre = this.docDecider.nombre;
      this.idTipoDocumentoDecisor = this.docDecider.idTipoDocumentoDecisor;
    });
  }

  /**
   * Form documento decisor
   */
  buildForm(): void {
    const user: string = localStorage.getItem('usuarioFront');
    const user2 = user.split('@');
    this.docDeciderForm = this.formBuilder.group({
      idTipoDocumentoDecisor: new FormControl(this.idTipoDocumentoDecisor, [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      nombre: new FormControl(this.nombre, [Validators.required, Validators.maxLength(125)]),
      activo: new FormControl(this.activo),
      usuario: new FormControl(user2[0])
    });
  }

  /**
   * Metodo que crea documento decisor
   */
   createDocDecider() {
    const data = {
      nombre: this.docDeciderForm.controls['nombre'].value,
      usuario: this.docDeciderForm.controls['usuario'].value,
      idTipoDocumentoDecisor: this.docDeciderForm.controls['idTipoDocumentoDecisor'].value
    }

    this.deciderService.createDocDecider(data).subscribe(
      (result) => {
        document.getElementById('openModalButtonEdit').click();
        this.router.navigate(
          ['home/parametrization/catalogos/document-decider-catalog'],
          {
            replaceUrl: true,
          }
        );
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Metodo que actualiza documento decisor
   */
   updateDocDecider() {
    this.mensaje = '';
    this.docDecider.nombre = this.docDeciderForm.controls['nombre'].value;
    this.docDecider.idTipoDocumentoDecisor = this.docDeciderForm.controls['idTipoDocumentoDecisor'].value;
    this.deciderService.updateDocDecider(this.docDecider).subscribe(
      (result) => {
        document.getElementById('modalButtonEditClose').click();
        document.getElementById('openModalButtonEditClose').click();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Metodo que abre la ventana modal para crear documento decisor
   */
  openModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  /**
   * Metodo que cierra el modal y redirecciona al listado de documento decisor
   */
  closeModalEdit() {
    this.router.navigate(['home/parametrization/catalogos/document-decider-catalog'], {
      replaceUrl: true,
    });
  }

  /**
   * Redirecciona al listado de documento decisor
   */
  back(): void {
    this.router.navigate(['home/parametrization/catalogos/document-decider-catalog'], {
      replaceUrl: true,
    });
  }

}
