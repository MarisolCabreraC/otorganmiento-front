// Modules
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Component
import { AdminDocumentDeciderComponent } from './admin-document-decider.component';

const routes: Routes = [
  {
    path: '',
    component: AdminDocumentDeciderComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminDocumentDeciderRoutingModule { }
