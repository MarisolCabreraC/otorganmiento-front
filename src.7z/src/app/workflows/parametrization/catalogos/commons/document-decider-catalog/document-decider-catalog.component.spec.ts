import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentDeciderCatalogComponent } from './document-decider-catalog.component';

describe('DocumentDeciderCatalogComponent', () => {
  let component: DocumentDeciderCatalogComponent;
  let fixture: ComponentFixture<DocumentDeciderCatalogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentDeciderCatalogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentDeciderCatalogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
