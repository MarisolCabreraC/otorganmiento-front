// Modules
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

// Route
import { DocumentDeciderCatalogRoutingModule } from '@workflows/parametrization/catalogos/commons/document-decider-catalog/document-decider-catalog-routing.module';

// Component
import { DocumentDeciderCatalogComponent } from '@workflows/parametrization/catalogos/commons/document-decider-catalog/document-decider-catalog.component';

@NgModule({
  declarations: [DocumentDeciderCatalogComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    DocumentDeciderCatalogRoutingModule
  ]
})
export class DocumentDeciderCatalogModule { }
