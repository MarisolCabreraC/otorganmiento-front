import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { DocDeciderInterface } from './interface/document-decider.interface';
import { DocumentDeciderService } from './service/document-decider.service';

@Component({
  selector: 'app-document-decider-catalog',
  templateUrl: './document-decider-catalog.component.html',
  styleUrls: ['../../../../../../../src/assets/css/style_catalogue.scss']
})
export class DocumentDeciderCatalogComponent implements OnInit {

  mensaje: any;
  editMenuOpt: boolean;
  deciders: DocDeciderInterface[];

  constructor(private router: Router, private spinner: NgxSpinnerService, private deciderService: DocumentDeciderService) {
    this.editMenuOpt = JSON.parse(localStorage.getItem('paramGeneral'));
  }

  ngOnInit(): void {
    this.initTableDocDecider();
  }

  /**
   * Carga la tabla con los datos del catalogo documento decisor
   */
  initTableDocDecider() {
    this.spinner.show();
    this.deciderService.listDocDecider().subscribe(response => {
      this.deciders = response;
    });
  }

  /**
   * Redirecciona al componente para crear documento decisor
   */
  addDocDecider(): void {
    this.router.navigate([
      '/home/parametrization/catalogos/document-decider-catalog/admin-document-decider',
    ]);
  }

  /**
   * Metodo para actualizar el estado del catalogo documento decisor
   */
  statusDocDecider(docDecider: DocDeciderInterface, status: boolean) {
    docDecider.activo = status;
    this.deciderService.updateDocDeciderStatus(docDecider).subscribe(
      (result) => {
        this.initTableDocDecider();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Redirecciona al componente para editar documento decisor
   */
  editDocDecider(docDecider: DocDeciderInterface): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/document-decider-catalog/admin-document-decider',
        { editProfile: JSON.stringify(docDecider) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  /**
   * Redirecciona a la tabla donde estan todos los catalogos
   */
  back(): void {
    this.router.navigate(['/home/parametrization/catalogos'], {
      replaceUrl: true,
    });
  }

}
