import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminCatalogFlowComponent } from './admin-typeflow.component';

describe('AdminCatalogFlowComponent', () => {
  let component: AdminCatalogFlowComponent;
  let fixture: ComponentFixture<AdminCatalogFlowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AdminCatalogFlowComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminCatalogFlowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
