import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TypeFlowCatalogComponent } from './type-flow-catalog.component';

describe('TypeFlowCatalogComponent', () => {
  let component: TypeFlowCatalogComponent;
  let fixture: ComponentFixture<TypeFlowCatalogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TypeFlowCatalogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TypeFlowCatalogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
