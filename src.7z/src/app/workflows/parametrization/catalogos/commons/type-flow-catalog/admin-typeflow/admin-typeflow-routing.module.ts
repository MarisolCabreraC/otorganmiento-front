// Modules
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Component
import { AdminCatalogFlowComponent } from './admin-typeflow.component';

const routes: Routes = [
  {
    path: '',
    component: AdminCatalogFlowComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminTypeflowRoutingModule { }
