// Modules
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

// Route
import { TypeFlowCatalogRoutingModule } from '@workflows/parametrization/catalogos/commons/type-flow-catalog/type-flow-catalog-routing.module';

// Service
import { TypeflowService } from '@workflows/parametrization/catalogos/commons/type-flow-catalog/service/typeflow.service';

// Components
import { TypeFlowCatalogComponent } from '@workflows/parametrization/catalogos/commons/type-flow-catalog/type-flow-catalog.component';

@NgModule({
  declarations: [
    TypeFlowCatalogComponent
  ],
  imports: [
    CommonModule,
    TypeFlowCatalogRoutingModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    NgbModule,
    SharedModule
  ],
  providers: [TypeflowService]
})
export class TypeFlowCatalogModule { }
