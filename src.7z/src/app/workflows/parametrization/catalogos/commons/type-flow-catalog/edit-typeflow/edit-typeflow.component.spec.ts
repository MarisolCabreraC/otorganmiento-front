import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditTypeflowComponent } from './edit-typeflow.component';

describe('EditTypeflowComponent', () => {
  let component: EditTypeflowComponent;
  let fixture: ComponentFixture<EditTypeflowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditTypeflowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditTypeflowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
