import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CatalogProductFlowResponse } from '@src/app/commons/models/catalogProductFlowResponse';
import { API_CATALOGS } from '@src/utils/catalogs';
import { Observable } from 'rxjs';
import { InfoCatalogoTipoFlujo } from '../model/typeflow.model';

@Injectable({
  providedIn: 'root'
})
export class TypeflowService {

  constructor(private http: HttpClient) { }

  /**
   * Funcion que permite consumir el servicio para guardar tipo flujo.
   * @param product tipo flujo a guardar.
   */
   createProductTypeFlow(product: InfoCatalogoTipoFlujo): Observable<InfoCatalogoTipoFlujo> {
    return this.http.post<InfoCatalogoTipoFlujo>(API_CATALOGS.ADD_CATALOG_TYPE_FLOW, product);
  }

  /**
   * Funcion que permite consumir el servicio para actualizar tipo flujo.
   * @param product tipo flujo a actualizar.
   */
  updateTypeFlow(product: InfoCatalogoTipoFlujo): Observable<InfoCatalogoTipoFlujo> {
    return this.http.post<InfoCatalogoTipoFlujo>(API_CATALOGS.UPDATE_CATALOG_TYPE_FLOW, product);
  }

  /**
   * Funcion que permite consumir el servicio para actualizar un tipo flujo.
   * @param product tipo flujo a actualizar.
   */
   updateProductTypeFlowStatus(product: InfoCatalogoTipoFlujo): Observable<InfoCatalogoTipoFlujo> {
    return this.http.post<InfoCatalogoTipoFlujo>(API_CATALOGS.STATUS_CATALOG_TYPE_FLOW, product);
  }

  /**
   * Funcion que permite consumur el servicio para consultar tipo flujo.
   */
  findProductTypeFlowByProfile(): Observable<InfoCatalogoTipoFlujo[]> {
    return this.http.post<InfoCatalogoTipoFlujo[]>(API_CATALOGS.SEARCH_CATALOG_TYPE_FLOW, {});
  }
}
