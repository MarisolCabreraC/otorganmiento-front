// Module
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Component
import { TypeFlowCatalogComponent } from '@workflows/parametrization/catalogos/commons/type-flow-catalog/type-flow-catalog.component';

const routes: Routes = [
  {
    path: '',
    component: TypeFlowCatalogComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TypeFlowCatalogRoutingModule { }
