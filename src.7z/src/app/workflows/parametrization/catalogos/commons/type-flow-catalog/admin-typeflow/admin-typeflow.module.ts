// Modules
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// Route
import { AdminTypeflowRoutingModule } from './admin-typeflow-routing.module';

// Service
import { TypeflowService } from '../service/typeflow.service';

// Component
import { AdminCatalogFlowComponent } from './admin-typeflow.component';

@NgModule({
  declarations: [AdminCatalogFlowComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    NgbModule,
    SharedModule,
    AdminTypeflowRoutingModule
    
  ],
  providers: [TypeflowService]
})
export class AdminTypeflowModule { }
