import { Component, OnInit, ViewChild } from '@angular/core';
import { InfoCatalogoTipoFlujo } from '../model/typeflow.model';
import { ModalsComponent } from '@workflows/modals/modals.component';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { TypeflowService } from '../service/typeflow.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-edit-typeflow',
  templateUrl: './edit-typeflow.component.html',
  styleUrls: ['../../../../../../../../src/assets/css/style_catalogue.scss']
})
export class EditTypeflowComponent implements OnInit {

  @ViewChild('examplemodal') modal: ModalsComponent;
  public errorCode = false;
  public errorCodeText = 'el dato no ha sido procesado';
  public mensaje: string;
  public typeFlow: InfoCatalogoTipoFlujo;
  public idFlujo: number;
  public nombre: string;
  public valor: number;
  public descripcion: string;
  public status: boolean;
  public form: FormGroup;
  public activo: boolean;
  public operacion: string = 'Editar';

  constructor(private router: Router,
    public formBuilder: FormBuilder,
    private typeFlowService: TypeflowService,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.loadData();
    this.buildForm();
  }

  /**
   * Metodo que carga los datos en el formulario
   */
  loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.typeFlow = JSON.parse(params['editProfile']) as InfoCatalogoTipoFlujo;
      this.nombre = this.typeFlow.nombre;
      this.idFlujo = this.typeFlow.idFlujo;

      if (this.nombre == null) {
        this.status = true;
      }
    });
  }

  /**
   * Form tipo flujo.
   */
  buildForm(): void {
    this.form = this.formBuilder.group({
      idFlujo: new FormControl(this.idFlujo),
      nombre: new FormControl(this.nombre, [Validators.required, Validators.maxLength(50)]),
      activo: new FormControl(this.activo)
    });
  }

  /**
   * Metodo que actualiza tipo flujo.
   */
  updateTypeFlow() {
    this.mensaje = '';
    this.typeFlow.nombre = this.form.controls['nombre'].value;
    this.typeFlowService.updateTypeFlow(this.typeFlow).subscribe(
      (result) => {
        document.getElementById('modalButtonEditClose').click();
        document.getElementById('openModalButtonEditClose').click();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Metodo que abre la ventana modal para editar tipo flujo.
   */
   openEditModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  /**
   * Metodo que cierra el modal y redirecciona al listado de tipo flujo.
   */
   closeModalEdit() {
    this.router.navigate(['home/parametrization/catalogos/product-catalog-type-flow'], { replaceUrl: true });
  }

  /**
   * Redirecciona al listado de tipo flujo.
   */
  public back(): void {
    this.router.navigate(['home/parametrization/catalogos/product-catalog-type-flow'], { replaceUrl: true });
  }

}
