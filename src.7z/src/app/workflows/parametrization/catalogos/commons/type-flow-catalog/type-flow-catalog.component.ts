import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { InfoCatalogoTipoFlujo } from './model/typeflow.model';
import { TypeflowService } from './service/typeflow.service';

@Component({
  selector: 'app-type-flow-catalog',
  templateUrl: './type-flow-catalog.component.html',
  styleUrls: ['../../../../../../../src/assets/css/style_catalogue.scss']
})
export class TypeFlowCatalogComponent implements OnInit {

  public mensaje: any;
  public editMenuOpt: boolean;
  typeflows: InfoCatalogoTipoFlujo[];

  constructor(private router: Router, private typeflowService: TypeflowService, private spinner: NgxSpinnerService) {
    this.editMenuOpt = JSON.parse(localStorage.getItem('paramGeneral'));
  }

  ngOnInit(): void {
    this.initTableTypeFlow();
  }

  /**
   * Carga la tabla con los datos de tipo flujo.
   */
  initTableTypeFlow() {
    this.spinner.show();
    this.typeflowService.findProductTypeFlowByProfile().subscribe(response => {
      this.typeflows = response;
      this.spinner.hide();
    });
  }

  /**
   * Redirecciona al componente para crear canal de venta
   */
  public addTypeFlowProduct(): void {
    this.router.navigate([
      '/home/parametrization/catalogos/product-catalog-type-flow/admin-type-flow'
    ]);
  }

  /**
   * Metodo para actualizar el estado de tipo flujo.
   */
  public statusTypeFlowProduct(typeflow: InfoCatalogoTipoFlujo, status: boolean) {
    typeflow.activo = status;
    this.typeflowService.updateProductTypeFlowStatus(typeflow).subscribe(
      (result) => {
        this.initTableTypeFlow();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Redirecciona al componente para editar tipo flujo.
   */
   public editTypeFlow(product: InfoCatalogoTipoFlujo): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/product-catalog-type-flow/edit-type-flow',
        { editProfile: JSON.stringify(product) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  /**
   * Redirecciona a la tabla donde estan todos los catalogos.
   */
  public back(): void {
    this.router.navigate(['/home/parametrization/catalogos'], {
      replaceUrl: true,
    });
  }
}
