// Modules
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Component
import { EditTypeflowComponent } from '@workflows/parametrization/catalogos/commons/type-flow-catalog/edit-typeflow/edit-typeflow.component';

const routes: Routes = [
  {
    path: '',
    component: EditTypeflowComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EditTypeflowRoutingModule { }
