// Modules
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

// Route
import { EditTypeflowRoutingModule } from './edit-typeflow-routing.module';

// Service
import { TypeflowService } from '../service/typeflow.service';

// Component
import { EditTypeflowComponent } from './edit-typeflow.component';


@NgModule({
  declarations: [EditTypeflowComponent],
  imports: [
    CommonModule,
    EditTypeflowRoutingModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    NgbModule,
    SharedModule
  ],
  providers: [TypeflowService]
})
export class EditTypeflowModule { }
