import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalsComponent } from '@workflows/modals/modals.component';
import { InfoCatalogoTipoFlujo } from '../model/typeflow.model';
import { TypeflowService } from '@workflows/parametrization/catalogos/commons/type-flow-catalog/service/typeflow.service';

@Component({
  selector: 'app-admin-typeflow',
  templateUrl: './admin-typeflow.component.html',
  styleUrls: ['../../../../../../../../src/assets/css/style_catalogue.scss']
})
export class AdminCatalogFlowComponent implements OnInit {

  @ViewChild('examplemodal') modal: ModalsComponent;
  public errorCode = false;
  public errorCodeText = 'el dato no ha sido procesado';
  public mensaje: string;
  public idFlujo: number;
  public activo: boolean = true;
  public nombre: string;
  public operacion: string = '';
  public titulo: string = '';
  public typeForm: FormGroup;
  public typeflow: InfoCatalogoTipoFlujo;

  constructor(
    private typeflowService: TypeflowService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    this.loadData();
    this.buildForm();
  }

  /**
   * Asigna data
   */
  loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.operacion = 'Agregar';
      this.titulo = ' tipo flujo';
    });
  }

  /**
   * Form tipo flujo
   */
  buildForm(): void {
    const user: string = localStorage.getItem('usuarioFront');
    const user2 = user.split('@');
    this.typeForm = this.formBuilder.group({
      idFlujo: new FormControl(this.idFlujo, [Validators.required, Validators.maxLength(10), Validators.pattern("^[0-9]*$")]),
      nombre: new FormControl(this.nombre, [Validators.required, Validators.maxLength(50)]),
      activo: new FormControl(this.activo),
      usuario: new FormControl(user2[0])
    });
  }

  /**
   * Metodo que crea tipo flujo
   */
  createProductTypeFlow() {
    const data = {
      nombre: this.typeForm.controls['nombre'].value,
      usuario: this.typeForm.controls['usuario'].value,
      idFlujo: this.typeForm.controls['idFlujo'].value
    }

    this.typeflowService.createProductTypeFlow(data).subscribe(
      (result) => {
        document.getElementById('openModalButtonEdit').click();
        this.router.navigate(
          ['home/parametrization/catalogos/product-catalog-type-flow'],
          { replaceUrl: true }
        );
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Metodo que abre la ventana modal para crear tipo flujo.
   */
   openAddModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  /**
   * Redirecciona al listado de tipo flujo
   */
  public back(): void {
    this.router.navigate(
      ['home/parametrization/catalogos/product-catalog-type-flow'],
      {
        replaceUrl: true,
      }
    );
  }
}
