import { TestBed } from '@angular/core/testing';

import { TypeflowService } from './typeflow.service';

describe('TypeflowService', () => {
  let service: TypeflowService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TypeflowService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
