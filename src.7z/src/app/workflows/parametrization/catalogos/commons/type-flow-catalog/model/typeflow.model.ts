/**
 * Entidad que mapea la informacion obtenida del microservicio de tipo flujo.
 */
export interface InfoCatalogoTipoFlujo {
  /**
   * Identificador del tipo flujo.
   */
    idFlujo: number;
    /**
   * Nombre del tipo flujo.
   */
    nombre: string;
    /**
   * Usuario que crea el catalogo tipo flujo.
   */
     usuario?        : string;
    /**
   * Estado del canal (activo - inactivo)
   */
    activo?: boolean;
}