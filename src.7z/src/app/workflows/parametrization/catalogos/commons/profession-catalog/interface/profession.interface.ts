/**
 * Entidad que mapea la informacion obtenida del microservicio del catalogo profesion.
 */
 export interface ProfessionInterface {
    /**
   * Identificador del catalogo profesion.
   */
     idProfesion        : number;
    /**
   * Nombre del catalogo profesion.
   */
    nombre         : string;
    /**
   * Usuario que crea el catalogo profesion.
   */
    usuario?        : string;
    /**
   * Estado del catalogo profesion (activo - inactivo)
   */
    activo?        : boolean;
}