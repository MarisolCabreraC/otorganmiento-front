import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfessionCatalogComponent } from './profession-catalog.component';

describe('ProfessionCatalogComponent', () => {
  let component: ProfessionCatalogComponent;
  let fixture: ComponentFixture<ProfessionCatalogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfessionCatalogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfessionCatalogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
