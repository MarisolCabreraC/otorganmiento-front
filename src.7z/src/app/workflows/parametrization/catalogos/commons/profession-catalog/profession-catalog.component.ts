import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ProfessionInterface } from './interface/profession.interface';
import { ProfessionService } from './service/profession.service';

@Component({
  selector: 'app-profession-catalog',
  templateUrl: './profession-catalog.component.html',
  styleUrls: ['../../../../../../../src/assets/css/style_catalogue.scss']
})
export class ProfessionCatalogComponent implements OnInit {

  mensaje: any;
  editMenuOpt: boolean;
  professions: ProfessionInterface[];
  filter = '';

  constructor(private router: Router, private spinner: NgxSpinnerService, private professionService: ProfessionService) {
    this.editMenuOpt = JSON.parse(localStorage.getItem('paramGeneral'));
  }

  ngOnInit(): void {
    this.initTableProfession();
  }

  initTableProfession() {
    this.spinner.show();
    this.professionService.listProfession().subscribe(response => {
      this.professions = response;
    });
  }

  public addProfession(): void {
    this.router.navigate([
      '/home/parametrization/catalogos/profession-catalog/admin-profession',
    ]);
  }

  public refreshProfession(): void {
    this.router.navigate([
      '/home/parametrization/catalogos/profession-catalog',
    ]);
  }

  public statusProfession(product: ProfessionInterface, status: boolean) {
    product.activo = status;
    this.professionService.updateProfessionStatus(product).subscribe(
      (result) => {
        this.refreshProfession();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  editProfession(profession: ProfessionInterface): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/profession-catalog/admin-profession',
        { editProfile: JSON.stringify(profession) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  public back(): void {
    this.router.navigate(['/home/parametrization/catalogos'], {
      replaceUrl: true,
    });
  }
}
