import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API_CATALOGS } from '@src/utils/catalogs';
import { Observable } from 'rxjs';
import { ProfessionInterface } from '../interface/profession.interface';

@Injectable({
  providedIn: 'root'
})
export class ProfessionService {

  constructor(private http: HttpClient) { }

  /**
   * Funcion que permite consumir el servicio para guardar profession.
   * @param profession a guardar.
   */
   createProfession(profession: ProfessionInterface): Observable<ProfessionInterface> {
    return this.http.post<ProfessionInterface>(API_CATALOGS.ADD_CATALOG_PROFESSION, profession);
  }

  /**
   * Funcion que permite consumir el servicio para actualizar un profession.
   * @param profession a actualizar.
   */
  updateProfession(profession: ProfessionInterface): Observable<ProfessionInterface> {
    return this.http.post<ProfessionInterface>(API_CATALOGS.UPDATE_CATALOG_PROFESSION, profession);
  }

  /**
   * Funcion que permite consumir el servicio para actualizar el estado de profession
   * @param profession estado a actualizar
   */
  updateProfessionStatus(profession: ProfessionInterface): Observable<ProfessionInterface> {
    return this.http.post<ProfessionInterface>(API_CATALOGS.STATUS_CATALOG_PROFESSION, profession);
  }

  /**
   * Funcion que permite consumur el servicio para consultar profession
   */
   listProfession(): Observable<ProfessionInterface[]> {
    return this.http.post<ProfessionInterface[]>(API_CATALOGS.LIST_CATALOG_PROFESSION, {});
  }
}
