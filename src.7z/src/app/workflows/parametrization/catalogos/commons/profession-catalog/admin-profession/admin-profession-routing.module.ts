import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminProfessionComponent } from './admin-profession.component';


const routes: Routes = [{
  path: '',
  component: AdminProfessionComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminProfessionRoutingModule { }
