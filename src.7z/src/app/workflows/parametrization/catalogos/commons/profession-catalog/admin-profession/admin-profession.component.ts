import { Component, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalsComponent } from '@workflows/modals/modals.component';
import { ProfessionInterface } from '../interface/profession.interface';
import { ProfessionService } from '../service/profession.service';

@Component({
  selector: 'app-admin-profession',
  templateUrl: './admin-profession.component.html',
  styleUrls: ['../../../../../../../../src/assets/css/style_catalogue.scss']
})
export class AdminProfessionComponent implements OnInit {

  @ViewChild('examplemodal') modal: ModalsComponent;
  public errorCode = false;
  public errorCodeText = 'el dato no ha sido procesado';
  public mensaje: string;
  public idProfesion: number;
  public activo: boolean;
  public nombre: string;
  public operacion: string = '';
  public titulo: string = '';
  public boton: string = '';
  public status: boolean;
  public professionForm: FormGroup;
  public profession: ProfessionInterface;

  constructor(private professionService: ProfessionService, private router: Router, private activatedRoute: ActivatedRoute, public formBuilder: FormBuilder) {
    this.activatedRoute.params.subscribe((params) => {
      if (params.editProfile) {
        this.operacion = 'Editar';
        this.titulo = ' Profesión';
        this.boton = 'Actualizar';
        this.loadData();
      } else {
        this.operacion = 'Agregar';
        this.titulo = ' Profesión';
        this.boton = 'Crear';
      }
    });
  }

  ngOnInit(): void {
    this.buildForm();
  }

  /**
   * Carga data
   */
   loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.profession = JSON.parse(params['editProfile']) as ProfessionInterface;
      this.nombre = this.profession.nombre;
      this.idProfesion = this.profession.idProfesion;

      if (this.nombre == null) {
        this.status = true;
      }
    });
  }

  /**
   * Form rol
   */
   buildForm(): void {
    const user: string = localStorage.getItem('usuarioFront');
    const user2 = user.split('@');
    this.professionForm = this.formBuilder.group({
      idProfesion: new FormControl(this.idProfesion, [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      nombre: new FormControl(this.nombre, [Validators.required, Validators.maxLength(125)]),
      usuario: new FormControl(user2[0])
    });
  }

  createProfession() {
    const data = {
      nombre: this.professionForm.controls['nombre'].value,
      idProfesion: this.professionForm.controls['idProfesion'].value,
      usuario: this.professionForm.controls['usuario'].value
    }
    this.professionService.createProfession(data).subscribe(
      (result) => {
        document.getElementById('openModalButtonEdit').click();
        this.router.navigate(
          ['home/parametrization/catalogos/profession-catalog'],
          {
            replaceUrl: true,
          }
        );
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  updateProfession() {
    this.mensaje = '';
    this.profession.nombre = this.professionForm.controls['nombre'].value;
    this.profession.idProfesion = this.professionForm.controls['idProfesion'].value;
    this.professionService.updateProfession(this.profession).subscribe(
      (result) => {
        document.getElementById('modalButtonEditClose').click();
        document.getElementById('openModalButtonEditClose').click();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  openModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  closeModalEdit() {
    this.router.navigate(
      ['home/parametrization/catalogos/profession-catalog'],
      {
        replaceUrl: true,
      }
    );
  }
  public back(): void {
    this.router.navigate(
      ['home/parametrization/catalogos/profession-catalog'],
      {
        replaceUrl: true,
      }
    );
  }
}
