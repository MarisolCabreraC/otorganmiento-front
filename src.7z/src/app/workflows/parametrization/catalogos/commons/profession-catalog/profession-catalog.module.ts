// Module
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';

// Pipe
import { PipesModule } from '@src/app/commons/pipes/pipes.module';

// Route
import { ProfessionCatalogRoutingModule } from './profession-catalog-routing.module';

// Component
import { ProfessionCatalogComponent } from './profession-catalog.component';

@NgModule({
  declarations: [ProfessionCatalogComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    NgbModule,
    PipesModule,
    ProfessionCatalogRoutingModule
  ],
  exports:[ProfessionCatalogComponent]
})
export class ProfessionCatalogModule { }
