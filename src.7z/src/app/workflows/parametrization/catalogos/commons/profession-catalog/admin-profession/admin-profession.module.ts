import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AdminProfessionRoutingModule } from './admin-profession-routing.module';
import { AdminProfessionComponent } from './admin-profession.component';



@NgModule({
  declarations: [AdminProfessionComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    NgbModule,
    AdminProfessionRoutingModule
  ],
  exports:[AdminProfessionComponent]
})
export class AdminProfessionModule { }
