import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminProfessionComponent } from './admin-profession.component';

describe('AdminProfessionComponent', () => {
  let component: AdminProfessionComponent;
  let fixture: ComponentFixture<AdminProfessionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminProfessionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminProfessionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
