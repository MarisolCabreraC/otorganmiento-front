import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminFestiveComponent } from '@workflows/parametrization/catalogos/commons/festive-catalog/admin-festive/admin-festive.component';


const routes: Routes = [
  {
    path: '',
    component: AdminFestiveComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminFestiveRoutingModule { }
