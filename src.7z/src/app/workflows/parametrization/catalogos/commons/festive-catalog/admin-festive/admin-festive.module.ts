import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from '@src/app/commons/shared/shared.module';

import { AdminFestiveRoutingModule } from '@workflows/parametrization/catalogos/commons/festive-catalog/admin-festive/admin-festive-routing.module';
import { AdminFestiveComponent } from '@workflows/parametrization/catalogos/commons/festive-catalog/admin-festive/admin-festive.component';
import { FestiveService } from '@workflows/parametrization/catalogos/commons/festive-catalog/service/festive.service';

@NgModule({
  declarations: [AdminFestiveComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    NgbModule,
    AdminFestiveRoutingModule,
  ],
  providers: [FestiveService],
  exports: [AdminFestiveComponent]
})
export class AdminFestiveModule { }
