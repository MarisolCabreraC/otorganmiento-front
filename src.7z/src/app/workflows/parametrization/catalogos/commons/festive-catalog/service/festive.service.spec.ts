import { TestBed } from '@angular/core/testing';

import { FestiveService } from './festive.service';

describe('FestiveService', () => {
  let service: FestiveService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FestiveService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
