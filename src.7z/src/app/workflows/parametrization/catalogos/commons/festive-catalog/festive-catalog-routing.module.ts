// Modules
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FestiveCatalogComponent } from '@workflows/parametrization/catalogos/commons/festive-catalog/festive-catalog.component';

const routes: Routes = [
  {
    path: '', component: FestiveCatalogComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FestiveCatalogRoutingModule { }
