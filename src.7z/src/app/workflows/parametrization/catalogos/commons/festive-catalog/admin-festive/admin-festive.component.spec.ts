import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminFestiveComponent } from './admin-festive.component';

describe('AdminFestiveComponent', () => {
  let component: AdminFestiveComponent;
  let fixture: ComponentFixture<AdminFestiveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminFestiveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminFestiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
