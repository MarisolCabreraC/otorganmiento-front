import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InfoCatalogoFestivo } from '@src/app/commons/models/infoCatalogoFestivo';
import { FestiveService } from '@workflows/parametrization/catalogos/commons/festive-catalog/service/festive.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-festive-catalog',
  templateUrl: './festive-catalog.component.html',
  styleUrls: ['../../../../../../../src/assets/css/style_catalogue.scss']
})
export class FestiveCatalogComponent implements OnInit {

  public mensaje: any;
  public editMenuOpt: boolean;
  festives: InfoCatalogoFestivo[];

  constructor(private router: Router, private festiveService: FestiveService, private spinner: NgxSpinnerService) {
    this.editMenuOpt = JSON.parse(localStorage.getItem('paramGeneral'));
  }

  ngOnInit(): void {
    this.initTableFestive();
  }

  initTableFestive() {
    this.spinner.show();
    this.festiveService.findCatalogFestiveByProfile().subscribe(response => {
      this.festives = response;
      this.spinner.hide();
    });
  }

  public addFestive(): void {
    this.router.navigate([
      '/home/parametrization/catalogos/festive-catalog/admin-festive',
    ]);
  }

  public statusFestive(festive: InfoCatalogoFestivo, status: boolean) {
    festive.activo = status;
    this.festiveService.updateFestiveStatus(festive).subscribe(
      (result) => {
        this.initTableFestive();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  public editFestive(festive: InfoCatalogoFestivo): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/festive-catalog/edit-festive',
        { editProfile: JSON.stringify(festive) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  public back(): void {
    this.router.navigate(['/home/parametrization/catalogos'], {
      replaceUrl: true,
    });
  }

}
