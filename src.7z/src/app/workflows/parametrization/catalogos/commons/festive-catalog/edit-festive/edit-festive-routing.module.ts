import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EditFestiveComponent } from './edit-festive.component';


const routes: Routes = [
  {
    path: '',
    component: EditFestiveComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EditFestiveRoutingModule { }
