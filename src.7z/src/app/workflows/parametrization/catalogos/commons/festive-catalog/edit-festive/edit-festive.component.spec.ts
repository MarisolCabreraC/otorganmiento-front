import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditFestiveComponent } from './edit-festive.component';

describe('EditFestiveComponent', () => {
  let component: EditFestiveComponent;
  let fixture: ComponentFixture<EditFestiveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditFestiveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditFestiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
