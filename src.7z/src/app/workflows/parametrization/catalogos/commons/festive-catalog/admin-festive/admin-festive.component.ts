import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { InfoCatalogoFestivo } from '@src/app/commons/models/infoCatalogoFestivo';
import { ModalsComponent } from '@workflows/modals/modals.component';
import { FestiveService } from '../service/festive.service';

@Component({
  selector: 'app-admin-festive',
  templateUrl: './admin-festive.component.html',
  styleUrls: ['../../../../../../../../src/assets/css/style_catalogue.scss']
})
export class AdminFestiveComponent implements OnInit {

  @ViewChild('examplemodal') modal: ModalsComponent;
  public errorCode = false;
  public errorCodeText = 'el dato no ha sido procesado';
  public mensaje: string;
  public idDiaNoHabil: number;
  public activo: boolean = true;
  public descripcion: string;
  public dia: string;
  public operacion = '';
  public titulo = '';
  public festiveForm: FormGroup;
  public festive: InfoCatalogoFestivo;

  constructor(private festiveService: FestiveService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public formBuilder: FormBuilder,
    private datePipe: DatePipe
    ) { }

  ngOnInit(): void {
    this.loadData();
    this.buildForm();
  }

  /**
   * Asigna data
   */
   loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.operacion = 'Agregar';
      this.titulo = ' Festivo';
    });
  }

  /**
   * Form festivos
   */
   buildForm(): void {
    this.festiveForm = this.formBuilder.group({
      idDiaNoHabil: new FormControl(),
      dia: new FormControl(this.dia, Validators.required),
      descripcion: new FormControl(this.descripcion, [Validators.required, Validators.maxLength(50)]),
      activo: new FormControl(this.activo)
    });
  }

  /**
   * Metodo que crea festivo
   */
   createFestive() {
    this.festive = new InfoCatalogoFestivo();
    this.festive.idDiaNoHabil = this.festiveForm.controls['idDiaNoHabil'].value;
    this.festive.dia = this.datePipe.transform(this.festiveForm.get('dia').value,'dd/MM/yyyy');
    this.festive.descripcion = this.festiveForm.controls['descripcion'].value;

    this.festiveService.createFestive(this.festive).subscribe(
      (result) => {
        console.log('crea festivo', result);
        document.getElementById('openModalButtonEdit').click();
        this.router.navigate(['home/parametrization/catalogos/festive-catalog'], {
          replaceUrl: true,
        });
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Metodo que abre la ventana modal para crear festivo
   */
   openAddModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  /**
   * Metodo que cierra el modal y redirecciona al listado de festivo
   */
  closeModalEdit() {
    this.router.navigate(['home/parametrization/catalogos/festive-catalog'], {
      replaceUrl: true,
    });
  }

  /**
   * Redirecciona al listado de festivos
   */
   public back(): void {
    this.router.navigate(['home/parametrization/catalogos/festive-catalog'], {
      replaceUrl: true,
    });
  }

}
