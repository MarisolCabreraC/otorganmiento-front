import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FestiveCatalogComponent } from './festive-catalog.component';

describe('FestiveCatalogComponent', () => {
  let component: FestiveCatalogComponent;
  let fixture: ComponentFixture<FestiveCatalogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FestiveCatalogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FestiveCatalogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
