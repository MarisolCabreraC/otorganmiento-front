import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { FestiveService } from '../service/festive.service';
import { festiveInterface } from '@workflows/parametrization/catalogos/commons/festive-catalog/interface-Festive/interfaceFestive';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-edit-festive',
  templateUrl: './edit-festive.component.html',
  styleUrls: ['../../../../../../../../src/assets/css/style_catalogue.scss']
})

export class EditFestiveComponent implements OnInit {

  public festiveForm: FormGroup;
  public festiveInterface: festiveInterface;
  public editParamId: number;
  public diaFestive: string;

  @Output() formClose = new EventEmitter;

  public errorCode = false;
  public mensaje: string;

  constructor(
    private router: Router,
    private spinner: NgxSpinnerService,
    private FestiveService: FestiveService,
    private activatedRoute: ActivatedRoute,
    private datePipe: DatePipe) { }

  ngOnInit(): void {
    console.log("Marisol Cabrera 06012022 9:10AM");
    this.editParamId = parseInt(this.activatedRoute.snapshot.paramMap.get('id'));
    this.festiveForm = new FormGroup({
      dia: new FormControl('', Validators.required),
      descripcion: new FormControl('', Validators.required),
      idDiaNoHabil: new FormControl('', Validators.required),
    });

    this.searchEntityId();

  }

  //LLamado servicio de consultar por Id selecionado
  public searchEntityId() {
    this.spinner.show();
    this.FestiveService.searchCatalogFestiveByProfileId(this.editParamId).subscribe(
      data => {
        this.festiveInterface = data;
        this.festiveForm.controls['idDiaNoHabil'].setValue(this.editParamId);
        this.festiveForm.controls['dia'].setValue(this.festiveInterface.dia);
        this.festiveForm.controls['descripcion'].setValue(this.festiveInterface.descripcion);
        this.spinner.hide();
      },
      error => {
        this.spinner.hide();
      }
    );
  }

  public save() {
    this.mensaje = '';
    this.festiveInterface.idDiaNoHabil = this.editParamId;
    this.festiveInterface.dia = this.datePipe.transform(this.festiveForm.get('dia').value, 'dd/MM/yyyy');
    this.festiveInterface.descripcion = this.festiveForm.get('descripcion').value;

    this.spinner.show();
    this.FestiveService.editFestive_(this.festiveInterface).subscribe(
      data => {
        this.spinner.hide();
        document.getElementById('modalButtonEditClose').click();
        document.getElementById('openModalButtonEditClose').click();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      });
  }

  public back() {
    this.router.navigate(['home/parametrization/catalogos/festive-catalog/'],
      { replaceUrl: true });
    this.formClose.emit();
  }

  openEditModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  closeModalEdit() {
    this.router.navigate(['home/parametrization/catalogos/festive-catalog/'], { replaceUrl: true });
  }
}
