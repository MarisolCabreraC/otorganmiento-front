import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { InfoCatalogoFestivo } from '@commons/models/infoCatalogoFestivo';
import { API_CATALOGS } from '@src/utils/catalogs';
import { Observable } from 'rxjs';
import {festiveInterface} from '@workflows/parametrization/catalogos/commons/festive-catalog/interface-Festive/interfaceFestive';

@Injectable({
  providedIn: 'root'
})
export class FestiveService {

  constructor(public http: HttpClient) { }

  createFestive(festivo: InfoCatalogoFestivo): Observable<InfoCatalogoFestivo> {
    return this.http.post<InfoCatalogoFestivo>(API_CATALOGS.ADD_CATALOG_FESTIVE, festivo);
  }

  editFestive(festivo: InfoCatalogoFestivo): Observable<InfoCatalogoFestivo> {
    return this.http.post<InfoCatalogoFestivo>(API_CATALOGS.UPDATE_CATALOG_FESTIVE, festivo);
  }

  updateFestiveStatus(festivo: InfoCatalogoFestivo): Observable<InfoCatalogoFestivo> {
    return this.http.post<InfoCatalogoFestivo>(API_CATALOGS.STATUS_CATALOG_FESTIVE, festivo);
  }

  public findCatalogFestiveByProfile() {
    return this.http.post<InfoCatalogoFestivo[]>(API_CATALOGS.SEARCH_CATALOG_FESTIVE, {});
  }

  public searchCatalogFestiveByProfileId(id: number) {
    return this.http.post<festiveInterface>(API_CATALOGS.SEARCH_CATALOG_ID_FESTIVE, { idDiaNoHabil : id });
  }

  editFestive_(festiveInterface: festiveInterface): Observable<festiveInterface> {
    return this.http.post<festiveInterface>(API_CATALOGS.UPDATE2_CATALOG_FESTIVE, festiveInterface);
  }
}
