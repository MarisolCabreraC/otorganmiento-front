// Module
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { FestiveCatalogComponent } from '@workflows/parametrization/catalogos/commons/festive-catalog/festive-catalog.component';
import { FestiveCatalogRoutingModule } from '@workflows/parametrization/catalogos/commons/festive-catalog/festive-catalog-routing.module';

import { FestiveService } from '@workflows/parametrization/catalogos/commons/festive-catalog/service/festive.service';


@NgModule({
  declarations: [FestiveCatalogComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    NgbModule,
    FestiveCatalogRoutingModule
  ],
  exports: [FestiveCatalogComponent],
  providers: [FestiveService]
})
export class FestiveCatalogModule { }
