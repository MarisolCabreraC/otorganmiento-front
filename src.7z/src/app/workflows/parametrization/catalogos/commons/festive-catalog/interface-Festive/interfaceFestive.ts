export interface festiveInterface{
    idDiaNoHabil: number,
    dia: string,
    descripcion: string,
}
