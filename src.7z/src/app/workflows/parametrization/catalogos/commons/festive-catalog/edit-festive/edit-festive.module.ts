import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EditFestiveRoutingModule } from './edit-festive-routing.module';
import { EditFestiveComponent } from './edit-festive.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { FestiveService } from '../service/festive.service';
@NgModule({
  declarations: [EditFestiveComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    NgbModule,
    EditFestiveRoutingModule
  ],
  providers: [FestiveService],
  exports: [EditFestiveComponent]
})
export class EditFestiveModule { }
