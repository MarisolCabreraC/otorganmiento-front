// Modules
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// Route
import { SectorCatalogRoutingModule } from './sector-catalog-routing.module';

// Component
import { SectorCatalogComponent } from './sector-catalog.component';

@NgModule({
  declarations: [SectorCatalogComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SectorCatalogRoutingModule
  ]
})
export class SectorCatalogModule { }
