import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalsComponent } from '@workflows/modals/modals.component';
import { SectorEmpresaInterface } from '../interface/sector.interface';
import { SectorService } from '../service/sector.service';

@Component({
  selector: 'app-admin-sector',
  templateUrl: './admin-sector.component.html',
  styleUrls: ['../../../../../../../../src/assets/css/style_catalogue.scss'],
})
export class AdminSectorComponent implements OnInit {

  @ViewChild('examplemodal') modal: ModalsComponent;
  mensaje: string;
  idSectorEmpresa: string;
  activo: boolean;
  nombre: string;
  boton: string = '';
  operacion: string = '';
  titulo: string = '';
  sectorForm: FormGroup;
  sector: SectorEmpresaInterface;

  constructor(private sectorService: SectorService, private router: Router, private activatedRoute: ActivatedRoute, public formBuilder: FormBuilder) {
    this.activatedRoute.params.subscribe((params) => {
      if (params.editProfile) {
        this.operacion = 'Editar';
        this.titulo = ' Sector Empresa';
        this.boton = 'Actualizar';
        this.loadData();
      } else {
        this.operacion = 'Agregar';
        this.titulo = ' Sector Empresa';
        this.boton = 'Crear';
      }
    });
  }

  ngOnInit(): void {
    this.buildForm();
  }

  /**
   * Carga data sector empresa
   */
  loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.sector = JSON.parse(params['editProfile']) as SectorEmpresaInterface;
      this.nombre = this.sector.nombre;
      this.idSectorEmpresa = this.sector.idSectorEmpresa;
    });
  }

  /**
   * Form sector empresa
   */
  buildForm(): void {
    const user: string = localStorage.getItem('usuarioFront');
    const user2 = user.split('@');
    this.sectorForm = this.formBuilder.group({
      idSectorEmpresa: new FormControl(this.idSectorEmpresa, [Validators.required, Validators.maxLength(5)]),
      nombre: new FormControl(this.nombre, [Validators.required, Validators.maxLength(125)]),
      activo: new FormControl(this.activo),
      usuario: new FormControl(user2[0])
    });
  }

  /**
   * Metodo que crea sector empresa
   */
  createSector() {
    const data = {
      nombre: this.sectorForm.controls['nombre'].value,
      usuario: this.sectorForm.controls['usuario'].value,
      idSectorEmpresa: this.sectorForm.controls['idSectorEmpresa'].value
    }

    this.sectorService.createSector(data).subscribe(
      (result) => {
        document.getElementById('openModalButtonEdit').click();
        this.router.navigate(
          ['home/parametrization/catalogos/sector-catalog'],
          {
            replaceUrl: true,
          }
        );
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Metodo que actualiza sector empresa
   */
   updateSector() {
    this.mensaje = '';
    this.sector.nombre = this.sectorForm.controls['nombre'].value;
    this.sector.idSectorEmpresa = this.sectorForm.controls['idSectorEmpresa'].value;
    this.sectorService.updateSector(this.sector).subscribe(
      (result) => {
        document.getElementById('modalButtonEditClose').click();
        document.getElementById('openModalButtonEditClose').click();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Metodo que abre la ventana modal para crear sector empresa
   */
  openModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  /**
   * Metodo que cierra el modal y redirecciona al listado de sector empresa
   */
  closeModalEdit() {
    this.router.navigate(['home/parametrization/catalogos/sector-catalog'], {
      replaceUrl: true,
    });
  }

  /**
   * Redirecciona al listado de sector empresa
   */
  back(): void {
    this.router.navigate(['home/parametrization/catalogos/sector-catalog'], {
      replaceUrl: true,
    });
  }
}
