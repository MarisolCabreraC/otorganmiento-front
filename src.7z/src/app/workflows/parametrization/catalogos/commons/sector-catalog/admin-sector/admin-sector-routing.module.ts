// Modules
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Component
import { AdminSectorComponent } from './admin-sector.component';

const routes: Routes = [{
  path: '',
  component: AdminSectorComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminSectorRoutingModule { }
