// Modules
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Component
import { SectorCatalogComponent } from './sector-catalog.component';

const routes: Routes = [
  {
    path: '',
    component: SectorCatalogComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SectorCatalogRoutingModule { }
