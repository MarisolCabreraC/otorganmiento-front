// Module
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// Route
import { AdminSectorRoutingModule } from './admin-sector-routing.module';

// Component
import { AdminSectorComponent } from './admin-sector.component';

@NgModule({
  declarations: [AdminSectorComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    NgbModule,
    AdminSectorRoutingModule
  ]
})
export class AdminSectorModule { }
