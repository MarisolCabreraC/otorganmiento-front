import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { InfoCatalogoSector } from '@commons/models/infoCatalogoSector';
import { MainService } from '@commons/services/main.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { SectorService } from './service/sector.service';

@Component({
  selector: 'app-sector-catalog',
  templateUrl: './sector-catalog.component.html',
  styleUrls: ['../../../../../../../src/assets/css/style_catalogue.scss'],
})
export class SectorCatalogComponent implements OnInit {

  mensaje: any;
  editMenuOpt: boolean;
  sectors: InfoCatalogoSector[];

  constructor(private router: Router, private spinner: NgxSpinnerService,private sectorService: SectorService) {
    this.editMenuOpt = JSON.parse(localStorage.getItem('paramGeneral'));
  }

  ngOnInit(): void {
    this.initTableSector();
  }

  /**
   * Carga la tabla con los datos del catalogo sector empresa
   */
  initTableSector() {
    this.spinner.show();
    this.sectorService.listSector().subscribe(response => {
      this.sectors = response.registros;
    });
  }

  /**
   * Redirecciona al componente para crear sector empresa
   */
  addSector(): void {
    this.router.navigate([
      '/home/parametrization/catalogos/sector-catalog/admin-sector',
    ]);
  }

  /**
   * Metodo para actualizar el estado del catalogo sector empresa
   */
  statusSector(actividad: InfoCatalogoSector, status: boolean) {
    actividad.activo = status;
    this.sectorService.updateSectorStatus(actividad).subscribe(
      (result) => {
        this.initTableSector();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Redirecciona al componente para editar sector empresa
   */
   editSector(sector: InfoCatalogoSector): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/sector-catalog/admin-sector',
        { editProfile: JSON.stringify(sector) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  /**
   * Redirecciona a la tabla donde estan todos los catalogos
   */
  back(): void {
    this.router.navigate(['/home/parametrization/catalogos'], {
      replaceUrl: true,
    });
  }
}
