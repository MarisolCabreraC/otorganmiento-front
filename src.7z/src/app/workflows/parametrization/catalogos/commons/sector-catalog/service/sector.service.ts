import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { API_CATALOGS } from '@src/utils/catalogs';
import { SectorResponse } from '../../../../../../commons/models/catalogSectorResponse';
import { SectorEmpresaInterface } from '../interface/sector.interface';

@Injectable({
  providedIn: 'root'
})
export class SectorService {

  constructor(private http: HttpClient) { }

  /**
   * Funcion que permite consumir el servicio para guardar sector empresa.
   * @param sector a guardar.
   */
   createSector(sector: SectorEmpresaInterface): Observable<SectorEmpresaInterface> {
    return this.http.post<SectorEmpresaInterface>(API_CATALOGS.ADD_CATALOG_SECTOR, sector);
  }

  /**
   * Funcion que permite consumir el servicio para actualizar un sector empresa.
   * @param sector a actualizar.
   */
  updateSector(sector: SectorEmpresaInterface): Observable<SectorEmpresaInterface> {
    return this.http.post<SectorEmpresaInterface>(API_CATALOGS.UPDATE_CATALOG_SECTOR, sector);
  }

  /**
   * Funcion que permite consumir el servicio para actualizar el estado de sector empresa
   * @param sector estado a actualizar
   */
  updateSectorStatus(sector: SectorEmpresaInterface): Observable<SectorEmpresaInterface> {
    return this.http.post<SectorEmpresaInterface>(API_CATALOGS.STATUS_CATALOG_SECTOR, sector);
  }

  /**
   * Funcion que permite consumur el servicio para consultar sector empresa
   */
   listSector() {
    return this.http.post<SectorResponse>(API_CATALOGS.LIST_CATALOG_SECTOR, {
      pagina: 1
    });
  }
}
