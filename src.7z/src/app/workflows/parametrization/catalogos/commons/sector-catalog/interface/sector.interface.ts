/**
 * Entidad que mapea la informacion obtenida del microservicio del catalogo sector empresa.
 */
 export interface SectorEmpresaInterface {
    /**
   * Identificador del catalogo sector empresa.
   */
     idSectorEmpresa: string;
    /**
   * Nombre del catalogo sector empresa.
   */
    nombre: string;
    /**
   * Usuario que crea el catalogo sector empresa.
   */
    usuario?: string;
    /**
   * Estado del catalogo sector empresa (activo - inactivo)
   */
    activo?: boolean;
}