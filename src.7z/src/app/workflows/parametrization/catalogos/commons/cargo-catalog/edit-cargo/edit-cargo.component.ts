import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { InfoCatalogoCargo } from '@src/app/commons/models/infoCatalogoCargo';
import { MainService } from '@src/app/commons/services/main.service';
import { ModalsComponent } from '@workflows/modals/modals.component';

@Component({
  selector: 'app-edit-cargo',
  templateUrl: './edit-cargo.component.html',
  styleUrls: ['../../../../../../../../src/assets/css/style_catalogue.scss']
})
export class EditCargoComponent implements OnInit {

  @ViewChild('examplemodal') modal: ModalsComponent;
  public errorCode = false;
  public errorCodeText = 'el dato no ha sido procesado';
  public mensaje: string;
  public idCargo: number;
  public activo: boolean;
  public nombre: string;
  public status: boolean;
  public operacion: string = '';
  public titulo: string = '';
  public cargoForm: FormGroup;
  public cargo: InfoCatalogoCargo;

  constructor(private mainService: MainService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.loadData();
    this.buildForm();
  }

  /**
   * Metodo que carga los datos en el formulario
   */
   loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.cargo = JSON.parse(params['editProfile']) as InfoCatalogoCargo;
      this.nombre = this.cargo.nombre;
      this.idCargo = this.cargo.idCargo;

      if (this.nombre == null) {
        this.status = true;
      }
    });
  }

  /**
   * Form cargo
   */
  buildForm(): void {
    this.cargoForm = this.formBuilder.group({
      idCargo: new FormControl(this.idCargo, Validators.required),
      nombre: new FormControl(this.nombre, [Validators.required, Validators.maxLength(125)]),
      activo: new FormControl(this.activo)
    });
  }

  /**
   * Metodo que actualiza cargo
   */
   updateCargo() {
    this.mensaje = '';
    this.cargo.nombre = this.cargoForm.controls['nombre'].value;
    this.mainService.updateCargoStatus(this.cargo).subscribe(
      (result) => {
        document.getElementById('modalButtonEditClose').click();
        document.getElementById('openModalButtonEditClose').click();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Metodo que abre la ventana modal para editar cargo
   */
   openEditModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  /**
   * Metodo que cierra el modal y redirecciona al listado de cargos
   */
  closeModalEdit() {
    this.router.navigate(['home/parametrization/catalogos/cargo-catalog'], { replaceUrl: true });
  }

  /**
   * Redirecciona al listado de cargos
   */
  public back(): void {
    this.router.navigate(['home/parametrization/catalogos/cargo-catalog'], { replaceUrl: true });
  }

}
