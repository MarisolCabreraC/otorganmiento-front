import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminCargoComponent } from './admin-cargo.component';

describe('AdminCargoComponent', () => {
  let component: AdminCargoComponent;
  let fixture: ComponentFixture<AdminCargoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminCargoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminCargoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
