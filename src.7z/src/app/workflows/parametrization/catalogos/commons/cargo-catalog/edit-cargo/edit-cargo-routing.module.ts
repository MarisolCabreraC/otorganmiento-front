import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EditCargoComponent } from './edit-cargo.component';

const routes: Routes = [
  {
    path: '',
    component: EditCargoComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EditCargoRoutingModule { }
