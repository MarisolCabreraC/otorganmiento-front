import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CargoCatalogComponent } from './cargo-catalog.component';

describe('CargoCatalogComponent', () => {
  let component: CargoCatalogComponent;
  let fixture: ComponentFixture<CargoCatalogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CargoCatalogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CargoCatalogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
