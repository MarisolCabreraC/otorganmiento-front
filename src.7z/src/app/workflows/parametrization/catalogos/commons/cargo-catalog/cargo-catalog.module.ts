// Modules
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';

// Route
import { CargoCatalogRoutingModule } from './cargo-catalog-routing.module';

// Pipe
import { PipesModule } from '@src/app/commons/pipes/pipes.module';

// Component
import { CargoCatalogComponent } from './cargo-catalog.component';

@NgModule({
  declarations: [CargoCatalogComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    NgbModule,
    PipesModule,
    CargoCatalogRoutingModule
  ],
  exports:[CargoCatalogComponent]
})
export class CargoCatalogModule { }
