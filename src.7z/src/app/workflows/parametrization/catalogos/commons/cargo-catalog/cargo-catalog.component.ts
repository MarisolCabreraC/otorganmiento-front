import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InfoCatalogoCargo } from 'src/app/commons/models/infoCatalogoCargo';
import { MainService } from 'src/app/commons/services/main.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-cargo-catalog',
  templateUrl: './cargo-catalog.component.html',
  styleUrls: ['../../../../../../../src/assets/css/style_catalogue.scss']
})
export class CargoCatalogComponent implements OnInit {
  public listCargo: any;
  public editMenuOpt: boolean;
  public mensaje: any;
  filter = '';
  
  constructor(
    private router: Router,
    private spinner: NgxSpinnerService,
    private mainService: MainService
  ) {
    this.editMenuOpt = JSON.parse(localStorage.getItem('paramGeneral'));
  }

  ngOnInit(): void {
    this.initTableCargo();
  }

  initTableCargo() {
    this.spinner.show();
    this.mainService.findCatalogCargoByProfile().subscribe((result) => {
      this.listCargo = result.registros;
      this.spinner.hide();
    });
  }

  public addCargo(): void {
    this.router.navigate([
      '/home/parametrization/catalogos/cargo-catalog/admin-cargo',
    ]);
  }

  public refreshCargo(): void {
    this.router.navigate(['/home/parametrization/catalogos/cargo-catalog']);
  }

  public statusCargo(product: InfoCatalogoCargo, status: boolean) {
    product.activo = status;
    this.mainService.updateCargoStatus(product).subscribe(
      (result) => {
        this.refreshCargo();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Redirecciona al componente para editar cargo
   */
   public editCargo(cargo: InfoCatalogoCargo): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/cargo-catalog/edit-cargo',
        { editProfile: JSON.stringify(cargo) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  public back(): void {
    this.router.navigate(['/home/parametrization/catalogos'], {
      replaceUrl: true,
    });
  }
}
