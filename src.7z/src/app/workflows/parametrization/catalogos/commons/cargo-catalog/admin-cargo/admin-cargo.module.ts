import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AdminCargoRoutingModule } from './admin-cargo-routing.module';
import { AdminCargoComponent } from './admin-cargo.component';



@NgModule({
  declarations: [AdminCargoComponent],
  imports: [
    CommonModule,
    AdminCargoRoutingModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    NgbModule,
    SharedModule
  ],
  exports:[AdminCargoComponent]
})
export class AdminCargoModule { }
