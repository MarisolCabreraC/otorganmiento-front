import { Component, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { InfoCatalogoCargo } from '@commons/models/infoCatalogoCargo';
import { MainService } from '@commons/services/main.service';
import { ModalsComponent } from '@workflows/modals/modals.component';

@Component({
  selector: 'app-admin-cargo',
  templateUrl: './admin-cargo.component.html',
  styleUrls: ['../../../../../../../../src/assets/css/style_catalogue.scss']
})
export class AdminCargoComponent implements OnInit {
  @ViewChild('examplemodal') modal: ModalsComponent;
  public errorCode = false;
  public errorCodeText = 'el dato no ha sido procesado';
  public mensaje: string;
  public idCargo: number;
  public activo: boolean = true;
  public nombre: string;
  public operacion: string = '';
  public titulo: string = '';
  public cargoForm: FormGroup;
  public cargo: InfoCatalogoCargo;
  constructor(
    private mainService: MainService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    this.loadData();
    const user: string = localStorage.getItem('usuarioFront');
    const user2 = user.split('@');
    this.cargoForm = new FormGroup({
      idCargo: new FormControl(this.idCargo, [Validators.required, Validators.maxLength(38), Validators.pattern("^[0-9]*$")]),
      nombre: new FormControl(this.nombre, [Validators.required, Validators.maxLength(125)]),
      usuario: new FormControl(user2[0]),
      activo: new FormControl(this.activo),
    });
  }

  loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.operacion = 'Agregar';
      this.titulo = ' cargo';
    });
  }

  createCargo() {
    this.cargo = new InfoCatalogoCargo();
    this.cargo.nombre = this.cargoForm.controls['nombre'].value;
    this.cargo.usuario = this.cargoForm.controls['usuario'].value;
    this.cargo.idCargo = this.cargoForm.controls['idCargo'].value;

    this.mainService.createCargo(this.cargo).subscribe(
      (result) => {
        document.getElementById('openModalButtonEdit').click();
        this.router.navigate(['home/parametrization/catalogos/cargo-catalog'], {
          replaceUrl: true,
        });
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  openEditModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  closeModalEdit() {
    this.router.navigate(['home/parametrization/catalogos/cargo-catalog'], {
      replaceUrl: true,
    });
  }
  public back(): void {
    this.router.navigate(['home/parametrization/catalogos/cargo-catalog'], {
      replaceUrl: true,
    });
  }
}
