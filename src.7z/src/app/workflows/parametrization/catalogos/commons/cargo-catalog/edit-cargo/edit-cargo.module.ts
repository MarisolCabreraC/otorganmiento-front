// Modules 
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

// Route
import { EditCargoRoutingModule } from './edit-cargo-routing.module';

// Component
import { EditCargoComponent } from './edit-cargo.component';

@NgModule({
  declarations: [EditCargoComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    NgbModule,
    EditCargoRoutingModule
  ]
})
export class EditCargoModule { }
