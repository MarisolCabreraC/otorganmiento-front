import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StatementCatalogRoutingModule } from './statement-catalog-routing.module';
import { StatementCatalogComponent } from './statement-catalog.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';


@NgModule({
  declarations: [StatementCatalogComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    StatementCatalogRoutingModule
  ],
  exports:[StatementCatalogComponent]
})
export class StatementCatalogModule { }
