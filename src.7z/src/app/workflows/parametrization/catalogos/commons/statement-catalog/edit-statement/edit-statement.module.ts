import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EditStatementRoutingModule } from './edit-statement-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { EditStatementComponent } from './edit-statement.component';

@NgModule({
  declarations: [EditStatementComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    NgbModule,
    EditStatementRoutingModule,
  ],
  exports:[EditStatementComponent]
})
export class EditStatementModule { }
