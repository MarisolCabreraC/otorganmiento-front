import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminStatementRoutingModule } from './admin-statement-routing.module';
import { AdminStatementComponent } from './admin-statement.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';


@NgModule({
  declarations: [AdminStatementComponent],
  imports: [
    CommonModule,
    AdminStatementRoutingModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule
  ],
  exports:[AdminStatementComponent]
})
export class AdminStatementModule { }
