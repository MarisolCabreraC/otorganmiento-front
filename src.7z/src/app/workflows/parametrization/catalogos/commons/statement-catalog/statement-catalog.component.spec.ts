import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StatementCatalogComponent } from './statement-catalog.component';

describe('StatementCatalogComponent', () => {
  let component: StatementCatalogComponent;
  let fixture: ComponentFixture<StatementCatalogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StatementCatalogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StatementCatalogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
