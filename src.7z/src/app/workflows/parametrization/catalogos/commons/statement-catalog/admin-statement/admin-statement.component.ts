import { Component, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { InfoCatalogoEstamento } from '@commons/models/infoCatalogoEstamento';
import { MainService } from '@commons/services/main.service';
import { ModalsComponent } from '@workflows/modals/modals.component';

@Component({
  selector: 'app-admin-statement',
  templateUrl: './admin-statement.component.html',
  styleUrls: ['./admin-statement.component.scss'],
})
export class AdminStatementComponent implements OnInit {
  @ViewChild('examplemodal') modal: ModalsComponent;
  public errorCode = false;
  public errorCodeText = 'el dato no ha sido procesado';
  public mensaje: string;
  public idEstamento: number;
  public activo: boolean;
  public nombre: string;
  public operacion: string = '';
  public titulo: string = '';
  public statementForm: FormGroup;
  public estamento: InfoCatalogoEstamento;
  public abreviatura: string;
  public montoMinimo: number;
  public montoMaximo: number;
  public articulo: string;
  constructor(
    private mainService: MainService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    this.loadData();
    this.statementForm = new FormGroup({
      idEstamento: new FormControl(this.idEstamento, [
        Validators.required,
        Validators.maxLength(5),
      ]),
      nombre: new FormControl(this.nombre, [
        Validators.required,
        Validators.maxLength(50),
      ]),
      abreviatura: new FormControl(this.abreviatura, [
        Validators.required,
        Validators.maxLength(50),
      ]),
      montoMinimo: new FormControl(this.montoMinimo, [
        Validators.required,
        Validators.maxLength(50),
      ]),
      montoMaximo: new FormControl(this.montoMaximo, [
        Validators.required,
        Validators.maxLength(50),
      ]),
      articulo: new FormControl(this.articulo, [Validators.maxLength(50)]),
      activo: new FormControl(this.activo),
    });
  }

  loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.operacion = 'Agregar';
      this.titulo = ' estamento';
    });
  }

  createStatement() {
    this.estamento = new InfoCatalogoEstamento();
    this.estamento.nombre = this.statementForm.controls['nombre'].value;
    this.estamento.idEstamento = this.statementForm.controls[
      'idEstamento'
    ].value;
    this.estamento.abreviatura = this.statementForm.controls[
      'abreviatura'
    ].value;
    this.estamento.montoMinimo = this.statementForm.controls[
      'montoMinimo'
    ].value;
    this.estamento.montoMaximo = this.statementForm.controls[
      'montoMaximo'
    ].value;
    this.estamento.articulo = this.statementForm.controls['articulo'].value;

    this.mainService.createStatement(this.estamento).subscribe(
      (result) => {
        document.getElementById('openModalButtonEdit').click();
        this.router.navigate(
          ['home/parametrization/catalogos/statement-catalog'],
          {
            replaceUrl: true,
          }
        );
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  openEditModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  closeModalEdit() {
    this.router.navigate(['home/parametrization/catalogos/statement-catalog'], {
      replaceUrl: true,
    });
  }
  public back(): void {
    this.router.navigate(['home/parametrization/catalogos/statement-catalog'], {
      replaceUrl: true,
    });
  }
}
