import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminStatementComponent } from './admin-statement.component';


const routes: Routes = [
  {
    path: '',
    component: AdminStatementComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminStatementRoutingModule { }
