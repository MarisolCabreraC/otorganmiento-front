import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit-statement',
  templateUrl: './edit-statement.component.html',
  styleUrls: ['./edit-statement.component.scss']
})
export class EditStatementComponent implements OnInit {

  public statementForms: FormGroup;

  public errorCode = false;
  constructor(private router: Router,) { }

  ngOnInit(): void {

    this.statementForms = new FormGroup({
      idEstamento:  new FormControl('', [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      nombre:       new FormControl('', [Validators.required, Validators.maxLength(50)]),
      abreviatura:  new FormControl('', [Validators.required, Validators.maxLength(50)]),
      montoMinimo:  new FormControl('', [Validators.required, Validators.maxLength(50)]),
      montoMaximo:  new FormControl('', [Validators.required, Validators.maxLength(50)]),
      articulo:     new FormControl('', [Validators.required, Validators.maxLength(50)])
    })
   
  }

  public back() {
    this.router.navigate(['home/parametrization/catalogos/document-type-catalog/'],
    { replaceUrl: true });
  }

  openEditModal() {
    document.getElementById('openModalButtonEdit').click();
  }
  closeModalEdit() {
    this.router.navigate(['home/parametrization/statement-catalog/edit-statement/'],
    { replaceUrl: true });
  }

  public edit() {}
  
}
