import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { InfoCatalogoEstamento } from '@commons/models/infoCatalogoEstamento';
import { MainService } from '@commons/services/main.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-statement-catalog',
  templateUrl: './statement-catalog.component.html',
  styleUrls: ['./statement-catalog.component.scss'],
})
export class StatementCatalogComponent implements OnInit {
  public listStatement: any;
  public mensaje: any;
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private spinner: NgxSpinnerService,
    private mainService: MainService
  ) {}

  ngOnInit(): void {
    this.initTableStatement();
  }

  initTableStatement() {
    this.spinner.show();
    this.mainService.findCatalogStatementByProfile().subscribe((result) => {
      this.listStatement = result.registros;
      console.log(this.listStatement);
    });
  }

  public addStatement(): void {
    this.router.navigate([
      '/home/parametrization/catalogos/statement-catalog/admin-statement',
    ]);
  }

  public refreshStatement(): void {
    this.router.navigate(['/home/parametrization/catalogos/statement-catalog']);
  }

  public statusStatement(product: InfoCatalogoEstamento, status: boolean) {
    product.activo = status;
    this.mainService.updateStatementStatus(product).subscribe(
      (result) => {
        //window.location.reload();
        this.refreshStatement();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  public back(): void {
    this.router.navigate(['/home/parametrization/catalogos'], {
      replaceUrl: true,
    });
  }
}
