// Modules
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Component
import { EditCanalComponent } from './edit-canal.component';

const routes: Routes = [
  {
    path: '',
    component: EditCanalComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EditCanalRoutingModule { }
