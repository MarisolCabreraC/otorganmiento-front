// Modules
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// Route
import { AdminCanalRoutingModule } from './admin-canal-routing.module';

// Service
import { CanalService } from '../service/canal.service';

// Component
import { AdminCanalComponent } from './admin-canal.component';

@NgModule({
  declarations: [AdminCanalComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    NgbModule,
    AdminCanalRoutingModule
  ],
  providers: [CanalService]
})
export class AdminCanalModule { }
