// Modules
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Component
import { CanalCatalogComponent } from '@workflows/parametrization/catalogos/commons/canal-catalog/canal-catalog.component';

const routes: Routes = [
  {
    path: '',
    component: CanalCatalogComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CanalCatalogRoutin { }
