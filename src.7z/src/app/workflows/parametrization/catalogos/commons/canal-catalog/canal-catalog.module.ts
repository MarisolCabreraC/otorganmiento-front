// Modules
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

// Route
import { CanalCatalogRoutin } from '@workflows/parametrization/catalogos/commons/canal-catalog/canal-catalog.routing.module';

// Service
import { CanalService } from '@workflows/parametrization/catalogos/commons/canal-catalog/service/canal.service';

// Components
import { CanalCatalogComponent } from '@workflows/parametrization/catalogos/commons/canal-catalog/canal-catalog.component';

@NgModule({
  declarations: [
    CanalCatalogComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    NgbModule,
    CommonModule,
    CanalCatalogRoutin
  ],
  providers: [CanalService]
})
export class CanalCatalogModule { }
