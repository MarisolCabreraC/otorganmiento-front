import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { API_CATALOGS } from '@src/utils/catalogs';
import { InfoCanal } from '../model/canal.model';

@Injectable({
  providedIn: 'root'
})
export class CanalService {

  constructor(private http: HttpClient) { }

  /**
   * Funcion que permite consumir el servicio para guardar canal de venta.
   * @param canal a guardar.
   */
   createCanal(canal: InfoCanal): Observable<InfoCanal> {
    return this.http.post<InfoCanal>(API_CATALOGS.ADD_CATALOG_CANAL, canal);
  }

  /**
   * Funcion que permite consumir el servicio para actualizar un canal de venta.
   * @param canal a actualizar.
   */
  updateCanal(canal: InfoCanal): Observable<InfoCanal> {
    return this.http.post<InfoCanal>(API_CATALOGS.UPDATE_CATALOG_CANAL, canal);
  }

  /**
   * Funcion que permite consumir el servicio para actualizar el estado de un canal
   * @param canal estado a actualizar
   */
  updateCanalStatus(canal: InfoCanal): Observable<InfoCanal> {
    return this.http.post<InfoCanal>(API_CATALOGS.STATUS_CATALOG_CANAL, canal);
  }

  /**
   * Funcion que permite consumur el servicio para consultar canal de venta
   */
  findCatalogCanalByProfile(): Observable<InfoCanal[]> {
    return this.http.post<InfoCanal[]>(API_CATALOGS.SEARCH_CATALOG_CANAL, {});
  }
}
