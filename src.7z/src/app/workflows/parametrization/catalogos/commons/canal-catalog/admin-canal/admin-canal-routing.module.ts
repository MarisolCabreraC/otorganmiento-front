// Modules
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Component
import { AdminCanalComponent } from './admin-canal.component';

const routes: Routes = [
  {
    path: '',
    component: AdminCanalComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminCanalRoutingModule { }
