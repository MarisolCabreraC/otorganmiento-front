import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CanalService } from '@workflows/parametrization/catalogos/commons/canal-catalog/service/canal.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { InfoCanal } from './model/canal.model';

@Component({
  selector: 'app-canal-catalog',
  templateUrl: './canal-catalog.component.html',
  styleUrls: ['../../../../../../../src/assets/css/style_catalogue.scss']
})
export class CanalCatalogComponent implements OnInit {

  public mensaje: any;
  public editMenuOpt: boolean;
  canals: InfoCanal[];

  constructor(private router: Router, private canalService: CanalService, private spinner: NgxSpinnerService) {
    this.editMenuOpt = JSON.parse(localStorage.getItem('paramGeneral'));
    console.log('Escritura paramCanal : ',  this.editMenuOpt);
  }

  ngOnInit(): void {
    this.initTableCanal();
  }

  /**
   * Carga la tabla con los datos de canal de venta
   */
  initTableCanal() {
    this.spinner.show();
    this.canalService.findCatalogCanalByProfile().subscribe(response => {
      this.canals = response;
      this.spinner.hide();
    });
  }

  /**
   * Redirecciona al componente para crear canal de venta
   */
  public addCanal(): void {
    this.router.navigate([
      '/home/parametrization/catalogos/canal-catalog/admin-canal',
    ]);
  }

  /**
   * Metodo para actualizar el estado del canal de venta
   */
  public statusCanal(product: InfoCanal, status: boolean) {
    product.activo = status;
    this.canalService.updateCanalStatus(product).subscribe(
      (result) => {
        this.initTableCanal();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Redirecciona al componente para editar canal de venta
   */
  public editCanal(canal: InfoCanal): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/canal-catalog/edit-canal',
        { editProfile: JSON.stringify(canal) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  /**
   * Redirecciona a la tabla donde estan todos los catalogos
   */
  public back(): void {
    this.router.navigate(['/home/parametrization/catalogos'], {
      replaceUrl: true,
    });
  }
}
