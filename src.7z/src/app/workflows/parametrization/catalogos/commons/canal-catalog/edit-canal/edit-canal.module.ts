// Modules
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

// Route
import { EditCanalRoutingModule } from './edit-canal-routing.module';

// Service
import { CanalService } from '../service/canal.service';

// Component
import { EditCanalComponent } from './edit-canal.component';

@NgModule({
  declarations: [EditCanalComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    NgbModule,
    EditCanalRoutingModule
  ],
  providers: [CanalService]
})
export class EditCanalModule { }
