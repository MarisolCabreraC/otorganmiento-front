import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CanalCatalogComponent } from './canal-catalog.component';

describe('CanalCatalogComponent', () => {
  let component: CanalCatalogComponent;
  let fixture: ComponentFixture<CanalCatalogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CanalCatalogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CanalCatalogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
