import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ModalsComponent } from '@workflows/modals/modals.component';
import { CanalService } from '@workflows/parametrization/catalogos/commons/canal-catalog/service/canal.service';
import { InfoCanal } from '../model/canal.model';

@Component({
  selector: 'app-edit-canal',
  templateUrl: './edit-canal.component.html',
  styleUrls: ['../../../../../../../../src/assets/css/style_catalogue.scss']
})
export class EditCanalComponent implements OnInit {

  @ViewChild('examplemodal') modal: ModalsComponent;
  public errorCode = false;
  public errorCodeText = 'el dato no ha sido procesado';
  public mensaje: string;
  public canal: InfoCanal;
  public idCanalVenta: number;
  public nombre: string;
  public valor: number;
  public descripcion: string;
  public status: boolean;
  public form: FormGroup;
  public activo: boolean;
  public operacion: string = 'Editar';

  constructor(private router: Router,
    public formBuilder: FormBuilder,
    private canalService: CanalService,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.loadData();
    this.buildForm();
  }

  /**
   * Metodo que carga los datos en el formulario
   */
  loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.canal = JSON.parse(params['editProfile']) as InfoCanal;
      this.nombre = this.canal.nombre;
      this.idCanalVenta = this.canal.idCanalVenta;

      if (this.nombre == null) {
        this.status = true;
      }
    });
  }

  /**
   * Form canal de ventas
   */
  buildForm(): void {
    this.form = this.formBuilder.group({
      idCanalVenta: new FormControl(this.idCanalVenta, Validators.required),
      nombre: new FormControl(this.nombre, [Validators.required, Validators.maxLength(125)]),
      activo: new FormControl(this.activo)
    });
  }

  /**
   * Metodo que actualiza canal de venta
   */
  updateCanal() {
    this.mensaje = '';
    this.canal.nombre = this.form.controls['nombre'].value;
    this.canalService.updateCanal(this.canal).subscribe(
      (result) => {
        document.getElementById('modalButtonEditClose').click();
        document.getElementById('openModalButtonEditClose').click();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Metodo que abre la ventana modal para editar canal de venta
   */
  openEditModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  /**
   * Metodo que cierra el modal y redirecciona al listado de canal de ventas
   */
  closeModalEdit() {
    this.router.navigate(['home/parametrization/catalogos/canal-catalog'], { replaceUrl: true });
  }

  /**
   * Redirecciona al listado de canal de ventas
   */
  public back(): void {
    this.router.navigate(['home/parametrization/catalogos/canal-catalog'], { replaceUrl: true });
  }

}
