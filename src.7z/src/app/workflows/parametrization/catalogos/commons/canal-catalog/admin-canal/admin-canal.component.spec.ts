import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminCanalComponent } from './admin-canal.component';

describe('AdminCanalComponent', () => {
  let component: AdminCanalComponent;
  let fixture: ComponentFixture<AdminCanalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminCanalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminCanalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
