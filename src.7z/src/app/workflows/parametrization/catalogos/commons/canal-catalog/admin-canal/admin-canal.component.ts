import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ModalsComponent } from '@workflows/modals/modals.component';
import { CanalService } from '@workflows/parametrization/catalogos/commons/canal-catalog/service/canal.service';
import { InfoCanal } from '../model/canal.model';

@Component({
  selector: 'app-admin-canal',
  templateUrl: './admin-canal.component.html',
  styleUrls: ['../../../../../../../../src/assets/css/style_catalogue.scss']
})
export class AdminCanalComponent implements OnInit {

  @ViewChild('examplemodal') modal: ModalsComponent;
  public errorCode = false;
  public errorCodeText = 'el dato no ha sido procesado';
  public mensaje: string;
  public idCanalVenta: number;
  public activo: boolean = true;
  public nombre: string;
  public operacion: string = '';
  public titulo: string = '';
  public canalForm: FormGroup;
  public canal: InfoCanal;

  constructor(
    private canalService: CanalService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    this.loadData();
    this.buildForm();
  }
  
  /**
   * Asigna data
   */
  loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.operacion = 'Agregar';
      this.titulo = ' canal de venta';
    });
  }

  /**
   * Form canal de ventas
   */
   buildForm(): void {
    const user: string = localStorage.getItem('usuarioFront');
    const user2 = user.split('@');
    this.canalForm = this.formBuilder.group({
      idCanalVenta: new FormControl(this.idCanalVenta, [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      nombre: new FormControl(this.nombre, [Validators.required, Validators.maxLength(125)]),
      activo: new FormControl(this.activo),
      usuario: new FormControl(user2[0])
    });
  }

  /**
   * Metodo que crea canal de venta
   */
  createCanal() {
    const data = {
      nombre: this.canalForm.controls['nombre'].value,
      usuario: this.canalForm.controls['usuario'].value,
      idCanalVenta: this.canalForm.controls['idCanalVenta'].value
    }

    this.canalService.createCanal(data).subscribe(
      (result) => {
        document.getElementById('openModalButtonEdit').click();
        this.router.navigate(['home/parametrization/catalogos/canal-catalog'], {
          replaceUrl: true,
        });
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Metodo que abre la ventana modal para crear canal de venta
   */
   openAddModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  /**
   * Metodo que cierra el modal y redirecciona al listado de canal de ventas
   */
  closeModalEdit() {
    this.router.navigate(['home/parametrization/catalogos/canal-catalog'], {
      replaceUrl: true,
    });
  }

  /**
   * Redirecciona al listado de canal de ventas
   */
  public back(): void {
    this.router.navigate(['home/parametrization/catalogos/canal-catalog'], {
      replaceUrl: true,
    });
  }
}
