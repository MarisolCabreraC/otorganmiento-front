/**
 * Entidad que mapea la informacion obtenida del microservicio del canal de venta.
 */
export interface InfoCanal {
    /**
   * Identificador del canal de venta.
   */
    idCanalVenta: number;
    /**
   * Nombre del canal de venta.
   */
    nombre: string;
    /**
   * Usuario que registra canal de venta
   */
    usuario?: string;
    /**
   * Estado del canal de venta (activo - inactivo)
   */
    activo?: boolean;
}