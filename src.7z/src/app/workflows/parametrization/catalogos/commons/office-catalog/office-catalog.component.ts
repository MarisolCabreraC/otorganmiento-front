import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { InfoCatalogoOficina } from '@commons/models/infoCatalogoOficina';
import { MainService } from '@commons/services/main.service';
import { OfficeService } from '@commons/services/office.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-office-catalog',
  templateUrl: './office-catalog.component.html',
  styleUrls: ['./office-catalog.component.scss'],
})
export class OfficeCatalogComponent implements OnInit {
  public listOffices: any;
  public listCities: any;
  public listDepartments: any;
  public listZones: any;
  public mensaje: any;
  public cityName: string;
  public departmentName: string;
  filter = '';
  public editMenuOpt: boolean;
  

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private mainService: MainService,
    private spinner: NgxSpinnerService,
    private officeService: OfficeService
  ) {
    this.editMenuOpt = JSON.parse(localStorage.getItem('paramGeneral'));
  }

  ngOnInit(): void {
    this.initTableOffices();
  }

  initTableOffices() {
    this.spinner.show();
    this.mainService.findCatalogOfficeByProfile().subscribe((result) => {
      this.listOffices = result.registros;
      console.log('%c OFFICES', 'background: RED', this.listOffices);
    });
  }

  /* initZones() {
    this.mainService.findCatalogOfficeZoneByProfile().subscribe((result) => {
      this.listZones = result.registros;
      let zoneRequest = this.listZones.map((zone) => zone);
      this.officeService.setDataOfficeZone({
        zoneRequest,
      });
      console.log('%c ZONES', 'background: yellow', zoneRequest);
    });
  }

  initCities() {
    this.mainService.findCatalogOfficeCitiesByProfile().subscribe((result) => {
      this.listCities = result.registros;
      let cityRequest = this.listCities.map((city) => city);
      this.officeService.setDataOfficeCity({
        cityRequest,
      });
      console.log('%c CITIES', 'background: green', cityRequest);
    });
  }

  initDepartments() {
    this.mainService
      .findCatalogOfficeDepartmentByProfile()
      .subscribe((result) => {
        this.listDepartments = result.registros;
        let departmentRequest = this.listDepartments.map((dep) => dep);
        this.officeService.setDataOfficeDepartment({
          departmentRequest,
        });
        console.log(
          '%c SETTED DEPARTMENTS',
          'background: purple',
          departmentRequest
        );
      });
  } */

    /**
   * Redirecciona al componente para editar oficina
   */
  public editOffice(product: InfoCatalogoOficina): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/office-catalog/edit-office',
        { editOffice: JSON.stringify(product) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }
  public addOffices(): void {
    this.router.navigate([
      '/home/parametrization/catalogos/office-catalog/admin-office',
    ]);
  }

  public refreshOffice(): void {
    this.router.navigate(['/home/parametrization/catalogos/office-catalog']);
  }

  public statusoffice(product: InfoCatalogoOficina, status: boolean) {
    product.activo = status;
    this.mainService.updateOficceStatus(product).subscribe(
      (result) => {
        //window.location.reload();
        this.refreshOffice();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  public back(): void {
    this.router.navigate(['/home/parametrization/catalogos'], {
      replaceUrl: true,
    });
  }
}
