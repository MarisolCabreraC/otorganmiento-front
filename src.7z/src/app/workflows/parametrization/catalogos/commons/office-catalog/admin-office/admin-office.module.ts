import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminOfficeRoutingModule } from './admin-office-routing.module';
import { AdminOfficeComponent } from './admin-office.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


@NgModule({
  declarations: [AdminOfficeComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    NgbModule,
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    AdminOfficeRoutingModule,
  ],
  exports:[AdminOfficeComponent]
})
export class AdminOfficeModule { }
