import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EditOfficeRoutingModule } from './edit-office-routing.module';
import { EditOfficeComponent } from './edit-office.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


@NgModule({
  declarations: [EditOfficeComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    NgbModule,
    CommonModule,
    EditOfficeRoutingModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule
  ],
  exports:[EditOfficeComponent]
})
export class EditOfficeModule { }
