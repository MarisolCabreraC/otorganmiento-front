import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OfficeCatalogRoutingModule } from './office-catalog-routing.module';
import { OfficeCatalogComponent } from './office-catalog.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { PipesModule } from '@src/app/commons/pipes/pipes.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


@NgModule({
  declarations: [OfficeCatalogComponent],
  imports: [
    
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    PipesModule,
    NgbModule,
    OfficeCatalogRoutingModule
  ],
  exports:[OfficeCatalogComponent]
})
export class OfficeCatalogModule { }
