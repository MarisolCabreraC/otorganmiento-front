import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { OfficeCatalogComponent } from './office-catalog.component';


const routes: Routes = [
  {
    path: '',
    component: OfficeCatalogComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OfficeCatalogRoutingModule { }
