import { Component, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { InfoCatalogoOficina } from '@commons/models/infoCatalogoOficina';
import { InfoCatalogoOficinaDepartamento } from '@commons/models/infoCatalogoOficinaDepartamento';
import { MainService } from '@commons/services/main.service';
import { AlertService } from '@src/app/commons/components/alerts/alerts.service';
import { ModalsComponent } from '@workflows/modals/modals.component';

@Component({
  selector: 'app-admin-office',
  templateUrl: './admin-office.component.html',
  styleUrls: ['./admin-office.component.scss'],
})
export class AdminOfficeComponent implements OnInit {
  @ViewChild('examplemodal') modal: ModalsComponent;
  public errorCode = false;
  public errorCodeText = 'el dato no ha sido procesado';
  public mensaje: string;
  public idOficina: number;
  public activo: boolean;
  public nombreOficina: string;
  public operacion: string = '';
  public titulo: string = '';
  public officeForm: FormGroup;
  public Oficina: InfoCatalogoOficina;
  public codigoCrm: string;
  public codigoZona: number;
  public codigoDepart: number;
  public codigoCiudad: string;
  public zona: string;
  public departamento: string;
  public ciudad: string;
  public idDepartamentoStd: any;
  public idCiudadStd: any;
  public idZonaStd: any;
  public listCities: any;
  public listDepartments: any;
  public listZones: any;
  public nombreZona: any;
  public nombreDepartamento: any;
  public nombreCiudad: any;

  constructor(
    private mainService: MainService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public formBuilder: FormBuilder,
    public alertSerive: AlertService
  ) {}

  onChange(idDepartamento) {
    this.idDepartamentoStd = idDepartamento;
    console.log('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>', this.idDepartamentoStd);
    this.loadCityData();
  }

  onChangeCity(idCiudad) {
    console.log(idCiudad);
    this.idCiudadStd = idCiudad;
  }

  onChangeZona(idZone) {
    this.idZonaStd = idZone;
  }

  ngOnInit(): void {
    this.loadData();
    this.initDepartments();
    this.initZones();
    this.officeForm = new FormGroup({
      idOficina: new FormControl(this.idOficina, [
        Validators.required,
        Validators.maxLength(7),
      ]),
      nombreOficina: new FormControl(this.nombreOficina, [
        Validators.required,
        Validators.maxLength(50),
      ]),
      codigoCrm: new FormControl(this.codigoCrm, [
        Validators.required,
        Validators.maxLength(3),
      ]),
      /* codigoZona: new FormControl(this.codigoZona, [
        Validators.required,
        Validators.maxLength(7),
      ]),
      codigoDepart: new FormControl(this.codigoDepart, [
        Validators.required,
        Validators.maxLength(2),
      ]),
      codigoCiudad: new FormControl(this.codigoCiudad, [
        Validators.required,
        Validators.maxLength(5),
      ]), */
      zona: new FormControl(this.nombreZona, [
        Validators.required,
        Validators.maxLength(50),
      ]),
      departamento: new FormControl(this.nombreDepartamento, [
        Validators.required,
        Validators.maxLength(50),
      ]),
      ciudad: new FormControl(this.nombreCiudad, [
        Validators.required,
        Validators.maxLength(50),
      ]),
      activo: new FormControl(this.activo),
    });
  }

  loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.operacion = 'Agregar';
      this.titulo = ' Oficina';
    });
  }

  initZones() {
    this.mainService.findCatalogOfficeZoneByProfile().subscribe((result) => {
      this.listZones = result.registros;
    });
  }

  /*   initCities() {
    this.mainService.findCatalogOfficeCitiesByProfile().subscribe((result) => {
      this.listCities = result.registros;
    });
  }
 */
  initDepartments() {
    this.mainService
      .findCatalogOfficeDepartmentByProfile()
      .subscribe((result) => {
        this.listDepartments = result.registros;
      });
  }

  async createOffice() {
    let validar = await this.alertSerive.alertConfirm('Guardar')
    if( validar){
        this.Oficina = new InfoCatalogoOficina();
        this.Oficina.nombreOficina = this.officeForm.controls[
          'nombreOficina'
        ].value;
        this.Oficina.idOficina = this.officeForm.controls['idOficina'].value;
        this.Oficina.idCrm = this.officeForm.controls['codigoCrm'].value;
        this.Oficina.idZona = this.officeForm.controls['zona'].value;
        this.Oficina.idDepartamento = this.officeForm.controls[
          'departamento'
        ].value;
        this.Oficina.idCiudad = this.officeForm.controls['ciudad'].value;
        /* this.Oficina.nombreZona = this.officeForm.controls['zona'].value;
        this.Oficina.nombreDepartamento = this.officeForm.controls[
          'departamento'
        ].value;
        this.Oficina.nombreCiudad = this.officeForm.controls['ciudad'].value; */
    
        this.mainService.createOffice(this.Oficina).subscribe(
          (result) => {
            let result2:any = result;
            if(result2.code){
              this.alertSerive.alertError(result2.description);
            }else{
              let ruta = 'home/parametrization/catalogos/office-catalog'
              this.alertSerive.alertSuccesMessage('Guardar',ruta)
            }
           
            // document.getElementById('openModalButtonEdit').click();
            // this.router.navigate(
            //   ['home/parametrization/catalogos/office-catalog'],
            //   {
            //     replaceUrl: true,
            //   }
            // );
          },
          (error) => {
            this.alertSerive.alertError(error.error.description)
            // this.mensaje = 'Error: ' + error.error.description;
          }
        );

    }
  }
 

  loadCityData() {
    this.activatedRoute.params.subscribe((params) => {
      let consultarCiudad = new InfoCatalogoOficinaDepartamento();
      consultarCiudad.idDepartamento = this.idDepartamentoStd;
      console.log(
        '%c testing id depart',
        'background: pink; color: purple',
        consultarCiudad
      );

      this.mainService
        .findCatalogOfficeCityByProfile(consultarCiudad)
        .subscribe((result) => {
          this.listCities = result.registros;
          console.log(
            '%c testing id depart',
            'background: pink; color: purple',
            this.listCities
          );
        });
    });
  }

  openEditModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  closeModalEdit() {
    this.router.navigate(['home/parametrization/catalogos/office-catalog'], {
      replaceUrl: true,
    });
  }
  public back(): void {
    this.router.navigate(['home/parametrization/catalogos/office-catalog'], {
      replaceUrl: true,
    });
  }
}
