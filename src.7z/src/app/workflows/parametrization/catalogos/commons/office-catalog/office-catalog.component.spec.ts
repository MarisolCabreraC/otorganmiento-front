import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OfficeCatalogComponent } from './office-catalog.component';

describe('OfficeCatalogComponent', () => {
  let component: OfficeCatalogComponent;
  let fixture: ComponentFixture<OfficeCatalogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OfficeCatalogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OfficeCatalogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
