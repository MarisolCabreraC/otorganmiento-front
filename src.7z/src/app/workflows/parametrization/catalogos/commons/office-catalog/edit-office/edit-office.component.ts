import { Component, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { InfoCatalogoOficina } from '@commons/models/infoCatalogoOficina';
import { InfoCatalogoOficinaDepartamento } from '@commons/models/infoCatalogoOficinaDepartamento';
import { MainService } from '@commons/services/main.service';
import { ModalsComponent } from '@workflows/modals/modals.component';

@Component({
  selector: 'app-edit-office',
  templateUrl: './edit-office.component.html',
  styleUrls: ['./edit-office.component.scss'],
})
export class EditOfficeComponent implements OnInit {
  @ViewChild('examplemodal') modal: ModalsComponent;
  public errorCode = false;
  public errorCodeText = 'el dato no ha sido procesado';
  public mensaje: string;
  public idOficina: number;
  public activo: boolean;
  public nombreOficina: string;
  public operacion: string = '';
  public titulo: string = '';
  public officeForm: FormGroup;
  public Oficina: InfoCatalogoOficina;
  public codigoCrm: string;
  public codigoZona: number;
  public codigoDepart: number;
  public codigoCiudad: string;
  public zona: string;
  public departamento: string;
  public ciudad: string;
  public idDepartamentoStd: any;
  public idCiudadStd: any;
  public idZonaStd: any;
  public listCities: any;
  public listDepartments: any;
  public listZones: any;
  public nombreZona: any;
  public nombreDepartamento: any;
  public nombreCiudad: any;

  constructor(
    private mainService: MainService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public formBuilder: FormBuilder
  ) {}

  onChange(idDepartamento) {
    this.idDepartamentoStd = idDepartamento;
    console.log('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>', this.idDepartamentoStd);
    this.loadCityData();
  }

  onChangeCity(idCiudad) {
    console.log(idCiudad);
    this.idCiudadStd = idCiudad;
  }

  onChangeZona(idZone) {
    this.idZonaStd = idZone;
  }

  ngOnInit(): void {
    this.loadData();
    this.initDepartments();
    this.initZones();
    this.officeForm = new FormGroup({
      idOficina: new FormControl(this.Oficina.idOficina, [
        Validators.required,
        Validators.maxLength(7),
      ]),
      nombreOficina: new FormControl(this.Oficina.nombreOficina, [
        Validators.required,
        Validators.maxLength(50),
      ]),
      codigoCrm: new FormControl(this.Oficina.idCrm, [
        Validators.required,
        Validators.maxLength(3),
      ]),
      /* codigoZona: new FormControl(this.codigoZona, [
        Validators.required,
        Validators.maxLength(7),
      ]),
      codigoDepart: new FormControl(this.codigoDepart, [
        Validators.required,
        Validators.maxLength(2),
      ]),
      codigoCiudad: new FormControl(this.codigoCiudad, [
        Validators.required,
        Validators.maxLength(5),
      ]), */
      zona: new FormControl(this.Oficina.idZona, [
        Validators.required,
        Validators.maxLength(50),
      ]),
      departamento: new FormControl(this.Oficina.idDepartamento, [
        Validators.required,
        Validators.maxLength(50),
      ]),
      ciudad: new FormControl(this.Oficina.idCiudad, [
        Validators.required,
        Validators.maxLength(50),
      ]),
      activo: new FormControl(this.Oficina.activo),
    });
  }

  loadData() {
    this.Oficina = new InfoCatalogoOficina();
    this.activatedRoute.params.subscribe((params) => {
      this.operacion = 'Editar';
      this.titulo = ' Oficina';
      this.Oficina = JSON.parse(params['editOffice']) as InfoCatalogoOficina;
      this.onChange(this.Oficina.idDepartamento);
    });
  }

  initZones() {
    this.mainService.findCatalogOfficeZoneByProfile().subscribe((result) => {
      this.listZones = result.registros;
    });
  }

  /*   initCities() {
    this.mainService.findCatalogOfficeCitiesByProfile().subscribe((result) => {
      this.listCities = result.registros;
    });
  }
 */
  initDepartments() {
    this.mainService
      .findCatalogOfficeDepartmentByProfile()
      .subscribe((result) => {
        this.listDepartments = result.registros;
      });
  }


  updateOffice(){
    this.Oficina.nombreOficina = this.officeForm.controls[
      'nombreOficina'
    ].value;
    this.Oficina.idOficina = this.officeForm.controls['idOficina'].value;
    this.Oficina.idCrm = this.officeForm.controls['codigoCrm'].value;
    this.Oficina.idZona = this.officeForm.controls['zona'].value;
    this.Oficina.idDepartamento = this.officeForm.controls[
      'departamento'
    ].value;
    this.Oficina.idCiudad = this.officeForm.controls['ciudad'].value;

    this.mainService.updateOffice(this.Oficina).subscribe(
      (result) => {
        document.getElementById('openModalButtonEdit').click();
        this.router.navigate(
          ['home/parametrization/catalogos/office-catalog'],
          {
            replaceUrl: true,
          }
        );
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  

  loadCityData() {
    this.activatedRoute.params.subscribe((params) => {
      let consultarCiudad = new InfoCatalogoOficinaDepartamento();
      consultarCiudad.idDepartamento = this.idDepartamentoStd;
      console.log(
        '%c testing id depart',
        'background: pink; color: purple',
        consultarCiudad
      );

      this.mainService
        .findCatalogOfficeCityByProfile(consultarCiudad)
        .subscribe((result) => {
          this.listCities = result.registros;
          console.log(
            '%c testing id depart',
            'background: pink; color: purple',
            this.listCities
          );
        });
    });
  }

  openEditModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  closeModalEdit() {
    this.router.navigate(['home/parametrization/catalogos/office-catalog'], {
      replaceUrl: true,
    });
  }
  public back(): void {
    this.router.navigate(['home/parametrization/catalogos/office-catalog'], {
      replaceUrl: true,
    });
  }
}
