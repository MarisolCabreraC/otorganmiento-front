// Modules
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Component
import { AdminProductBuyComponent } from './admin-product-buy.component';

const routes: Routes = [
  {
    path: '',
    component: AdminProductBuyComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminProductBuyRoutingModule { }
