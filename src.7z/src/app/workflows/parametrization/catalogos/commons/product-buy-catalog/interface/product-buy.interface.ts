/**
 * Entidad que mapea la informacion obtenida del microservicio de codigo producto comprar.
 */
 export interface ProductBuyInterface {
    /**
   * Abreviatura de codigo producto comprar.
   */
    idAbreviatura   : string;
    /**
   * codigo de codigo producto comprar.
   */
    codigo          : string;
    /**
   * Nombre de codigo producto comprar.
   */
    producto        : string;
    /**
   * Usuario que crea codigo producto comprar.
   */
    usuario?        : string;
    /**
   * Estado de codigo producto comprar (activo - inactivo)
   */
    activo?         : boolean;
}
   