// Modules
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

// Route
import { AdminProductBuyRoutingModule } from './admin-product-buy-routing.module';

// Component
import { AdminProductBuyComponent } from './admin-product-buy.component';

@NgModule({
  declarations: [AdminProductBuyComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    NgbModule,
    AdminProductBuyRoutingModule
  ]
})
export class AdminProductBuyModule { }
