import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AlertService } from '@src/app/commons/components/alerts/alerts.service';
import { ProductBuyInterface } from '../interface/product-buy.interface';
import { ProductBuyService } from '../service/product-buy.service';

@Component({
  selector: 'app-admin-product-buy',
  templateUrl: './admin-product-buy.component.html',
  styleUrls: ['../../../../../../../../src/assets/css/style_catalogue.scss']
})
export class AdminProductBuyComponent implements OnInit {

  idAbreviatura: string;
  activo: boolean;
  codigo: string;
  producto: string;
  boton: string = '';
  operacion: string = '';
  titulo: string = '';
  productbuyForm: FormGroup;
  productBuy: ProductBuyInterface;

  constructor(private productbuyService: ProductBuyService, private router: Router, private activatedRoute: ActivatedRoute, public formBuilder: FormBuilder,
    private alertSerive: AlertService) {
    this.activatedRoute.params.subscribe((params) => {
      if (params.editProfile) {
        this.operacion = 'Editar';
        this.titulo = ' Código producto a comprar';
        this.boton = 'Actualizar';
        this.loadData();
      } else {
        this.operacion = 'Agregar';
        this.titulo = ' Código producto a comprar';
        this.boton = 'Crear';
      }
    });
  }

  ngOnInit(): void {
    this.buildForm();
  }

  /**
   * Carga data codigo producto a comprar
   */
   loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.productBuy = JSON.parse(params['editProfile']) as ProductBuyInterface;
      this.producto = this.productBuy.producto;
      this.codigo = this.productBuy.codigo;
      this.idAbreviatura = this.productBuy.idAbreviatura;
    });
  }

  /**
   * Form codigo producto a comprar
   */
  buildForm(): void {
    const user: string = localStorage.getItem('usuarioFront');
    const user2 = user.split('@');
    this.productbuyForm = this.formBuilder.group({
      idAbreviatura: new FormControl(this.idAbreviatura, [Validators.required, Validators.maxLength(2)]),
      codigo: new FormControl(this.codigo, [Validators.required, Validators.maxLength(2), Validators.pattern("^[0-9]*$")]),
      producto: new FormControl(this.producto, [Validators.required, Validators.maxLength(25)]),
      activo: new FormControl(this.activo),
      usuario: new FormControl(user2[0])
    });
  }

  /**
   * Metodo que crea codigo producto a comprar
   */
  async createProductBuy() {
    let validar = await this.alertSerive.alertConfirm('Guardar')

    if (validar) {
      const data = {
        producto: this.productbuyForm.controls['producto'].value,
        codigo: this.productbuyForm.controls['codigo'].value,
        idAbreviatura: this.productbuyForm.controls['idAbreviatura'].value
      }
  
      this.productbuyService.createProductBuy(data).subscribe(response => {
          let result:any = response;
          if(result.code){
            this.alertSerive.alertError(result.description);
          }else{
            let ruta = 'home/parametrization/catalogos/product-buy-catalog'
            this.alertSerive.alertSuccesMessage('Guardar',ruta)
          }
        }, (error) => {
          this.alertSerive.alertError(error.error.description)
        }
      );
    }
  }

  /**
   * Metodo que actualiza codigo producto a comprar
   */
  async updateProductBuy() {
    let validar = await this.alertSerive.alertConfirm('Actualizar')

    if (validar) {
      this.productBuy.producto = this.productbuyForm.controls['producto'].value;
      this.productBuy.codigo = this.productbuyForm.controls['codigo'].value;
      this.productBuy.idAbreviatura = this.productbuyForm.controls['idAbreviatura'].value;

      this.productbuyService.updateProductBuy(this.productBuy).subscribe(response => {
          let result:any = response;
          if(result.code){
            this.alertSerive.alertError(result.description);
          }else{
            let ruta = 'home/parametrization/catalogos/product-buy-catalog'
            this.alertSerive.alertSuccesMessage('Actualizar',ruta)
          }
        }, (error) => {
          this.alertSerive.alertError(error.error.description)
        }
      );
    }
  }

  /**
   * Redirecciona al listado de codigo producto a comprar
   */
  back(): void {
    this.router.navigate(['home/parametrization/catalogos/product-buy-catalog'], {
      replaceUrl: true,
    });
  }

}
