import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminProductBuyComponent } from './admin-product-buy.component';

describe('AdminProductBuyComponent', () => {
  let component: AdminProductBuyComponent;
  let fixture: ComponentFixture<AdminProductBuyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminProductBuyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminProductBuyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
