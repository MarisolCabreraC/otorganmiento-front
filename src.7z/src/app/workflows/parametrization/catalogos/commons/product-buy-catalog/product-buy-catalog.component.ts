import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ProductBuyInterface } from './interface/product-buy.interface';
import { ProductBuyService } from './service/product-buy.service';

@Component({
  selector: 'app-product-buy-catalog',
  templateUrl: './product-buy-catalog.component.html',
  styleUrls: ['../../../../../../../src/assets/css/style_catalogue.scss']
})
export class ProductBuyCatalogComponent implements OnInit {

  public mensaje: any;
  public editMenuOpt: boolean;
  products: ProductBuyInterface[];

  constructor(private router: Router, private productbuyService: ProductBuyService, private spinner: NgxSpinnerService) {
    this.editMenuOpt = JSON.parse(localStorage.getItem('paramGeneral'));
  }

  ngOnInit(): void {
    this.listProductBuy();
  }

  /**
   * Carga la tabla con los datos del catalogo codigo producto a comprar
   */
  listProductBuy() {
    this.spinner.show();
    this.productbuyService.listProductBuy().subscribe(response => {
      this.products = response;
    });
  }

  /**
   * Redirecciona al componente para crear codigo producto a comprar
   */
  addProductBuy(): void {
    this.router.navigate([
      '/home/parametrization/catalogos/product-buy-catalog/admin-product-buy',
    ]);
  }

  /**
   * Metodo para actualizar el estado del catalogo codigo producto a comprar
   */
  statusProductBuy(product: ProductBuyInterface) {
    this.productbuyService.updateProductBuyStatus(product).subscribe(
      (result) => {
        this.listProductBuy();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Redirecciona al componente para editar codigo producto a comprar
   */
   editProductBuy(product: ProductBuyInterface): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/product-buy-catalog/admin-product-buy',
        { editProfile: JSON.stringify(product) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  /**
   * Redirecciona a la tabla donde estan todos los catalogos
   */
  back(): void {
    this.router.navigate(['/home/parametrization/catalogos'], {
      replaceUrl: true,
    });
  }

}
