import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductBuyCatalogComponent } from './product-buy-catalog.component';

describe('ProductBuyCatalogComponent', () => {
  let component: ProductBuyCatalogComponent;
  let fixture: ComponentFixture<ProductBuyCatalogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductBuyCatalogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductBuyCatalogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
