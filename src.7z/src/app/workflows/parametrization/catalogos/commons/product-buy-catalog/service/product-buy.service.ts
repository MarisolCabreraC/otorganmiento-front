import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ProductBuyInterface } from '../interface/product-buy.interface';
import { API_CATALOGS } from '@src/utils/catalogs';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductBuyService {

  constructor(private http: HttpClient) { }

  /**
   * Funcion que permite consumir el servicio para guardar codigo producto comprar.
   * @param product a guardar.
   */
   createProductBuy(product: ProductBuyInterface): Observable<ProductBuyInterface> {
    return this.http.post<ProductBuyInterface>(API_CATALOGS.ADD_CATALOG_PRODUCT_BUY, product);
  }

  /**
   * Funcion que permite consumir el servicio para actualizar un codigo producto comprar.
   * @param product a actualizar.
   */
  updateProductBuy(product: ProductBuyInterface): Observable<ProductBuyInterface> {
    return this.http.post<ProductBuyInterface>(API_CATALOGS.UPDATE_CATALOG_PRODUCT_BUY, product);
  }

  /**
   * Funcion que permite consumir el servicio para actualizar el estado de codigo producto comprar
   * @param product estado a actualizar
   */
  updateProductBuyStatus(product: ProductBuyInterface): Observable<ProductBuyInterface> {
    return this.http.post<ProductBuyInterface>(API_CATALOGS.STATUS_CATALOG_PRODUCT_BUY, product);
  }

  /**
   * Funcion que permite consumur el servicio para consultar codigo producto comprar
   */
   listProductBuy(): Observable<ProductBuyInterface[]> {
    return this.http.post<ProductBuyInterface[]>(API_CATALOGS.LIST_CATALOG_PRODUCT_BUY, {});
  }
}
