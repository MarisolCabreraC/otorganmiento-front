// Modules
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Component
import { ProductBuyCatalogComponent } from './product-buy-catalog.component';

const routes: Routes = [
  {
    path: '',
    component: ProductBuyCatalogComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductBuyCatalogRoutingModule { }
