// Modules
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

// Route
import { ProductBuyCatalogRoutingModule } from './product-buy-catalog-routing.module';

// Component
import { ProductBuyCatalogComponent } from './product-buy-catalog.component';

@NgModule({
  declarations: [ProductBuyCatalogComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    ProductBuyCatalogRoutingModule
  ]
})
export class ProductBuyCatalogModule { }
