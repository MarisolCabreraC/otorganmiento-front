import { TestBed } from '@angular/core/testing';

import { ProductBuyService } from './product-buy.service';

describe('ProductBuyService', () => {
  let service: ProductBuyService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProductBuyService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
