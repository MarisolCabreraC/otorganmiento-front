import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

import { InterfaceDocumentType } from '@src/app/workflows/parametrization/catalogos/commons/document-type-catalog/interface-document-type/InterfaceDocumentType'
import { DocumentTypeService } from '@workflows/parametrization/catalogos/commons/document-type-catalog/service-document-type/document-type.service';
@Component({
  selector: 'app-document-type-catalog',
  templateUrl: './document-type-catalog.component.html',
  styleUrls: ['../../../../../../../src/assets/css/style_catalogue.scss']
})
export class DocumentTypeCatalogComponent implements OnInit {

  public editMenuOpt: boolean;
  documentTypes: InterfaceDocumentType[];
  public mensaje: any;

  constructor(private router: Router,
    private spinner: NgxSpinnerService,
    private documentTypeService: DocumentTypeService) {
      this.editMenuOpt = JSON.parse(localStorage.getItem('paramGeneral'));
     }

  ngOnInit(): void {
    this.initTableDocumentType();
  }

  public initTableDocumentType() {
    this.spinner.show();
    this.documentTypeService.consultarDocumentType().subscribe(response => {
      this.documentTypes = response;
      this.spinner.hide();
    });
  }

  public statatusDocumentType(documentType: InterfaceDocumentType) {
    this.documentTypeService.updateDocumentTypeStatus(documentType).subscribe(
      (result) => {
        this.initTableDocumentType();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    )
  }

  public editDocumentType(documentType: InterfaceDocumentType): void {
    this.router.navigate([
      'home/parametrization/catalogos/document-type-catalog/edit-document-type',
      { editProfile:        JSON.stringify(documentType) },
      { skipLocationChange: true, replaceUrl: false }
    ]
    )
  }

  public addDocumentType() {
    this.router.navigate(['/home/parametrization/catalogos/document-type-catalog/admin-document-type'], {
      replaceUrl: true,
    });
  }
  public back() {
    this.router.navigate(['/home/parametrization/catalogos'], {
      replaceUrl: true,
    });
  }
}
