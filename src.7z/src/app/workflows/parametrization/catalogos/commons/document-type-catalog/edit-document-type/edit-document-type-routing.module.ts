import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EditDocumentTypeComponent } from './edit-document-type.component';

const routes: Routes = [
  {
    path: '',
    component: EditDocumentTypeComponent
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EditDocumentTypeRoutingModule { }
