import { DatePipe } from '@angular/common';
import { Component, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import Swal from 'sweetalert2';

import { InterfaceDocumentType } from '../interface-document-type/InterfaceDocumentType';
import { DocumentTypeService } from '../service-document-type/document-type.service';


@Component({
  selector: 'app-edit-document-type',
  templateUrl: './edit-document-type.component.html',
  styleUrls: ['../../../../../../../../src/assets/css/style_catalogue.scss']
})
export class EditDocumentTypeComponent implements OnInit {
  public TypeDocForms: FormGroup;
  public interfaceDocumentType: InterfaceDocumentType;
  public idDocumentType: number;
  public crdenciales: string;
  public editParamId: number;

  public errorCode = false;

  constructor(
    private router: Router,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute,
    private datePipe: DatePipe,
    private documentTypeService: DocumentTypeService
  ) { }

  ngOnInit(): void {
    this.editParamId = parseInt(this.activatedRoute.snapshot.paramMap.get('id'));
    this.TypeDocForms = new FormGroup({
      codigo:        new FormControl('', [Validators.required, Validators.maxLength(10), Validators.pattern("^[0-9]*$")]),
      descripcion:   new FormControl('', [Validators.required, Validators.maxLength(50)]),
      nombre:        new FormControl('', [Validators.required, Validators.maxLength(10)]),
      abreviatura:   new FormControl('', [Validators.required, Validators.maxLength(10)]),
      indicador:     new FormControl('', [Validators.required, Validators.maxLength(10), Validators.pattern("^[0-9]*$")]),
      idSarc:        new FormControl('', [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      idAsobancaria: new FormControl('', [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      idGarantia:    new FormControl('', [Validators.required, Validators.maxLength(5)]),
      idCrm:         new FormControl('', [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      idBatch:       new FormControl('', [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      idHost:        new FormControl('', [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      idCartera:     new FormControl('', [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      idSeriva:      new FormControl('', [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
    })
    this.searchId();
  }

  public searchId() { 
    this.spinner.show();
    this.documentTypeService.consultarDocumentTypeiD(this.editParamId).subscribe(
      data => {
        this.interfaceDocumentType = data;
        this.TypeDocForms.controls['codigo'].setValue(this.editParamId);
        this.TypeDocForms.controls['descripcion'].setValue(this.interfaceDocumentType.descripcion);
        this.TypeDocForms.controls['nombre'].setValue(this.interfaceDocumentType.nombre);
        this.TypeDocForms.controls['abreviatura'].setValue(this.interfaceDocumentType.abreviatura);
        this.TypeDocForms.controls['indicador'].setValue(this.interfaceDocumentType.indicador);
        this.TypeDocForms.controls['idSarc'].setValue(this.interfaceDocumentType.idSarc);
        this.TypeDocForms.controls['idAsobancaria'].setValue(this.interfaceDocumentType.idAsobancaria);
        this.TypeDocForms.controls['idGarantia'].setValue(this.interfaceDocumentType.idGarantia);
        this.TypeDocForms.controls['idCrm'].setValue(this.interfaceDocumentType.idCrm);
        this.TypeDocForms.controls['idBatch'].setValue(this.interfaceDocumentType.idBatch);
        this.TypeDocForms.controls['idHost'].setValue(this.interfaceDocumentType.idHost);
        this.TypeDocForms.controls['idCartera'].setValue(this.interfaceDocumentType.idCartera);
        this.TypeDocForms.controls['idSeriva'].setValue(this.interfaceDocumentType.idSeriva);
        this.spinner.hide();
      },
      error => {
        this.spinner.hide();
      }
    )
  }


  public edit() {
    var obj = {
      codigo: this.TypeDocForms.get('codigo').value,
      descripcion: this.TypeDocForms.get('descripcion').value,
      nombre: this.TypeDocForms.get('nombre').value,
      abreviatura: this.TypeDocForms.get('abreviatura').value,
      indicador: this.TypeDocForms.get('indicador').value,
      idSarc: this.TypeDocForms.get('idSarc').value,
      idAsobancaria: this.TypeDocForms.get('idAsobancaria').value,
      idGarantia: this.TypeDocForms.get('idGarantia').value,
      idCrm: this.TypeDocForms.get('idCrm').value,
      idBatch: this.TypeDocForms.get('idBatch').value,
      idHost: this.TypeDocForms.get('idHost').value,
      idCartera: this.TypeDocForms.get('idCartera').value,
      idSeriva: this.TypeDocForms.get('idSeriva').value,
      usuario: localStorage.getItem('usuarioFront').split('@')[0]
    }
    this.documentTypeService.editDocumentType(obj).subscribe(
      data => {
        this.spinner.hide();
        if (data.code != null) {
          Swal.fire('', data.description, 'warning',)
        }
        else {
        document.getElementById('modalButtonEditClose').click();
        document.getElementById('openModalButtonEditClose').click();
        }
      },
      (error) => {
        Swal.fire('', error.error.description, 'warning',)
      });
  }

  public back() {
    this.router.navigate(['home/parametrization/catalogos/document-type-catalog/'],
    { replaceUrl: true });
  }

  openEditModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  closeModalEdit() {
    this.router.navigate(['home/parametrization/catalogos/document-type-catalog/'],
    { replaceUrl: true });
  }
}
