import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DocumentTypeCatalogRoutingModule } from './document-type-catalog-routing.module';
import { DocumentTypeCatalogComponent } from '@workflows/parametrization/catalogos/commons/document-type-catalog/document-type-catalog.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';




@NgModule({
  declarations: [DocumentTypeCatalogComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    DocumentTypeCatalogRoutingModule,
    NgbModule
  ],
  exports:[ DocumentTypeCatalogComponent]
})
export class DocumentTypeCatalogModule { }
