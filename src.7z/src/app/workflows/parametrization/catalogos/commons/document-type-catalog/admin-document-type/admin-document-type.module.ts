import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AdminDocumentTypeRoutingModule } from './admin-document-type-routing.module';
import { AdminDocumentTypeComponent } from '@workflows/parametrization/catalogos/commons/document-type-catalog/admin-document-type/admin-document-type.component';



@NgModule({
  declarations: [AdminDocumentTypeComponent],
  imports: [
    CommonModule, 
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    AdminDocumentTypeRoutingModule,
    NgbModule
  ],
  exports:[AdminDocumentTypeComponent]
})
export class AdminDocumentTypeModule { }
