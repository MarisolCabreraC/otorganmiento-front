import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { InterfaceDocumentType } from '@src/app/workflows/parametrization/catalogos/commons/document-type-catalog/interface-document-type/InterfaceDocumentType'
import { API_CATALOGS } from '@src/utils/catalogs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class DocumentTypeService {

  constructor(public http: HttpClient) { }
  public consultarDocumentType() {
    return this.http.post<InterfaceDocumentType[]>(API_CATALOGS.SEARCH_CATALOG_TYPEDOCUMENT_ENTITY, {})
  }
  public consultarDocumentTypeiD(id: number) {
    return this.http.post<InterfaceDocumentType>(API_CATALOGS.SEARCH_CATALOG_TYPEDOCUMENT_ID_ENTITY, { codigo: id })
  }

  public editDocumentType(interfaceDocumentType: InterfaceDocumentType): Observable<InterfaceDocumentType> {
    return this.http.post<InterfaceDocumentType>(API_CATALOGS.UPDATE_CATALOG_TYPEDOCUMENT_STATEMENT, interfaceDocumentType)
  }

  public createDocumentType(formData: InterfaceDocumentType): Observable<InterfaceDocumentType> {
    return this.http.post<InterfaceDocumentType>(API_CATALOGS.ADD_CATALOG_TYPEDOCUMENT_ENTITY,formData)
  }

  public updateDocumentTypeStatus(interfaceDocumentType: InterfaceDocumentType): Observable<InterfaceDocumentType> {
    return this.http.post<InterfaceDocumentType>(API_CATALOGS.STATUS_CATALOG_TYPEDOCUMENT_ENTITY, interfaceDocumentType)
  }
}
