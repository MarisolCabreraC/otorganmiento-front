import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


import { EditDocumentTypeRoutingModule } from './edit-document-type-routing.module';
import { EditDocumentTypeComponent } from '@workflows/parametrization/catalogos/commons/document-type-catalog/edit-document-type/edit-document-type.component';

@NgModule({
  declarations: [EditDocumentTypeComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    EditDocumentTypeRoutingModule,
    NgbModule
  ],
  exports:[EditDocumentTypeComponent]
})
export class EditDocumentTypeModule { }
