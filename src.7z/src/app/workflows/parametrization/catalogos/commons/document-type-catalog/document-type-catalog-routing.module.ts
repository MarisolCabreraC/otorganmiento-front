import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DocumentTypeCatalogComponent } from '@workflows/parametrization/catalogos/commons/document-type-catalog/document-type-catalog.component';


const routes: Routes = [
  {
    path: '',
    component: DocumentTypeCatalogComponent
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DocumentTypeCatalogRoutingModule { }
