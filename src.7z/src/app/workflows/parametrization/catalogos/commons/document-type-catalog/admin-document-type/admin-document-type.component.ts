import { Component, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import Swal from 'sweetalert2';

import { InterfaceDocumentType } from '@workflows/parametrization/catalogos/commons/document-type-catalog/interface-document-type/InterfaceDocumentType';
import { DocumentTypeService } from '@workflows/parametrization/catalogos/commons/document-type-catalog/service-document-type/document-type.service';
@Component({
  selector: 'app-admin-document-type',
  templateUrl: './admin-document-type.component.html',
  styleUrls: ['../../../../../../../../src/assets/css/style_catalogue.scss']
})
export class AdminDocumentTypeComponent implements OnInit {

  public TypeDocForms: FormGroup;
  public interfaceDocumentType: InterfaceDocumentType;
  public idDocumentType: number;
  public crdenciales: string;

  public errorCode = false;
  public operacion: string = '';

  constructor(
    private router: Router,
    private spinner: NgxSpinnerService,
    private documentTypeService: DocumentTypeService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.TypeDocForms = new FormGroup({
      codigo: new FormControl('', [Validators.required, Validators.maxLength(10), Validators.pattern("^[0-9]*$")]),
      descripcion: new FormControl('', [Validators.required, Validators.maxLength(50)]),
      nombre: new FormControl('', [Validators.required, Validators.maxLength(10)]),
      abreviatura: new FormControl('', [Validators.required, Validators.maxLength(10)]),
      indicador: new FormControl('', [Validators.required, Validators.maxLength(10), Validators.pattern("^[0-9]*$")]),
      idSarc: new FormControl('', [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      idAsobancaria: new FormControl('', [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      idGarantia: new FormControl('', [Validators.required, Validators.maxLength(5)]),
      idCrm: new FormControl('', [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      idBatch: new FormControl('', [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      idHost: new FormControl('', [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      idCartera: new FormControl('', [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      idSeriva: new FormControl('', [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
    })
    this.loadData();
  }

  loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.operacion = 'Agregar';
    });
  }

  public save() {
    this.spinner.show();

    var obj = {
      codigo: this.TypeDocForms.get('codigo').value,
      descripcion: this.TypeDocForms.get('descripcion').value,
      nombre: this.TypeDocForms.get('nombre').value,
      abreviatura: this.TypeDocForms.get('abreviatura').value,
      indicador: this.TypeDocForms.get('indicador').value,
      idSarc: this.TypeDocForms.get('idSarc').value,
      idAsobancaria: this.TypeDocForms.get('idAsobancaria').value,
      idGarantia: this.TypeDocForms.get('idGarantia').value,
      idCrm: this.TypeDocForms.get('idCrm').value,
      idBatch: this.TypeDocForms.get('idBatch').value,
      idHost: this.TypeDocForms.get('idHost').value,
      idCartera: this.TypeDocForms.get('idCartera').value,
      idSeriva: this.TypeDocForms.get('idSeriva').value,
      usuario: localStorage.getItem('usuarioFront').split('@')[0]
    }

    this.documentTypeService.createDocumentType(obj).subscribe(
      data => {
        document.getElementById('openModalButtonEdit').click();
        if (data.code != null) {
          Swal.fire('', data.description, 'warning',)
        }
        else {
          this.router.navigate(['home/parametrization/catalogos/document-type-catalog'], {
            replaceUrl: true,
          });
        }
      },
      (error) => {
        Swal.fire('', error.error.description, 'warning',)
      });
  }

  public back() {
    this.router.navigate(['/home/parametrization/catalogos/document-type-catalog'],
      { replaceUrl: true });
  }

  openAddModal() {
    document.getElementById('openModalButtonEdit').click();
  }
}