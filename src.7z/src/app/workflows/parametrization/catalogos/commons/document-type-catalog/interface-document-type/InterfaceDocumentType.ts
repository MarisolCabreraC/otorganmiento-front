export interface InterfaceDocumentType  {
    codigo:         number;
    descripcion:    string;
    nombre:         string;
    abreviatura:    string;
    indicador:      number;
    activo?:        number;
    idSarc:         number;
    idAsobancaria:  number;
    idGarantia:     string;
    idCrm:          number;
    idBatch:        number;
    idHost:         number;
    idCartera:      number;
    idSeriva:       number;
    usuario?:       string;
    dtCreacion?:    string;
    code?:          string;
    description?:   string;
    errorType?:     string ; 
    exceptionDetails?: [
        {
            component?: string,
            endPoint?:  string
        }
    ]
}