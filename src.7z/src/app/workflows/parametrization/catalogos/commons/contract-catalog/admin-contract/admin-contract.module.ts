import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminContractRoutingModule } from './admin-contract-routing.module';
import { AdminContractComponent } from '@workflows/parametrization/catalogos/commons/contract-catalog/admin-contract/admin-contract.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';

@NgModule({
  declarations: [AdminContractComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    AdminContractRoutingModule
  ],
  exports:[AdminContractComponent]
})
export class AdminContractModule { }
