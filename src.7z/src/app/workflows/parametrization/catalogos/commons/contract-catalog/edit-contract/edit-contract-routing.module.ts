import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EditContractComponent } from './edit-contract.component';


const routes: Routes = [{
  path: '',
  component: EditContractComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EditContractRoutingModule { }
