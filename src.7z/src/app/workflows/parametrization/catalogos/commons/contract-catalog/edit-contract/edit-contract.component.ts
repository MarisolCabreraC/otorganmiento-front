import { Component, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { InfoCatalogoContrato } from '@commons/models/infoCatalogoContracto';
import { MainService } from '@commons/services/main.service';
import { ModalsComponent } from '@workflows/modals/modals.component';
import { Contract } from '../model/interfaceContract';
import { ContrarctService } from '../services/contract.service';

@Component({
  selector: 'app-edit-contract',
  templateUrl: './edit-contract.component.html',
  styleUrls: ['./edit-contract.component.scss'],
})
export class EditContractComponent implements OnInit {
  @ViewChild('examplemodal') modal: ModalsComponent;
  public errorCode = false;
  public errorCodeText = 'el dato no ha sido procesado';
  public mensaje: string;
  public idTipoContrato: number;
  public activo: boolean;
  public nombre: string;
  public operacion: string = '';
  public titulo: string = '';
  public contractForm: FormGroup;
  public contrato: InfoCatalogoContrato;
  public contract: Contract = {
    idTipoContrato: '',
    nombre: '',
    activo : null
  }
  constructor(
    private contractService:ContrarctService,
    private mainService: MainService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    this.loadData();
    this.contractForm = new FormGroup({
      idTipoContrato: new FormControl(this.contract.idTipoContrato, [
        Validators.required,
        Validators.maxLength(5),
      ]),
      nombre: new FormControl(this.contract.nombre, [
        Validators.required,
        Validators.maxLength(50),
      ]),
      activo: new FormControl(this.contract.activo),
    });
  }

  loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.operacion = 'Agregar';
      this.titulo = ' contrato';
      this.contract = JSON.parse(params['editContract']) as Contract;
    });
  }

  // createContract() {
  //   this.contrato = new InfoCatalogoContrato();
  //   this.contrato.nombre = this.contractForm.controls['nombre'].value;
  //   this.contrato.idTipoContrato = this.contractForm.controls[
  //     'idTipoContrato'
  //   ].value;

  //   this.mainService.createContract(this.contrato).subscribe(
  //     (result) => {
  //       document.getElementById('openModalButtonEdit').click();
  //       this.router.navigate(
  //         ['home/parametrization/catalogos/contract-catalog'],
  //         {
  //           replaceUrl: true,
  //         }
  //       );
  //     },
  //     (error) => {
  //       this.mensaje = 'Error: ' + error.error.description;
  //     }
  //   );
  // }
  updateContract(){

    this.contract.nombre = this.contractForm.controls['nombre'].value;
    this.contractService.updateContract(this.contract).subscribe(
      (result)=>{
        document.getElementById('openModalButtonEdit').click();
          this.router.navigate(
            ['home/parametrization/catalogos/contract-catalog'],
            {
              replaceUrl: true,
            }
          );

      },
      (error) =>{
        this.mensaje = 'Error: ' + error.error.description;
      }
    )


  }

  openEditModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  closeModalEdit() {
    this.router.navigate(['home/parametrization/catalogos/contract-catalog'], {
      replaceUrl: true,
    });
  }
  public back(): void {
    this.router.navigate(['home/parametrization/catalogos/contract-catalog'], {
      replaceUrl: true,
    });
  }
}
