import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ContractCatalogRoutingModule } from './contract-catalog-routing.module';
import { ContractCatalogComponent } from '@workflows/parametrization/catalogos/commons/contract-catalog/contract-catalog.component'
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '@src/app/commons/shared/shared.module';

@NgModule({
  declarations: [ContractCatalogComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    ContractCatalogRoutingModule
  ]
  ,
  exports: [ContractCatalogComponent]

})
export class ContractCatalogModule { }
