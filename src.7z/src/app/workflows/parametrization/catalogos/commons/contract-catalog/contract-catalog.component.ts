import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { InfoCatalogoContrato } from '@commons/models/infoCatalogoContracto';
import { MainService } from '@commons/services/main.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { Contract } from './model/interfaceContract';

@Component({
  selector: 'app-contract-catalog',
  templateUrl: './contract-catalog.component.html',
  styleUrls: ['./contract-catalog.component.scss'],
})
export class ContractCatalogComponent implements OnInit {
  public listContract: any;
  public mensaje: any;
  public editMenuOpt: boolean;
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private spinner: NgxSpinnerService,
    private mainService: MainService
  ) {
    this.editMenuOpt = JSON.parse(localStorage.getItem('paramGeneral'));
  }

  ngOnInit(): void {
    this.initTableContract();
  }

  initTableContract() {
    this.spinner.show();
    this.mainService.findCatalogContractByProfile().subscribe((result) => {
      this.listContract = result.registros;
      console.log(this.listContract);
    });
  }

  public addContract(): void {
    this.router.navigate([
      '/home/parametrization/catalogos/contract-catalog/admin-contract',
    ]);
  }

  /**
   * Redirecciona al componente para editar tipo contrato
   */
  public editContrato(contract: Contract): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/contract-catalog/edit-contract',
        { editContract: JSON.stringify(contract) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  public refreshContract(): void {
    this.router.navigate(['/home/parametrization/catalogos/contract-catalog']);
  }

  public statusContract(product: InfoCatalogoContrato, status: boolean) {
    product.activo = status;
    this.mainService.updateContractStatus(product).subscribe(
      (result) => {
        //window.location.reload();
        this.refreshContract();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  public back(): void {
    this.router.navigate(['/home/parametrization/catalogos'], {
      replaceUrl: true,
    });
  }
}
