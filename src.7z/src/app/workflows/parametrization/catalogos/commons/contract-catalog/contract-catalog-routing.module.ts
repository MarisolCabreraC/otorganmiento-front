import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ContractCatalogComponent } from '@workflows/parametrization/catalogos/commons/contract-catalog/contract-catalog.component'

const routes: Routes = [{
  path: '',
  component: ContractCatalogComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ContractCatalogRoutingModule { }
