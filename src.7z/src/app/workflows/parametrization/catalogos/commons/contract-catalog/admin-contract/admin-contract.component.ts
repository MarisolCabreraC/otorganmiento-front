import { Component, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { InfoCatalogoContrato } from '@commons/models/infoCatalogoContracto';
import { MainService } from '@commons/services/main.service';
import { ModalsComponent } from '@workflows/modals/modals.component';

@Component({
  selector: 'app-admin-contract',
  templateUrl: './admin-contract.component.html',
  styleUrls: ['./admin-contract.component.scss'],
})
export class AdminContractComponent implements OnInit {
  @ViewChild('examplemodal') modal: ModalsComponent;
  public errorCode = false;
  public errorCodeText = 'el dato no ha sido procesado';
  public mensaje: string;
  public idTipoContrato: number;
  public activo: boolean;
  public nombre: string;
  public operacion: string = '';
  public titulo: string = '';
  public contractForm: FormGroup;
  public contrato: InfoCatalogoContrato;
  constructor(
    private mainService: MainService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    this.loadData();
    this.contractForm = new FormGroup({
      idTipoContrato: new FormControl(this.idTipoContrato, [
        Validators.required,
        Validators.maxLength(5),
      ]),
      nombre: new FormControl(this.nombre, [
        Validators.required,
        Validators.maxLength(50),
      ]),
      activo: new FormControl(this.activo),
    });
  }

  loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.operacion = 'Agregar';
      this.titulo = ' contrato';
    });
  }

  createContract() {
    this.contrato = new InfoCatalogoContrato();
    this.contrato.nombre = this.contractForm.controls['nombre'].value;
    this.contrato.idTipoContrato = this.contractForm.controls[
      'idTipoContrato'
    ].value;

    this.mainService.createContract(this.contrato).subscribe(
      (result) => {
        document.getElementById('openModalButtonEdit').click();
        this.router.navigate(
          ['home/parametrization/catalogos/contract-catalog'],
          {
            replaceUrl: true,
          }
        );
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  openEditModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  closeModalEdit() {
    this.router.navigate(['home/parametrization/catalogos/contract-catalog'], {
      replaceUrl: true,
    });
  }
  public back(): void {
    this.router.navigate(['home/parametrization/catalogos/contract-catalog'], {
      replaceUrl: true,
    });
  }
}
