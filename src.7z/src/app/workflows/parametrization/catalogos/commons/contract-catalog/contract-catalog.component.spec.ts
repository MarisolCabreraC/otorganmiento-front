import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContractCatalogComponent } from './contract-catalog.component';

describe('ContractCatalogComponent', () => {
  let component: ContractCatalogComponent;
  let fixture: ComponentFixture<ContractCatalogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContractCatalogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContractCatalogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
