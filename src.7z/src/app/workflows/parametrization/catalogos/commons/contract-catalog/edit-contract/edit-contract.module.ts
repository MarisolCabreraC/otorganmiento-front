import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import { EditContractRoutingModule } from './edit-contract-routing.module';

import {EditContractComponent} from './edit-contract.component'
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { from } from 'rxjs';

@NgModule({
  declarations: [EditContractComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    EditContractRoutingModule
  ],
  exports:[EditContractComponent]
})
export class EditContractModule { }
