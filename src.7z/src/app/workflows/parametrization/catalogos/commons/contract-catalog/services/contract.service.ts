import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { API_CATALOGS } from '@src/utils/catalogs';
import { Contract } from '../model/interfaceContract';
// import {Account} from '../model/interfaceAccount'

@Injectable({
  providedIn: 'root'
})
export class ContrarctService {

  constructor(private clientHttp: HttpClient) { }



  /**
   * Funcion que permite consumir el servicio para guardar tipo contrato .
   * @param Contract a guardar.
   */
  public createContract(contract: Contract) {
    return this.clientHttp.post<Contract>(
      API_CATALOGS.ADD_CATALOG_CONTRACT,
      contract
    );
  }

  /**
   * Funcion que permite consumir el servicio para actualizar un tipo contrato
   * @param Contract a actualizar.
   */
  updateContract(contract: Contract): Observable<Account> {
    return this.clientHttp.post<Account>(API_CATALOGS.UPDATE_CATALOG_CONTRACT, contract);
  }

  /**
   * Funcion que permite consumir el servicio para actualizar el tipo de cuenta
   * @param account estado a actualizar
   */
  updateAcountStatus(account: Account): Observable<Account> {
    return this.clientHttp.post<Account>(API_CATALOGS.STATUS_CATALOG_ACCOUNT, account);
  }

  /**
   * Funcion que permite consumur el servicio para consultar tipo de cuenta
   */
  findCatalogAcountByProfile(): Observable<Account[]> {
    return this.clientHttp.post<Account[]>(API_CATALOGS.SEARCH_CATALOG_ACCOUNT, {});
  }
}
