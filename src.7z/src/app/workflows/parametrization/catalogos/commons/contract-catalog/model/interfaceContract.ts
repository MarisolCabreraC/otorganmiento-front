export interface Contract{
    idTipoContrato: string;
    nombre: string;
    activo?: boolean;
  }