// Modules
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Component
import { AdminRolComponent } from './admin-rol.component';

const routes: Routes = [
  {
    path: '',
    component: AdminRolComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRolRoutingModule { }
