import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API_CATALOGS } from '@src/utils/catalogs';
import { Observable } from 'rxjs';
import { RolInterface } from '../interface/rol.interface';

@Injectable({
  providedIn: 'root'
})
export class RolService {

  constructor(private http: HttpClient) { }

  /**
   * Funcion que permite consumir el servicio para guardar rol.
   * @param rol a guardar.
   */
   createRol(rol: RolInterface): Observable<RolInterface> {
    return this.http.post<RolInterface>(API_CATALOGS.ADD_CATALOG_ROL, rol);
  }

  /**
   * Funcion que permite consumir el servicio para actualizar un rol.
   * @param rol a actualizar.
   */
  updateRol(rol: RolInterface): Observable<RolInterface> {
    return this.http.post<RolInterface>(API_CATALOGS.UPDATE_CATALOG_ROL, rol);
  }

  /**
   * Funcion que permite consumir el servicio para actualizar el estado de rol
   * @param rol estado a actualizar
   */
  updateRolStatus(rol: RolInterface): Observable<RolInterface> {
    return this.http.post<RolInterface>(API_CATALOGS.STATUS_CATALOG_ROL, rol);
  }

  /**
   * Funcion que permite consumur el servicio para consultar rol
   */
   listRol(): Observable<RolInterface[]> {
    return this.http.post<RolInterface[]>(API_CATALOGS.LIST_CATALOG_ROL, {});
  }
}
