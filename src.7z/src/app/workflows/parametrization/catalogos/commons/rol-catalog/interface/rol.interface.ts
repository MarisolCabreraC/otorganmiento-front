/**
 * Entidad que mapea la informacion obtenida del microservicio del catalogo rol titularidad.
 */
 export interface RolInterface {
    /**
   * Identificador del catalogo rol titularidad.
   */
    codigo        : number;
    /**
   * Nombre del catalogo rol titularidad.
   */
    nombre         : string;
    /**
   * Identificador de cartera.
   */
    idCartera        : number;
    /**
   * Usuario que crea el catalogo rol titularidad.
   */
    usuario?        : string;
    /**
   * Estado del catalogo rol titularidad (activo - inactivo)
   */
    activo?        : boolean;
}