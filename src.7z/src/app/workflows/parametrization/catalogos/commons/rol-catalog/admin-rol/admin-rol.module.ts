// Modules
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

// Route
import { AdminRolRoutingModule } from '@workflows/parametrization/catalogos/commons/rol-catalog/admin-rol/admin-rol-routing.module';

// Service
import { RolService } from '@workflows/parametrization/catalogos/commons/rol-catalog/service/rol.service';

// Component
import { AdminRolComponent } from '@workflows/parametrization/catalogos/commons/rol-catalog/admin-rol/admin-rol.component';

@NgModule({
  declarations: [AdminRolComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    NgbModule,
    AdminRolRoutingModule
  ],
  providers: [RolService]
})
export class AdminRolModule { }
