// Modules
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

// Route
import { RolCatalogRoutingModule } from '@workflows/parametrization/catalogos/commons/rol-catalog/rol-catalog-routing.module';

// Service
import { RolService } from '@workflows/parametrization/catalogos/commons/rol-catalog/service/rol.service';

// Component
import { RolCatalogComponent } from '@workflows/parametrization/catalogos/commons/rol-catalog/rol-catalog.component';

@NgModule({
  declarations: [RolCatalogComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    RolCatalogRoutingModule
  ],
  providers: [RolService]
})
export class RolCatalogModule { }
