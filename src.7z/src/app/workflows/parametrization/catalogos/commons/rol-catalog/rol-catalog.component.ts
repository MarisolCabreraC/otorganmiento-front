import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { RolInterface } from './interface/rol.interface';
import { RolService } from './service/rol.service';

@Component({
  selector: 'app-rol-catalog',
  templateUrl: './rol-catalog.component.html',
  styleUrls: ['../../../../../../../src/assets/css/style_catalogue.scss']
})
export class RolCatalogComponent implements OnInit {

  public mensaje: any;
  public editMenuOpt: boolean;
  roles: RolInterface[];

  constructor(private router: Router, private rolService: RolService, private spinner: NgxSpinnerService) {
    this.editMenuOpt = JSON.parse(localStorage.getItem('paramGeneral'));
  }

  ngOnInit(): void {
    this.listRol();
  }

  /**
   * Carga la tabla con los datos del catalogo rol titularidad
   */
   listRol() {
    this.spinner.show();
    this.rolService.listRol().subscribe(response => {
      this.roles = response;
      this.spinner.hide();
    });
  }

  /**
   * Redirecciona al componente para crear rol titularidad
   */
   addRol(): void {
    this.router.navigate([
      '/home/parametrization/catalogos/rol-catalog/admin-rol',
    ]);
  }

  /**
   * Metodo para actualizar el estado del catalogo rol titularidad
   */
  statusRol(role: RolInterface) {
    this.rolService.updateRolStatus(role).subscribe(
      (result) => {
        this.listRol();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Redirecciona al componente para editar rol titularidad
   */
   editRol(role: RolInterface): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/rol-catalog/admin-rol',
        { editProfile: JSON.stringify(role) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  /**
   * Redirecciona a la tabla donde estan todos los catalogos
   */
  back(): void {
    this.router.navigate(['/home/parametrization/catalogos'], {
      replaceUrl: true,
    });
  }

}
