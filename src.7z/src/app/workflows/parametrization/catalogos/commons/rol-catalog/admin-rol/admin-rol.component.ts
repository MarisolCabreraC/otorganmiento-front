import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ModalsComponent } from '@workflows/modals/modals.component';
import { RolInterface } from '../interface/rol.interface';
import { RolService } from '../service/rol.service';

@Component({
  selector: 'app-admin-rol',
  templateUrl: './admin-rol.component.html',
  styleUrls: ['../../../../../../../../src/assets/css/style_catalogue.scss']
})
export class AdminRolComponent implements OnInit {

  @ViewChild('examplemodal') modal: ModalsComponent;
  errorCode = false;
  errorCodeText = 'el dato no ha sido procesado';
  mensaje: string;
  codigo: number;
  idCartera: number;
  nombre: string;
  activo: boolean = true;
  status: boolean;
  operacion: string = '';
  titulo: string = '';
  boton: string = '';
  form: FormGroup;
  rol: RolInterface;

  constructor(private rolService: RolService, private router: Router, private activatedRoute: ActivatedRoute, public formBuilder: FormBuilder) {
    this.activatedRoute.params.subscribe((params) => {
      if (params.editProfile) {
        this.operacion = 'Editar';
        this.titulo = ' Rol';
        this.boton = 'Actualizar';
        this.loadData();
      } else {
        this.operacion = 'Agregar';
        this.titulo = ' Rol';
        this.boton = 'Crear';
      }
    });
  }

  ngOnInit(): void {
    this.buildForm();
  }

  /**
   * Carga data
   */
   loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.rol = JSON.parse(params['editProfile']) as RolInterface;
      this.nombre = this.rol.nombre;
      this.idCartera = this.rol.idCartera;
      this.codigo = this.rol.codigo;

      if (this.nombre == null) {
        this.status = true;
      }
    });
  }

  /**
   * Form rol
   */
   buildForm(): void {
    const user: string = localStorage.getItem('usuarioFront');
    const user2 = user.split('@');
    this.form = this.formBuilder.group({
      codigo: new FormControl(this.codigo),
      nombre: new FormControl(this.nombre, [Validators.required, Validators.maxLength(50)]),
      idCartera: new FormControl(this.idCartera, [Validators.required, Validators.maxLength(10), Validators.pattern("^[0-9]*$")]),
      usuario: new FormControl(user2[0])
    });
  }

  /**
   * Metodo que crea rol
   */
   createRol() {
    const data = {
      nombre: this.form.controls['nombre'].value,
      idCartera: this.form.controls['idCartera'].value,
      usuario: this.form.controls['usuario'].value,
      codigo: this.form.controls['codigo'].value
    }

    this.rolService.createRol(data).subscribe(
      (result) => {
        document.getElementById('openModalButtonEdit').click();
        this.router.navigate(['home/parametrization/catalogos/rol-catalog'], {
          replaceUrl: true,
        });
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Metodo que actualiza rol
   */
   updateRol() {
    this.mensaje = '';
    this.rol.nombre = this.form.controls['nombre'].value;
    this.rol.idCartera = this.form.controls['idCartera'].value;
    this.rolService.updateRol(this.rol).subscribe(
      (result) => {
        document.getElementById('modalButtonEditClose').click();
        document.getElementById('openModalButtonEditClose').click();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Metodo que abre la ventana modal para crear rol
   */
   openModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  /**
   * Metodo que cierra el modal y redirecciona al listado de rol
   */
  closeModalEdit() {
    this.router.navigate(['home/parametrization/catalogos/rol-catalog'], {
      replaceUrl: true,
    });
  }

  /**
   * Redirecciona al listado de rol
   */
  back(): void {
    this.router.navigate(['home/parametrization/catalogos/rol-catalog'], {
      replaceUrl: true,
    });
  }

}
