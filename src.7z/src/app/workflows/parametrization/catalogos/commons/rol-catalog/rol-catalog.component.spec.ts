import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RolCatalogComponent } from './rol-catalog.component';

describe('RolCatalogComponent', () => {
  let component: RolCatalogComponent;
  let fixture: ComponentFixture<RolCatalogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RolCatalogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RolCatalogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
