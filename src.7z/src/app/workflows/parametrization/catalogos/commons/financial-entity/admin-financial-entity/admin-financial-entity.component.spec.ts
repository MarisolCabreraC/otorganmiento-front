import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminFinancialEntityComponent } from './admin-financial-entity.component';

describe('AdminFinancialEntityComponent', () => {
  let component: AdminFinancialEntityComponent;
  let fixture: ComponentFixture<AdminFinancialEntityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminFinancialEntityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminFinancialEntityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
