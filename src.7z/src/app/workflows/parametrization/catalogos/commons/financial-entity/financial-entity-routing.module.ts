import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FinancialEntityComponent } from './financial-entity.component';


const routes: Routes = [
  {
    path: '',
    component: FinancialEntityComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FinancialEntityRoutingModule { }
