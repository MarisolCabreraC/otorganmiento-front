import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { API_CATALOGS } from '@src/utils/catalogs';
import { Observable } from 'rxjs';
import { FinancialEntityInterface } from '../model/financial-entity.model';

@Injectable({
  providedIn: 'root'
})
export class FinancialEntityService {

  constructor(private http: HttpClient) { }

  /**
   * Funcion que permite consumir el servicio para guardar entidad financiera.
   * @param financial a guardar.
   */
   createEntity(financial: FinancialEntityInterface): Observable<FinancialEntityInterface> {
    return this.http.post<FinancialEntityInterface>(API_CATALOGS.ADD_CATALOG_FINANCIAL_ENTITY, financial);
  }

  /**
   * Funcion que permite consumir el servicio para actualizar un entidad financiera.
   * @param financial a actualizar.
   */
  updateEntity(financial: FinancialEntityInterface): Observable<FinancialEntityInterface> {
    return this.http.post<FinancialEntityInterface>(API_CATALOGS.UPDATE_CATALOG_FINANCIAL_ENTITY, financial);
  }

  /**
   * Funcion que permite consumir el servicio para actualizar el estado entidad financiera
   * @param financial estado a actualizar
   */
  updateEntityStatus(financial: FinancialEntityInterface): Observable<FinancialEntityInterface> {
    return this.http.post<FinancialEntityInterface>(API_CATALOGS.STATUS_CATALOG_FINANCIAL_ENTITY, financial);
  }

  /**
   * Funcion que permite consumur el servicio para consultar entidad financiera
   */
  findCatalogEntityByProfile(): Observable<FinancialEntityInterface[]> {
    return this.http.post<FinancialEntityInterface[]>(API_CATALOGS.SEARCH_CATALOG_FINANCIAL_ENTITY, {});
  }
}
