import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { FinancialEntityInterface } from './model/financial-entity.model';
import { FinancialEntityService } from './service/financial-entity.service';


@Component({
  selector: 'app-financial-entity',
  templateUrl: './financial-entity.component.html',
  styleUrls: ['../../../../../../../src/assets/css/style_catalogue.scss']
})
export class FinancialEntityComponent implements OnInit {
  
  public mensaje: any;
  public editMenuOpt: boolean;
  entitys: FinancialEntityInterface[];
  filter = '';

  constructor(private router: Router, private spinner: NgxSpinnerService, private financialService: FinancialEntityService) {
      this.editMenuOpt = JSON.parse(localStorage.getItem('paramGeneral'));
  }

  ngOnInit(): void {
    this.listFinancialEntity();
  }

  /**
   * Carga la tabla con los datos de entidad financiera
   */
  public listFinancialEntity() {
    this.spinner.show();
    this.financialService.findCatalogEntityByProfile().subscribe(response => {
      this.entitys = response;
      this.spinner.hide();
    });
  }

  /**
   * Redirecciona al componente para crear entidad financiera
   */
  public addEntity(): void {
    this.router.navigate([
      '/home/parametrization/catalogos/financial-entity/admin-financial-entity',
    ]);
  }

  /**
   * Metodo para actualizar el estado de entidad financiera
   */
   public statusEntity(entity: FinancialEntityInterface) {
    this.financialService.updateEntityStatus(entity).subscribe(
      (result) => {
        this.listFinancialEntity();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Redirecciona al componente para editar entidad financiera
   */
   public editEntity(entity: FinancialEntityInterface): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/financial-entity/edit-financial-entity',
        { editProfile: JSON.stringify(entity) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  public back(): void {
    this.router.navigate(['/home/parametrization/catalogos'], {
      replaceUrl: true,
    });
  }
}
