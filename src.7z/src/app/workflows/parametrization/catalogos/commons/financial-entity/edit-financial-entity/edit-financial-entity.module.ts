// Modules
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

// Route
import { EditFinancialEntityRoutingModule } from './edit-financial-entity-routing.module';

// Service
import { FinancialEntityService } from '../service/financial-entity.service';

// Component
import { EditFinancialEntityComponent } from './edit-financial-entity.component';

@NgModule({
  declarations: [EditFinancialEntityComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    NgbModule,
    EditFinancialEntityRoutingModule
  ],
  providers: [FinancialEntityService]
})
export class EditFinancialEntityModule { }
