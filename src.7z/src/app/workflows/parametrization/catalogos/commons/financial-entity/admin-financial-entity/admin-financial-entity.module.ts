// Module
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

// Route
import { AdminFinancialEntityRoutingModule } from './admin-financial-entity-routing.module';

// Service
import { FinancialEntityService } from '../service/financial-entity.service';

// Component
import { AdminFinancialEntityComponent } from './admin-financial-entity.component';

// Component

@NgModule({
  declarations: [AdminFinancialEntityComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    NgbModule,
    AdminFinancialEntityRoutingModule
  ],
  providers: [FinancialEntityService]
})
export class AdminFinancialEntityModule { }
