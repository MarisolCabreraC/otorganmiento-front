import { TestBed } from '@angular/core/testing';

import { FinancialEntityService } from './financial-entity.service';

describe('FinancialEntityService', () => {
  let service: FinancialEntityService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FinancialEntityService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
