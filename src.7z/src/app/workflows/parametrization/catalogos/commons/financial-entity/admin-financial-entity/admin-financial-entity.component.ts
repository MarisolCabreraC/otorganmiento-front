import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ModalsComponent } from '@workflows/modals/modals.component';
import { FinancialEntityInterface } from '../model/financial-entity.model';
import { FinancialEntityService } from '../service/financial-entity.service';

@Component({
  selector: 'app-admin-financial-entity',
  templateUrl: './admin-financial-entity.component.html',
  styleUrls: ['../../../../../../../../src/assets/css/style_catalogue.scss']
})
export class AdminFinancialEntityComponent implements OnInit {

  @ViewChild('examplemodal') modal: ModalsComponent;
  public errorCode = false;
  public errorCodeText = 'el dato no ha sido procesado';
  public mensaje: string;
  public idEntidadFinanciera: number;
  public numeroIdentificacion: number;
  public idCartera: number;
  public nombre: string;
  public activo: boolean = true;
  public operacion: string = '';
  public titulo: string = '';
  public entityForm: FormGroup;
  public entity: FinancialEntityInterface;

  constructor(private entityService: FinancialEntityService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.loadData();
    this.buildForm();
  }

  /**
   * Asigna data
   */
   loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.operacion = 'Agregar';
      this.titulo = ' Entidad Financiera';
    });
  }

  /**
   * Form entidad financiera
   */
   buildForm(): void {
    const user: string = localStorage.getItem('usuarioFront');
    const user2 = user.split('@');
    this.entityForm = this.formBuilder.group({
      idEntidadFinanciera: new FormControl(this.idEntidadFinanciera, [Validators.required, Validators.maxLength(3), Validators.pattern("^[0-9]*$")]),
      nombre: new FormControl(this.nombre, [Validators.required, Validators.maxLength(50)]),
      numeroIdentificacion: new FormControl(this.numeroIdentificacion, [Validators.required, Validators.maxLength(12), Validators.pattern("^[0-9]*$")]),
      idCartera: new FormControl(this.idCartera, [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      usuario: new FormControl(user2[0])
    });
  }

  /**
   * Metodo que crea entidad financiera
   */
   createEntity() {
    const data = {
      nombre: this.entityForm.controls['nombre'].value,
      numeroIdentificacion: this.entityForm.controls['numeroIdentificacion'].value,
      idCartera: this.entityForm.controls['idCartera'].value,
      usuario: this.entityForm.controls['usuario'].value,
      idEntidadFinanciera: this.entityForm.controls['idEntidadFinanciera'].value
    }

    this.entityService.createEntity(data).subscribe(
      (result) => {
        document.getElementById('openModalButtonEdit').click();
        this.router.navigate(['home/parametrization/catalogos/financial-entity'], {
          replaceUrl: true,
        });
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Metodo que abre la ventana modal para crear entidad financiera
   */
   openAddModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  /**
   * Metodo que cierra el modal y redirecciona al listado de entidad financiera
   */
  closeModalEdit() {
    this.router.navigate(['home/parametrization/catalogos/financial-entity'], {
      replaceUrl: true,
    });
  }

  /**
   * Redirecciona al listado de entidad financiera
   */
  public back(): void {
    this.router.navigate(['home/parametrization/catalogos/financial-entity'], {
      replaceUrl: true,
    });
  }

}
