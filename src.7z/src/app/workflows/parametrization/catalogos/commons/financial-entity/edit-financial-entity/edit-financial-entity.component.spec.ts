import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditFinancialEntityComponent } from './edit-financial-entity.component';

describe('EditFinancialEntityComponent', () => {
  let component: EditFinancialEntityComponent;
  let fixture: ComponentFixture<EditFinancialEntityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditFinancialEntityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditFinancialEntityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
