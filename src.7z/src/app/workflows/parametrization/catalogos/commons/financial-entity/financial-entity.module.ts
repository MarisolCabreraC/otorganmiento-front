// Modules
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@src/app/commons/shared/shared.module';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// Route
import { FinancialEntityRoutingModule } from './financial-entity-routing.module';

// Pipe
import { PipesModule } from '@src/app/commons/pipes/pipes.module';

// Component
import { FinancialEntityComponent } from './financial-entity.component';

@NgModule({
  declarations: [FinancialEntityComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    SharedModule,
    PipesModule,
    NgbModule,
    FinancialEntityRoutingModule
  ]
  ,
  exports:[FinancialEntityComponent]
})
export class FinancialEntityModule { }
