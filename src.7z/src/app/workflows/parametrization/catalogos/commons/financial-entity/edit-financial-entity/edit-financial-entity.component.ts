import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ModalsComponent } from '@workflows/modals/modals.component';
import { FinancialEntityService } from '../service/financial-entity.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FinancialEntityInterface } from '../model/financial-entity.model';

@Component({
  selector: 'app-edit-financial-entity',
  templateUrl: './edit-financial-entity.component.html',
  styleUrls: ['../../../../../../../../src/assets/css/style_catalogue.scss']
})
export class EditFinancialEntityComponent implements OnInit {

  @ViewChild('examplemodal') modal: ModalsComponent;
  public errorCode = false;
  public errorCodeText = 'el dato no ha sido procesado';
  public mensaje: string;
  public entity: FinancialEntityInterface;
  public idEntidadFinanciera: number;
  public numeroIdentificacion: number;
  public idCartera: number;
  public nombre: string;
  public valor: number;
  public descripcion: string;
  public status: boolean;
  public form: FormGroup;
  public usuario: string;
  public operacion: string = 'Editar';

  constructor(private router: Router,
    public formBuilder: FormBuilder,
    private entityService: FinancialEntityService,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.loadData();
    this.buildForm();
  }

  /**
   * Metodo que carga los datos en el formulario
   */
   loadData() {
    this.activatedRoute.params.subscribe((params) => {
      this.entity = JSON.parse(params['editProfile']) as FinancialEntityInterface;
      this.nombre = this.entity.nombre;
      this.numeroIdentificacion = this.entity.numeroIdentificacion;
      this.idCartera = this.entity.idCartera
      this.idEntidadFinanciera = this.entity.idEntidadFinanciera;

      if (this.nombre == null) {
        this.status = true;
      }
    });
  }

  /**
   * Form entidad financiera
   */
  buildForm(): void {
    this.form = this.formBuilder.group({
      idEntidadFinanciera: new FormControl(this.idEntidadFinanciera, [Validators.required, Validators.maxLength(3), Validators.pattern("^[0-9]*$")]),
      nombre: new FormControl(this.nombre, [Validators.required, Validators.maxLength(50)]),
      numeroIdentificacion: new FormControl(this.numeroIdentificacion, [Validators.required, Validators.maxLength(12), Validators.pattern("^[0-9]*$")]),
      idCartera: new FormControl(this.idCartera, [Validators.required, Validators.maxLength(5), Validators.pattern("^[0-9]*$")]),
      usuario: new FormControl('postman')
    });
  }

  /**
   * Metodo que actualiza actividad economica
   */
   updateActivity() {
    this.mensaje = '';
    this.entity.nombre = this.form.controls['nombre'].value;
    this.entity.numeroIdentificacion = this.form.controls['numeroIdentificacion'].value;
    this.entity.idCartera = this.form.controls['idCartera'].value;
    this.entity.usuario = this.form.controls['usuario'].value;
    this.entityService.updateEntity(this.entity).subscribe(
      (result) => {
        document.getElementById('modalButtonEditClose').click();
        document.getElementById('openModalButtonEditClose').click();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }

  /**
   * Metodo que abre la ventana modal para editar entidad financiera
   */
   openEditModal() {
    document.getElementById('openModalButtonEdit').click();
  }

  /**
   * Metodo que cierra el modal y redirecciona al listado de entidad financiera
   */
   closeModalEdit() {
    this.router.navigate(['home/parametrization/catalogos/financial-entity'], { replaceUrl: true });
  }

  /**
   * Redirecciona al listado de entidad financiera
   */
   public back(): void {
    this.router.navigate(['home/parametrization/catalogos/financial-entity'], { replaceUrl: true });
  }

}
