/**
 * Entidad que mapea la informacion obtenida del microservicio de entidad financiera.
 */
export interface FinancialEntityInterface {
    /**
   * Identificador de entidad financiera.
   */
    idEntidadFinanciera: number;
    /**
   * Nombre de entidad financiera.
   */
    nombre: string;
    /**
   * Numero de ifentificación de entidad financiera.
   */
    numeroIdentificacion: number;
    /**
   * Id cartera de entidad financiera.
   */
    idCartera: number;
    /**
   * Digito verificacion de entidad financiera.
   */
    digitoVerificacion: number;
     /**
   * via pago de entidad financiera.
   */
    viaPago: number;
    /**
   * usuario de entidad financiera.
   */
    usuario?: string;
    /**
   * Estado de entidad financiera (activo - inactivo)
   */
    activo?: boolean;
}