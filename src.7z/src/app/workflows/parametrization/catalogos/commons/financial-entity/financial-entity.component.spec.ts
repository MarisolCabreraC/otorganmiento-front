import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinancialEntityComponent } from './financial-entity.component';

describe('FinancialEntityComponent', () => {
  let component: FinancialEntityComponent;
  let fixture: ComponentFixture<FinancialEntityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinancialEntityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinancialEntityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
