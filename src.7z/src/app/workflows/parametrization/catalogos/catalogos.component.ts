import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MainService } from '@commons/services/main.service';
import { InfoCatalogoParam } from '@commons/models/infoCatalogoParams';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-catalogos',
  templateUrl: './catalogos.component.html',
  styleUrls: ['./catalogos.component.scss'],
})
export class CatalogosComponent implements OnInit {
  public listCatalogs: any;
  public productCatalog: true;
  public catalogDetailColumn: boolean;
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private spinner: NgxSpinnerService,
    private mainService: MainService
  ) {
    this.catalogDetailColumn = JSON.parse(localStorage.getItem('paramCatalogo'));
   // console.log('>>>>> Escritura paramCatalogo: ', this.catalogDetailColumn);
  }

  ngOnInit(): void {
    this.initTable();
  }

  initTable() {
    this.spinner.show();
    this.mainService.findAllCatalogsByProfile().subscribe((result) => {
      this.listCatalogs = result.catalogos;
      this.spinner.hide();
      // console.log('%c test Catalogos', 'background: red', this.listCatalogs);
    });
  }

  public editCatalog(catalog: InfoCatalogoParam): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/product-catalog',
        { editCatalog: JSON.stringify(catalog) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  public editCatalogFlow(catalog: InfoCatalogoParam): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/product-catalog-type-flow',
        { editCatalog: JSON.stringify(catalog) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }
  public editCatalogAccount(catalog: InfoCatalogoParam):void{
    this.router.navigate(
      [
        '/home/parametrization/catalogos/account-catalog',
        { editCanal: JSON.stringify(catalog) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }
  public editCanal(catalog: InfoCatalogoParam): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/canal-catalog',
        { editCanal: JSON.stringify(catalog) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  public editCargo(catalog: InfoCatalogoParam): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/cargo-catalog',
        { editCanal: JSON.stringify(catalog) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  public editOcupation(catalog: InfoCatalogoParam): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/ocupation-catalog',
        { editCanal: JSON.stringify(catalog) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  public editProfession(catalog: InfoCatalogoParam): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/profession-catalog',
        { editCanal: JSON.stringify(catalog) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  public editActivity(catalog: InfoCatalogoParam): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/activity-catalog',
        { editCanal: JSON.stringify(catalog) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  public editSector(catalog: InfoCatalogoParam): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/sector-catalog',
        { editCanal: JSON.stringify(catalog) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  public editContract(catalog: InfoCatalogoParam): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/contract-catalog',
        { editCanal: JSON.stringify(catalog) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  public editStatement(catalog: InfoCatalogoParam): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/statement-catalog',
        { editCanal: JSON.stringify(catalog) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  public editOffice(catalog: InfoCatalogoParam): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/office-catalog',
        { editCanal: JSON.stringify(catalog) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  public editFestive(catalog: InfoCatalogoParam): void {
    console.log('festivos', catalog);
    this.router.navigate(
      [
        '/home/parametrization/catalogos/festive-catalog',
        { editCanal: JSON.stringify(catalog) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
    console.log();
  }

  public editentidadfinanciera(catalog: InfoCatalogoParam): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/financial-entity',
        { editCanal: JSON.stringify(catalog) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
    console.log();
  }
  public regionales(catalog: InfoCatalogoParam): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/regional-catalog',
        { editCanal: JSON.stringify(catalog) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  public etapaFlujo(catalog: InfoCatalogoParam): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/stage-catalog',
        { editCanal: JSON.stringify(catalog) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  public tipoDocumento(catalog: InfoCatalogoParam): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/document-type-catalog',
        { editCanal: JSON.stringify(catalog) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  public zona(catalog: InfoCatalogoParam): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/zone-catalog',
        { editCanal: JSON.stringify(catalog) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  public rolTitularidad(catalog: InfoCatalogoParam): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/rol-catalog',
        { editCanal: JSON.stringify(catalog) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

  public documentoDecisor(catalog: InfoCatalogoParam): void {
    this.router.navigate(
      [
        '/home/parametrization/catalogos/document-decider-catalog',
        { editCanal: JSON.stringify(catalog) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }

}
