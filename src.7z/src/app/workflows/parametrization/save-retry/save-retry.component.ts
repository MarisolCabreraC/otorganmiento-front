import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Microservicio, ParametrizationReintento } from '@commons/models/index';
import { DominioService } from '@commons/services/dominio.service';
import { ParametrizationReintentoService } from '@commons/services/parametrization-reintento.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-save-retry',
  templateUrl: './save-retry.component.html',
  styleUrls: ['./save-retry.component.scss']
})
export class SaveRetryComponent implements OnInit {

  public forma: FormGroup;
  public regularPhraseFormatHour: RegExp = /^([01]?[0-9]|2[0-3]):[0-5][0-9]$/;
  public regularPhraseNumberRetry: RegExp = /^[1-9][0-9]?$|^99$/;
  public regularPhraseNumberInterval: RegExp = /^(?:1[01][0-9]|120|1[5-9]|[2-9][0-9])$/;
  public microserviciesArray: Microservicio[];
  public editParam: string;
  public edicion: boolean = false;
  public parametrization: ParametrizationReintento;
  public errorCode = false;
  public errorCodeText = 'el dato no ha sido procesado';
  constructor(private router: Router,
    public formBuilder: FormBuilder,
    private spinner: NgxSpinnerService,
    private parametrizationRetryService: ParametrizationReintentoService,
    private dominioService: DominioService ) { }

  ngOnInit(): void {
    this.loadPage();
  }

  /**
   * 
   */
  public loadPage(): void {
      this.setForm();
      this.listMicroservices();
  }

  public back() {
    this.router.navigate(['home/reintentos/parametrizacion'], { replaceUrl: true });
  }

  public setForm(): void {

    this.forma = new FormGroup({
      idMicroServicio: new FormControl('', [Validators.required]),
      reintento: new FormControl('', [Validators.required, Validators.pattern(this.regularPhraseNumberRetry)]),
      restriccionInicio: new FormControl('', [Validators.required, Validators.pattern(this.regularPhraseFormatHour)]),
      restriccionFin: new FormControl('', [Validators.required, Validators.pattern(this.regularPhraseFormatHour)]),
      restriccionDia: new FormControl('', [Validators.required,]),
      intervalo: new FormControl('', [Validators.required, Validators.pattern(this.regularPhraseNumberInterval)])
    });
  }

  public save(): void {
    this.saveParametrization();
  }

  /**
   * recupera los microservicios, listado
   */
  public listMicroservices(): void {
    this.spinner.show();
    this.dominioService.consultarMicroservicios().subscribe(
      data => {
        this.microserviciesArray = data;
        this.spinner.hide();
      }, error => {
        this.spinner.hide();
      }
    );
  }

  /**
   * 
   */
  public saveParametrization(): void {
    this.spinner.show();
    this.parametrizationRetryService.saveParametrizationRetry(this.forma.value).subscribe(
      data => {     
        document.getElementById('openModalButtonS').click();
        this.spinner.hide();
      }, error => {
        this.spinner.hide();
      //  console.log('error al guardar parametrizacion', error);
        if(error.code = 'CRECO-P01'){
          document.getElementById('openModalButtonE').click();
        }
      }
    );
  }

  public backForm() {
    this.router.navigate(['/home/reintentos/parametrizacion']);
  }
  public goToRetryList() {
    this.router.navigate(['/home/reintentos/parametrizacion']);
  }

}
