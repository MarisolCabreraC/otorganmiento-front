import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SaveRetryComponent } from './save-retry.component';

describe('SaveRetryComponent', () => {
  let component: SaveRetryComponent;
  let fixture: ComponentFixture<SaveRetryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SaveRetryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SaveRetryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
