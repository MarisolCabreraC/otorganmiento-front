import { Component, OnInit } from '@angular/core';
import { TraceService } from '@commons/services/trace.service';
import { TraceInformation } from '@commons/models/mvp2/traceInformation'
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-massive',
  templateUrl: './massive.component.html',
  styleUrls: ['./massive.component.scss']
})
export class MassiveComponent implements OnInit {

  public tracesInformationArray: TraceInformation[];
  public arrayTracesAux: TraceInformation[] = [];
  public trace: TraceInformation;
  public message: string; // pasar a constante
  public statusRequest: string;
  public buttonFinish = false;
  public disableLength = true;
  public errorCodeNeg = 'NEG01'; // pasar a constante
  public zero = 0; // pasar a constante
  public RETRY_MASSIVE_TYPE = 'M';  // pasar a constante, masivamente
  public RETRY_MANUAL_INDIVIDUAL_TYPE = 'F'; // pasar a constante, de manera inndividual
  public LENGTH_SEVEN = 7;
  public errorBack = '';
  constructor(private traceService: TraceService, private spinner: NgxSpinnerService) { }

  private statusRetry = 'REINTENTO'; // pasar a cosntante

  ngOnInit(): void {
    this.loadTraceRetry();
  }

  /**
   * Carga la lista de trazas en estado reintento
   */
  public loadTraceRetry() {
    this.spinner.show();
    var obj = {
      nuevoEstado: this.statusRetry,
    }
    this.traceService.consultTraceStatusRetry(obj).subscribe(
      data => {
        this.tracesInformationArray = data.trazabilidad;
        this.spinner.hide();
      },
      error => {
        this.spinner.hide();
      }
    );
  }

  /**
   * recarga el aray de trazas en estado reintento y actualiza el array auxiliar para deshabilitar buton
   */
  public refreshPageTraceMassive(){
    this.arrayTracesAux = [];
    this.loadTraceRetry();
    this.flagButtonChangeCheck();
  }

  /**
   * Reintentar traza
   * @param any 
   */
  public sendMessage(trace: TraceInformation): void {
    if (this.buttonFinish == false) {
      this.buttonFinish = true;
      this.spinner.show();
      trace.tipoReintento = this.RETRY_MANUAL_INDIVIDUAL_TYPE;
      trace.usuarioEjecucion = localStorage.getItem('usuarioFront');
      console.log('traza que se envia de manera indivual revisar tipo reintento',trace);
      this.traceService.sendMessageTrace(trace).subscribe(
        data => {
          this.spinner.hide();
          this.showMessageResponse('Solicitud enviada correctamente.', 'EXITOSO');
        },
        error => {
          this.errorBack = error.error.exceptionDetails[this.zero].description;
          this.errorBack = this.errorBack.substring(this.LENGTH_SEVEN,this.errorBack.length);
          this.spinner.hide();
          this.showMessageResponse(this.errorBack, 'ERROR');
        }
      );
      this.buttonFinish = false;
    }
  }

  /**
   * finalizar traza
   * @param trace 
   */
  public confirmationFinishTry(trace: TraceInformation): void {
    this.trace = trace;
    this.trace.estado = "ERROR";
    this.message = "Quiere finalizar los intentos para esta solicitud ?";
    this.statusRequest = 'TERMINADO';
    document.getElementById('openModalButton').click();
  }

  /**
   * 
   * @param messageResponse 
   * @param statusRequest 
   */
  public showMessageResponse(messageResponse: string, statusRequest: string): void {
    this.loadTraceRetry();
    this.message = messageResponse;
    this.statusRequest = statusRequest;
    document.getElementById('openModalButton').click();
  }

  /**
   * 
   */
  public finishTry(): void {
    this.buttonFinish = true;
    this.spinner.show();
    this.traceService.updatetraza(this.trace).subscribe(
      data => {
        this.spinner.hide();
        console.log('data de actualizar traza', data);
        this.loadTraceRetry();
        document.getElementById('modalButtonEditClose').click();
      },
      error => {
        this.spinner.hide();
        this.loadTraceRetry();
        console.log('Error al acualizar la traza', error);
        this.showMessageResponse("No se pudo enviar la Solicitud.", "ERROR");
      }
    );
    this.buttonFinish = false;
  }

  /**
   * 
   */
  public closeModal(): void {
    this.loadTraceRetry();
    document.getElementById('modalButtonEditClose').click();
  }

  /**
   * Ejecuta reintento masivo 
   */
  public doMassive(): void {
     this.spinner.show(); 
     this.arrayTracesAux.forEach(t => t.tipoReintento = this.RETRY_MASSIVE_TYPE);
     this.arrayTracesAux.forEach(t => t.usuarioEjecucion =  localStorage.getItem('usuarioFront'));
     console.log('array que se envia', this.arrayTracesAux);
    this.traceService.retryMassive(this.arrayTracesAux).subscribe(
      data => {
        console.log('data de servicio masivo', data);
        this.arrayTracesAux=[];
        this.flagButtonChangeCheck();
        document.getElementById('openModalButton2').click();
        this.spinner.hide();
      }, error => {
        if(error.error.code == this.errorCodeNeg) {
          this.errorBack = error.error.description;
          console.log('mensje a mostrar de error ->',  this.errorBack);
          
          document.getElementById('openModalButton3').click();
        }
        this.spinner.hide();
      }
    );
  }
  /**
   * Actualiza el array que se envia al servicio agregando o quitando registros,
   * actualiza bandera de boton
   * @param e 
   * @param trace traza a actualizar
   */
  public getTraceList(e: any, trace:TraceInformation): void {
    if (e.target.checked) {
      this.arrayTracesAux.push(trace);
    }
    else {
      this.arrayTracesAux = this.arrayTracesAux.filter(t => t != trace);
    }
    this.flagButtonChangeCheck();
  }

  /**
   * Selecciona/deselecciona todos los registros y actualiza el array que se envia al servicio,
   * actualiza bandera de boton
   * @param e 
   */
  public selectAllTraces(e: any): void {
    if(this.tracesInformationArray.length != this.zero ) {
      this.tracesInformationArray.forEach(t => t.checked = e.target.checked)
      if (this.tracesInformationArray[0].checked) {
        this.arrayTracesAux = this.tracesInformationArray;
        this.flagButtonChangeCheck();
      } else {
        this.arrayTracesAux = [];
        this.flagButtonChangeCheck();
      }
    } 
  }

  /**
  * controla boton de mostrar cuando hay mas de un check habilitado
  */
  public flagButtonChangeCheck(): void {
    this.disableLength = this.arrayTracesAux.length < 2 ? true : false;
  }
  /**
   * 
   */
  public closeButton(): void {
    console.log('se cierra modal de error masivo');
  }
}

