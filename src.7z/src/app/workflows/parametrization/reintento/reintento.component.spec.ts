import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReintentoComponent } from './reintento.component';

describe('ReintentoComponent', () => {
  let component: ReintentoComponent;
  let fixture: ComponentFixture<ReintentoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReintentoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReintentoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
