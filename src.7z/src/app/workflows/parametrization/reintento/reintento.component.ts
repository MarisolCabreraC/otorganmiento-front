import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ParametrizationReintento, } from '@commons/models/index';
import { ParametrizationReintentoService } from '@commons/services/parametrization-reintento.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-reintento',
  templateUrl: './reintento.component.html',
  styleUrls: ['./reintento.component.scss']
})
export class ReintentoComponent implements OnInit {

  public parametrizationReintentoArray: ParametrizationReintento[];
 
  constructor(private parametrizationReintentoService: ParametrizationReintentoService,
              private router: Router, private spinner: NgxSpinnerService) { }

  ngOnInit(): void {
    this.cargarParametrizacionReintentos();
  }
 
/**
 * 
 */
  public cargarParametrizacionReintentos(): void{
    this.spinner.show();
    this.parametrizationReintentoService.consultarParametrizacionReintento().subscribe(
      data => {
        this.parametrizationReintentoArray = data;
        this.spinner.hide();
      },
      error =>{
        this.spinner.hide();
      }
    );
  }

  /**
   * 
   */
  public goToRetrySave(): void {
     this.router.navigate(['/home/reintentos/add']);
  }

}
