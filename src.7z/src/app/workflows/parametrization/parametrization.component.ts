import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MainService } from '@commons/services/main.service';
import { InfoParams } from '@commons/models/infoParams';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-parametrization',
  templateUrl: './parametrization.component.html',
  styleUrls: ['./parametrization.component.scss'],
})
export class ParametrizationComponent implements OnInit {
  public listParams: any;
  public editMenuOpt: boolean;
  constructor(
    private router: Router,
    private spinner: NgxSpinnerService,
    private mainService: MainService
  ) {
    this.editMenuOpt = JSON.parse(localStorage.getItem('paramGeneral'));
    console.log('>>>>> Escritura paramGeneral : ',  this.editMenuOpt);
  }

  ngOnInit(): void {
    this.initTable();
  }

  initTable() {
    this.spinner.show();
    this.mainService.findAllParams().subscribe((result) => {
      this.listParams = result.contenido;
      this.spinner.hide();
    });
  }

  public editParams(param: InfoParams): void {
    this.router.navigate(
      [
        'home/parametrization/edit-param',
        { editProfile: JSON.stringify(param) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }
}
