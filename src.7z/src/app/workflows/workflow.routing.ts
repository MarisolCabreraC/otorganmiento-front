import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MsalGuard } from '@azure/msal-angular';
import { ConsultGuard } from '@commons/guards/guardsConsult.guard';
import { RetryGuard } from '@commons/guards/guardsRetry.guard';
import { RetryExecuteGuard } from '@commons/guards/guardsRetryEjecutar.guard';
import { SecurityGuard } from '@commons/guards/guardsSecurity.guard';
import { ParametrizationGeneralGuard } from '@commons/guards/guardParametrizationGeneral.guard';
import { SecurityProfileGuard } from '@commons/guards/guardsSecurityPerfil.guard';
import { ParametrizationGuard } from '../commons/guards/guardOptionParametrization.guard';

import { NoPermitidoComponent } from '@commons/components/no-permitido/no-permitido.component';
import { AdminAccessComponent } from '@workflows/admin-access/admin-access.component';
import { AdminProfileComponent } from '@workflows/admin-profile/admin-profile.component';
import { AddProfileComponent } from '@workflows/admin-profile/components/add-profile/add-profile.component';
import { ClienteComponent } from '@workflows/cliente/cliente.component';
import { EditParamsComponent } from '@workflows/parametrization/commons/edit/edit-params/edit-params.component';
import { EditRetryComponent } from '@workflows/parametrization/edit-retry/edit-retry.component';
import { ParametrizationComponent } from '@workflows/parametrization/parametrization.component';
import { MassiveComponent } from '@workflows/parametrization/reintento/massive/massive.component';
import { ReintentoComponent } from '@workflows/parametrization/reintento/reintento.component';
import { SaveRetryComponent } from '@workflows/parametrization/save-retry/save-retry.component';
import { QueryComponent } from './dashboard/commons/components/query/query.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CatalogosComponent } from './parametrization/catalogos/catalogos.component';
import { DetailedTraceabilityTableComponent } from './request/components/details/detailed-consultation/commons/detailed-traceability-table/detailed-traceability-table.component';
import { DetailedConsultationComponent } from './request/components/details/detailed-consultation/detailed-consultation.component';
import { FieldDetailsComponent } from './request/components/details/field-details/field-details.component';
import { RequestComponent } from './request/request.component';
import { FestiveCatalogRoutingModule } from '@workflows/parametrization/catalogos/commons/festive-catalog/festive-catalog-routing.module'

export const routes: Routes = [
  {
    path: '',
    component: DashboardComponent,
    canActivate: [MsalGuard],
    children: [
      // { path: 'customers', loadChildren: () => import('@workflows/parametrization/catalogos/catalogos.module').then(m => m.CatalogosModule)},
      { path: 'no-permitido', component: NoPermitidoComponent },
      { path: 'admin-access', component: AdminAccessComponent, canActivate: [SecurityGuard] },
      { path: 'admin-profile', component: AdminProfileComponent, canActivate: [SecurityProfileGuard] },
      { path: 'admin-profile/add-profile', component: AddProfileComponent, canActivate: [SecurityProfileGuard] },
      { path: 'client/:client_id', component: ClienteComponent, canActivate: [ConsultGuard] },
     
      { path: 'parametrization', component: ParametrizationComponent, canActivate: [ParametrizationGeneralGuard] },
      { path: 'parametrization/edit-param', component: EditParamsComponent, canActivate: [ParametrizationGeneralGuard] },
      { path: 'reintentos/parametrizacion/edit/:id', component: EditRetryComponent, canActivate: [RetryGuard] },
      { path: 'reintentos/masivo', component: MassiveComponent, canActivate: [RetryExecuteGuard] },
      { path: 'reintentos/parametrizacion', component: ReintentoComponent, canActivate: [RetryGuard] },
      { path: 'reintentos/add', component: SaveRetryComponent, canActivate: [RetryGuard] },
      { path: 'parametrization/catalogos', component: CatalogosComponent, canActivate: [ParametrizationGuard] },

      { path: 'query', component: QueryComponent, canActivate: [ConsultGuard] },
      { path: 'request/:request_id', component: RequestComponent, canActivate: [ConsultGuard] },
      { path: 'detailed-consultation', component: DetailedConsultationComponent, canActivate: [ConsultGuard] },
      { path: 'field-details', component: FieldDetailsComponent, canActivate: [ConsultGuard] },
      { path: 'traceability', component: DetailedTraceabilityTableComponent, canActivate: [ConsultGuard] },

      { path: 'parametrization/catalogos/activity-catalog', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/activity-catalog/activity-catalog.module').then(m => m.activityCatalogModule) },
      { path: 'parametrization/catalogos/activity-catalog/admin-activity', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/activity-catalog/admin-activity/admin-activity.module').then(m => m.AdminActivityModule) },
      { path: 'parametrization/catalogos/activity-catalog/edit-activity', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/activity-catalog/edit-activity/edit-activity.module').then(m => m.EditActivityModule) },
      
      { path: 'parametrization/catalogos/canal-catalog', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/canal-catalog/canal-catalog.module').then(m => m.CanalCatalogModule) },
      { path: 'parametrization/catalogos/canal-catalog/admin-canal', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/canal-catalog/admin-canal/admin-canal.module').then(m => m.AdminCanalModule)},
      { path: 'parametrization/catalogos/canal-catalog/edit-canal', canActivate: [ParametrizationGeneralGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/canal-catalog/edit-canal/edit-canal.module').then(m => m.EditCanalModule) },
      
      { path: 'parametrization/catalogos/account-catalog', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/account-catalog/account-catalog.module').then(m => m.AccountCatalogModule) },
      { path: 'parametrization/catalogos/account-catalog/admin-account', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/account-catalog/admin-account/admin-account.module').then(m => m.AdminAccountModule) },
      { path: 'parametrization/catalogos/account-catalog/edit-account', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/account-catalog/edit-account/edit-account.module').then(m => m.EditAccountModule) },


      { path: 'parametrization/catalogos/contract-catalog', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/contract-catalog/contract-catalog.module').then(m => m.ContractCatalogModule) },
      { path: 'parametrization/catalogos/contract-catalog/admin-contract', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/contract-catalog/admin-contract/admin-contract.module').then(m => m.AdminContractModule) },
      { path: 'parametrization/catalogos/contract-catalog/edit-contract', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/contract-catalog/edit-contract/edit-contract.module').then(m => m.EditContractModule) },
      
      { path: 'parametrization/catalogos/cargo-catalog', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/cargo-catalog/cargo-catalog.module').then(m => m.CargoCatalogModule) },
      { path: 'parametrization/catalogos/cargo-catalog/admin-cargo', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/cargo-catalog/admin-cargo/admin-cargo.module').then(m => m.AdminCargoModule) },
      { path: 'parametrization/catalogos/cargo-catalog/edit-cargo', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/cargo-catalog/edit-cargo/edit-cargo.module').then(m => m.EditCargoModule) },
      
      { path: 'parametrization/catalogos/ocupation-catalog', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/ocupation-catalog/ocupation-catalog.module').then(m => m.OcupationCatalogModule) },
      { path: 'parametrization/catalogos/ocupation-catalog/admin-ocupation', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/ocupation-catalog/admin-ocupation/admin-ocupation.module').then(m => m.AdminOcupationModule) },
      { path: 'parametrization/catalogos/ocupation-catalog/edit-ocupation', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/ocupation-catalog/edit-ocupation/edit-ocupation.module').then(m => m.EditOcupationModule) },
  
      { path: 'parametrization/catalogos/office-catalog', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/office-catalog/office-catalog.module').then(m => m.OfficeCatalogModule) },
      { path: 'parametrization/catalogos/office-catalog/admin-office', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/office-catalog/admin-office/admin-office.module').then(m => m.AdminOfficeModule) },
      { path: 'parametrization/catalogos/office-catalog/edit-office', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/office-catalog/edit-office/edit-office.module').then(m => m.EditOfficeModule) },
      
      { path: 'parametrization/catalogos/product-catalog', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/product-catalog/product-catalog.module').then(m => m.ProductCatalogModule) },
      { path: 'parametrization/catalogos/product-catalog/admin-product', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/product-catalog/admin-catalog/admin-catalog.module').then(m => m.AdminCatalogModule) },
      { path: 'parametrization/catalogos/product-catalog/edit-product', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/product-catalog/edit-product/edit-product.module').then(m => m.EditProductModule) },

      { path: 'parametrization/catalogos/profession-catalog', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/profession-catalog/profession-catalog.module').then(m => m.ProfessionCatalogModule) },
      { path: 'parametrization/catalogos/profession-catalog/admin-profession', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/profession-catalog/admin-profession/admin-profession.module').then(m => m.AdminProfessionModule) },
      
      { path: 'parametrization/catalogos/sector-catalog', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/sector-catalog/sector-catalog.module').then(m => m.SectorCatalogModule) },
      { path: 'parametrization/catalogos/sector-catalog/admin-sector', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/sector-catalog/admin-sector/admin-sector.module').then(m => m.AdminSectorModule) },
      
      { path: 'parametrization/catalogos/statement-catalog', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/statement-catalog/statement-catalog.module').then(m => m.StatementCatalogModule) },
      { path: 'parametrization/catalogos/statement-catalog/admin-statement', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/statement-catalog/admin-statement/admin-statement.module').then(m => m.AdminStatementModule) },
      { path: 'parametrization/catalogos/statement-catalog/edit-statement', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/statement-catalog/edit-statement/edit-statement.module').then(m => m.EditStatementModule) },

      
      { path: 'parametrization/catalogos/product-catalog-type-flow', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/type-flow-catalog/type-flow-catalog.module').then(m => m.TypeFlowCatalogModule) },
      { path: 'parametrization/catalogos/product-catalog-type-flow/admin-type-flow', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/type-flow-catalog/admin-typeflow/admin-typeflow.module').then(m => m.AdminTypeflowModule) },
      { path: 'parametrization/catalogos/product-catalog-type-flow/edit-type-flow', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/type-flow-catalog/edit-typeflow/edit-typeflow.module').then(m => m.EditTypeflowModule) },
      
      { path: 'parametrization/catalogos/financial-entity' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/financial-entity/financial-entity.module').then(m => m.FinancialEntityModule) },
      { path: 'parametrization/catalogos/financial-entity/edit-financial-entity' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/financial-entity/edit-financial-entity/edit-financial-entity.module').then(m => m.EditFinancialEntityModule) },
      { path: 'parametrization/catalogos/financial-entity/admin-financial-entity' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/financial-entity/admin-financial-entity/admin-financial-entity.module').then(m => m.AdminFinancialEntityModule) },

      { path: 'parametrization/catalogos/festive-catalog' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/festive-catalog/festive-catalog-routing.module').then(m => m.FestiveCatalogRoutingModule) },
      { path: 'parametrization/catalogos/festive-catalog/admin-festive' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/festive-catalog/admin-festive/admin-festive-routing.module').then(m => m.AdminFestiveRoutingModule) },
      { path: 'parametrization/catalogos/festive-catalog/edit-festive/:id' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/festive-catalog/edit-festive/edit-festive-routing.module').then(m => m.EditFestiveRoutingModule) },
     
     
     
      // { path: 'parametrization/catalogos/festive-catalog' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/festive-catalog/festive-catalog.module').then(m => m.FestiveCatalogModule) },
      
        // { path: 'parametrization/catalogos/festive-catalog/admin-festive', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/festive-catalog/admin-festive/admin-festive.module').then(m => m.AdminFestiveModule) },
      // { path: 'parametrization/catalogos/festive-catalog/edit-festive', canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/festive-catalog/edit-festive/edit-festive.module').then(m => m.EditFestiveModule) },
      // { path: 'parametrization/catalogos/festive-catalog', canActivate: [ParametrizationGuard],  loadChildren: () => import('@workflows/parametrization/catalogos/commons/festive-catalog/festive-catalog.module').then(m => m.FestiveCatalogModule) },
      

      
      // { path: 'parametrization/catalogos/festive-catalog/edit-festive/:id' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/festive-catalog/edit-festive/edit-festive.module').then(m => m.EditFestiveModule) },
      // { path: 'parametrization/catalogos/festive-catalog/edit/:id', canActivate: [ParametrizationGuard], component: EditFestiveComponent }
      { path: 'parametrization/catalogos/regional-catalog' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/regional-catalog/regional-catalog.module').then(m => m.RegionalCatalogModule) },
      { path: 'parametrization/catalogos/regional-catalog/admin-regional-catalog' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/regional-catalog/admin-regional-catalog/admin-regional-catalog.module').then(m => m.AdminRegionalCatalogModule) },
      { path: 'parametrization/catalogos/regional-catalog/edit-regional-catalog/:id' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/regional-catalog/edit-regional-catalog/edit-regional-catalog.module').then(m => m.EditRegionalCatalogModule) },

      { path: 'parametrization/catalogos/stage-catalog' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/flow-stage/flow-stage.module').then(m => m.FlowStageModule) },
      { path: 'parametrization/catalogos/stage-catalog/admin-stage' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/flow-stage/admin-stage/admin-stage.module').then(m => m.AdminStageModule) },

      { path: 'parametrization/catalogos/document-type-catalog' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/document-type-catalog/document-type-catalog.module').then(m => m.DocumentTypeCatalogModule) },
      { path: 'parametrization/catalogos/document-type-catalog/edit-document-type/:id' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/document-type-catalog/edit-document-type/edit-document-type.module').then(m => m.EditDocumentTypeModule) },
      { path: 'parametrization/catalogos/document-type-catalog/admin-document-type' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/document-type-catalog/admin-document-type/admin-document-type.module').then(m => m.AdminDocumentTypeModule) },

      { path: 'parametrization/catalogos/zone-catalog' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/zone-catalog/zone-catalog.module').then(m => m.ZoneCatalogModule) },
      { path: 'parametrization/catalogos/zone-catalog/admin-zone' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/zone-catalog/admin-zone/admin-zone.module').then(m => m.AdminZoneModule) },

      { path: 'parametrization/catalogos/rol-catalog' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/rol-catalog/rol-catalog.module').then(m => m.RolCatalogModule) },
      { path: 'parametrization/catalogos/rol-catalog/admin-rol' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/rol-catalog/admin-rol/admin-rol.module').then(m => m.AdminRolModule) },

      { path: 'parametrization/catalogos/pay-note-type-catalog' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/pay-note-type-catalog/pay-note-type-catalog.module').then(m => m.PayNoteTypeCatalogModule) },
      { path: 'parametrization/catalogos/pay-note-type-catalog/edit-pay-note-type-catalog' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/pay-note-type-catalog/edit-pay-note-type-catalog/edit-pay-note-type-catalog.module').then(m => m.EditPayNoteTypeCatalogModule) },
      { path: 'parametrization/catalogos/pay-note-type-catalog/admin-pay-note-type-catalog' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/pay-note-type-catalog/admin-pay-note-type-catalog/admin-pay-note-type-catalog.module').then(m => m.AdminPayNoteTypeCatalogModule) },
      
      { path: 'parametrization/catalogos/document-decider-catalog' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/document-decider-catalog/document-decider-catalog.module').then(m => m.DocumentDeciderCatalogModule) },
      { path: 'parametrization/catalogos/document-decider-catalog/admin-document-decider' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/catalogos/commons/document-decider-catalog/admin-document-decider/admin-document-decider.module').then(m => m.AdminDocumentDeciderModule) },

      { path: 'parametrization/adherencia/adherencia' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/adherencia/adherencia/admin-adherence/add-adherence/add-adherence/add-adherence.module').then(m => m.AddAdherenceModule) },
      { path: 'parametrization/adherencia/adherencia/admin-adherence' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/adherencia/adherencia/admin-adherence/add-adherence/add-adherence/add-adherence.module').then(m => m.AddAdherenceModule) },
      { path: 'parametrization/adherencia/adherencia/admin-adherence/add-adherence' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/adherencia/adherencia/admin-adherence/admin-adherence.module').then(m => m.AdminAdherenceModule) },

      { path: 'parametrization/adherencia/adherencia/admin-profile' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/adherencia/perfiles/admin-profile/admin-profile.module').then(m => m.AdminAdherenceProfileModule) },
      { path: 'parametrization/adherencia/adherencia/admin-profile/add-profile' , canActivate: [ParametrizationGuard], loadChildren: () => import('@workflows/parametrization/adherencia/adherencia/admin-adherence/admin-adherence.module').then(m => m.AdminAdherenceModule) },


    ]


  }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule
  ]
})
export class WorkflowRoutingModule { }
