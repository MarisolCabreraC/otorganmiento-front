import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-workflow',
  templateUrl: './workflow.component.html',
  styles: [
  ]
})
export class WorkflowComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
