import { Component, OnInit } from '@angular/core';
import { MainService } from '@commons/services/main.service';
import { Perfil } from '@commons/models/perfil';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
/**
 * @ngdoc component
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Julio 2020
 * @author Everis Colombia - para Banco Popular.
 * @description Fichero encargado de realizar la interpolacion de perfiles.
 */
@Component({
  selector: 'app-admin-profile',
  templateUrl: './admin-profile.component.html',
  styleUrls: ['./admin-profile.component.scss'],
})
export class AdminProfileComponent implements OnInit {
  listProfiles: any;
  mensaje: string;
  public adminProfileBtnMenu: boolean;
  constructor(
    public router: Router,
    private spinner: NgxSpinnerService,
    private servicio: MainService
  ) {
    this.adminProfileBtnMenu = JSON.parse(localStorage.getItem('segPerfil'));
    console.log('>>>>> Escritura segPerfil: ', this.adminProfileBtnMenu);
  }

  // metodo encargado de iniciar el primer metodo
  ngOnInit(): void {
    this.initTable();
  }
  /**
   * @description metodo de consultar todos los datos de la tabla
   * @author yquintana - Everis Colombia - para Banco Popular.
   * @version 1.0.0
   * @since Julio 2020
   * @param perfil que representa el objeto del perfil.
   */
  initTable() {
    this.spinner.show();
    this.servicio.findAllProfilesByPage('-1').subscribe((result) => {
      this.listProfiles = result.contenido;
      // console.log(
      //   '%c testing adminprofiles',
      //   'background: brown; color: yellow',
      //   this.listProfiles
      // );
      this.spinner.hide();
    });
  }
  /**
   * @description metodo encargado de editar el perfil
   * @author yquintana - Everis Colombia - para Banco Popular.
   * @version 1.0.0
   * @since Julio 2020
   * @param perfil que representa el objeto del perfil.
   */
  public editProfile(perfil: Perfil): void {
    this.router.navigate(
      [
        'home/admin-profile/add-profile',
        { editProfile: JSON.stringify(perfil) },
      ],
      { skipLocationChange: true, replaceUrl: false }
    );
  }
  /**
   * @description metodo encargado de cambiar el estado del perfil
   * @author yquintana - Everis Colombia - para Banco Popular.
   * @version 1.0.0
   * @since Julio 2020
   * @param perfil que representa el objeto del perfil.
   * @param estado que representa el estado del perfil.
   */
  public estatusProfile(perfil: Perfil, estado: boolean) {
    perfil.activo = estado;
    this.servicio.updateProfile(perfil).subscribe(
      (result) => {
        window.location.reload();
      },
      (error) => {
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
  }
  /**
   * @description metodo de redireccionar a la pantalla de editar el perfil
   * @author yquintana - Everis Colombia - para Banco Popular.
   * @version 1.0.0
   * @since Julio 2020
   **/
  public addProfile(): void {
    this.router.navigate(['/add-profile']);
  }
}
