import { Component, OnInit, ViewChild } from '@angular/core';
import { MainService } from '@commons/services/main.service';
import { Perfil } from '@commons/models/perfil';
import {
  FormGroup,
  FormBuilder,
  FormControl,
  Validators,
} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ModalsComponent } from '@workflows/modals/modals.component';
import { NgxSpinnerService } from 'ngx-spinner';

/**
 * @ngdoc component
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Julio 2020
 * @author Everis Colombia - para Banco Popular.
 * @description Fichero encargado de la interpolacion de agrega perfil y crear perfil.
 */
@Component({
  selector: 'app-add-profile',
  templateUrl: './add-profile.component.html',
  styleUrls: ['./add-profile.component.scss'],
})
export class AddProfileComponent implements OnInit {
  @ViewChild('exampleModal') modal: ModalsComponent;
  public errorCode = false;
  public errorCodeText = 'el código ingresado se encuentra en uso';
  public codigoDa: string;
  public nombre: string;
  public mensaje: string;
  private perfil: Perfil;
  public operacion: string = 'Agregar';
  public titulo: string = 'nuevo perfil';
  profileForm: FormGroup;
  constructor(
    private router: Router,
    private servicio: MainService,
    public formBuilder: FormBuilder,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute
  ) {
    this.mensaje = '';
  }
  // metodo encargado de iniciar el primer metodo
  ngOnInit(): void {
    this.loadData();
    this.profileForm = new FormGroup({
      codigoDa: new FormControl(
        this.codigoDa,
        Validators.compose([Validators.required, Validators.maxLength(50)])
      ),
      nombre: new FormControl(
        this.nombre,
        Validators.compose([Validators.required, Validators.maxLength(50)])
      ),
    });
  }
  /**
   * @description metodo encargado de realizar la configuracion de los campos
   * @author yquintana - Everis Colombia - para Banco Popular.
   * @version 1.0.0
   * @since Julio 2020
   * @param perfil que representa el objeto del perfil.
   */
  configurationValidator() {
    this.profileForm = this.formBuilder.group({
      codigoDa: new FormControl(
        '',
        Validators.compose([Validators.required, Validators.maxLength(50)])
      ),

      nombre: new FormControl(
        '',
        Validators.compose([Validators.required, Validators.maxLength(50)])
      ),
    });
  }

  /**
   * @description metodo encargado de cargar los datos
   * @author yquintana - Everis Colombia - para Banco Popular.
   * @version 1.0.0
   * @since Julio 2020
   */
  loadData() {
    this.spinner.show();
    this.activatedRoute.params.subscribe((params) => {
      if (params['editProfile'] == null) {
        this.operacion = 'Agregar';
        this.titulo = ' nuevo perfil';
      } else {
        this.operacion = 'Editar';
        this.titulo = ' perfil';
        this.perfil = JSON.parse(params['editProfile']) as Perfil;
        this.codigoDa = this.perfil.codigoDa;
        this.nombre = this.perfil.nombre;
      }
    });
  }

  /**
   * @description metodo encargado enrutar a la operacion indicada
   * @author yquintana - Everis Colombia - para Banco Popular.
   * @version 1.0.0
   * @since Julio 2020
   * @param perfil que representa el objeto del perfil.
   */
  createProfile() {
    this.spinner.show();
    this.mensaje = '';
    if (this.operacion === 'Actualizar') {
      document.getElementById('openModalButtonEdit').click();
    } else {
      this.perfil = new Perfil();
      this.perfil.codigoDa = this.profileForm.controls['codigoDa'].value;
      this.perfil.nombre = this.profileForm.controls['nombre'].value;
      this.perfil.activo = true;
      this.servicio.createProfile(this.perfil).subscribe(
        (result) => {
          document.getElementById('openModalButton').click();
        },
        (error) => {
          this.mensaje = 'Error: ' + error.error.description;
        }
      );
    }
    console.log('TESTING');
  }

  /**
   * @description metodo encargado de editar el perfil
   * @author yquintana - Everis Colombia - para Banco Popular.
   * @version 1.0.0
   * @since Julio 2020
   */

  /*  openEditModal() {
    document.getElementById('modalButtonEditClose').click();
  } */

  editProfile() {
    this.spinner.show();
    this.mensaje = '';
    this.perfil.codigoDa = this.profileForm.controls['codigoDa'].value;
    this.perfil.nombre = this.profileForm.controls['nombre'].value;

    this.servicio.updateProfile(this.perfil).subscribe(
      (result) => {
        this.spinner.hide();
        document.getElementById('modalButtonEditClose').click();
        this.router.navigate(['home/admin-profile'], { replaceUrl: true });
      },
      (error) => {
        this.spinner.hide();
        this.mensaje = 'Error: ' + error.error.description;
      }
    );
    console.log('TESTING>>>>>>>>>>>>>>>>>>>');
  }
  /**
   * @description metodo encargado de volver atras.
   * @author yquintana - Everis Colombia - para Banco Popular.
   * @version 1.0.0
   * @since Julio 2020
   */
  public back(): void {
    this.router.navigate(['home/admin-profile'], { replaceUrl: true });
  }
}
