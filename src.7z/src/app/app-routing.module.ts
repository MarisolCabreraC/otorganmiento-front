import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

//Modulos
import { WorkflowRoutingModule } from '@workflows/workflow.routing';
import { MsalGuard } from '@azure/msal-angular';
import { QueryComponent } from './workflows/dashboard/commons/components/query/query.component';
/**
 * @ngdoc ngModule
 * @copyright Copyright (c) Banco Popular. All rights reserved.
 * @license MIT License.
 * @version 1.0.0
 * @since Desde Julio 2020
 * @author jcastcor - para Banco Popular.
 * @description Fichero encargado de realizar la redireccion de las urls de las rutas en toda la aplicacion
 */
const routes: Routes = [
   { path: '', redirectTo: '/home/query', pathMatch: 'full' },
   { path: 'home', canActivate: [MsalGuard], loadChildren: () => import('@workflows/workflow.module').then(m => m.WorkflowModule) },
  //  { path: 'home', loadChildren: () => import('@workflows/workflow.module').then(m => m.WorkflowModule) },
   { path: '**', pathMatch: 'full', redirectTo: '/home/query' }
];
@NgModule({
  imports: [RouterModule.forRoot(routes),
    WorkflowRoutingModule],
  exports: [RouterModule],
})
export class AppRoutingModule { }
